﻿function Usage
{
    Write-Host "Usage :"
    Write-Host ""
    Write-Host "   PowerShell.exe -ExecutionPolicy Bypass CreateAPDSShareFolder.ps1 `$(ImgPath) `$(BundleServer) `$(BundleInstance)"
    Write-Host ""
    exit;
}

Function RemoveFromPdsShare($files)
{
    if (Test-Path pdsShareDrive:\$files)
    {
       Remove-Item pdsShareDrive:\$files
    }
}

if($args[0] -eq $null)
{
    Usage;
}

if($args[1] -eq $null)
{
    Usage;
}

if($args[2] -eq $null)
{
    Usage;
}

$imagePath = $args[0]
$dbServer = $args[1]
$dbName = $args[2]

# Get the location of APDSShare
$result = Invoke-Sqlcmd -Query "SELECT FILETABLEROOTPATH('dbo.APDSShare', 2) AS APDSShare" -ServerInstance "$dbServer" -Database "$dbName"
$pdsSharePath = $result.APDSShare

# Use PS Drives because Copy-Item and Remove-Item does not work with FileTable share
New-PSDrive -Name imageDrive -PSProvider FileSystem -Root "$imagePath" | Out-Null
New-PSDrive -Name pdsShareDrive -PSProvider FileSystem -Root "$pdsSharePath" | Out-Null

# Copy over PDS Share files from image to FileTable share
Copy-Item -Path imageDrive:\* -Destination pdsShareDrive: -recurse -Force

# Cleanup: this is needed one-time until is deployed to prod
# V1.2 cleanup - begin
RemoveFromPdsShare "CommonScripts\FileStore.ps1"
RemoveFromPdsShare "CleanupPDSShare.ps1"
RemoveFromPdsShare "ShareAPDSShareFolder.ps1"
RemoveFromPdsShare "UpdateAPDSPowerShellConfigFile.ps1"
# V1.2 cleanup - end

# V15.01 cleanup - begin
RemoveFromPdsShare "CommonScripts\ResumeWorkflowActivity.ps1"
# V15.01 cleanup - end

# Remove the PS Drives
Remove-PSDrive imageDrive
Remove-PSDrive pdsShareDrive

