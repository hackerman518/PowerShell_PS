# Report workflow activity failure. Used to manually continue workflow instance process in case it's stuck.
#
# Note: Calling with wrong operationName than where workflow is stuck doesn't do anything and is safe.
#
# Uses BusinessCommon library to list all files across all firms.
# Dependencies: 
#    Needs LoadBusinessLayer.ps1 in the same folder
#    LoadBusinessLayer.ps1 needs APDSPowerShell.config in the same folder and populated with correct key values.

param
(
    [Parameter(Mandatory=$true)][int]$workflowInstanceId
    #[Parameter(Mandatory=$true)][string]$operationName
)

# Full path and file name of the script that is being run.
$scriptPath = split-path -parent $PSCommandPath

# Load dependencies which must be in the relative path as this script.
&("$scriptPath\LoadBusinessLayer.ps1")

Try
{
    # Retrieve the Data Service URI
    $dataSvcUri = [Advent.PDS.BusinessCommon.CommonShared]::GetDataServiceUri()
	Write-Host $dataSvcUri
    #Invoke-RestMethod -Method POST –Uri "${dataSvcUri}/ReportWorkflowActivityFailure?workflowInstanceId=${workflowInstanceId}&operationName='$operationName'"
    #Invoke-RestMethod -Method POST –Uri "${dataSvcUri}/FailWorkflowActivityWithInstanceID?workflowInstanceId=${workflowInstanceId}"	
}
Catch
{
    Write-Error $_
}
