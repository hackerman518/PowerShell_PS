﻿param (
	[Parameter(Mandatory=$true)][int]$scheduleId = $( Read-Host "scheduleId" ),
	[Parameter(Mandatory=$false)][int]$attempt = 10,
	[Parameter(Mandatory=$false)][int]$waitTimeSeconds = 5
)

$attemptCount = 0

while ($true)
{
    $attemptCount++
    try
    {
	    # Retrieve the Data Service URI
    	$dataSvcUri = Invoke-Expression "& $PSScriptRoot\..\Extensions\Advent.PDS.ILocatorTool.exe -cPDSCore -bDataService -tServiceUri"

        # Log the web request
        Write-Output "${dataSvcUri}/StartWorkflow?scheduleId=${scheduleId}"
    	Invoke-RestMethod -Method POST –Uri "${dataSvcUri}/StartWorkflow?scheduleId=${scheduleId}"

        # Exit the loop
        break
    }
    Catch [Exception]
    {
        if ($attemptCount -lt $attempt)
        {
	        Write-Warning $_
            Write-Output "Failed to invoke workflow on attempt $attemptCount, attempting again in $waitTimeSeconds seconds... "
            Start-Sleep -s $waitTimeSeconds
        }
        else
        {
            Write-Output "Failed to invoke workflow on attempt $attemptCount. "
            Write-Error $_.Exception.Message
            throw
        }
    }
}

