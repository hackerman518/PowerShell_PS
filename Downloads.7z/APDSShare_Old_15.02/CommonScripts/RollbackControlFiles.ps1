param
(
    # The current control file.
    [Parameter(Mandatory=$true)][string]$currentControlFile,

    # The date to rollback the control files to.
    [Parameter(Mandatory=$true)][string]$targetControlFileDate,
    
    # Optional parameter used to change to a sub directory for subscriber dedicated control files.
    [Parameter(Mandatory=$false)][string]$subControlFileDirectory
)

# Contains the full path and file name of the script that is being run.
$scriptPath = split-path -parent $PSCommandPath

# Get full path for control files via relative path.
$controlFilePath = [System.IO.Path]::GetFullPath("$scriptPath\..\ControlFiles\")

# Check if sub-directory value was provided.
if ($subControlFileDirectory)
{
    $controlFilePath += $subControlFileDirectory

    # Add the path seperator to the end of the string if it was missing one.
    if (!$controlFilePath.EndsWith('\'))
    {
        $controlFilePath += '\'
    }
}

[DateTime]$controlFileDate = New-Object DateTime
if (![DateTime]::TryParseExact($targetControlFileDate, 'yyMMdd', [CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref] $controlFileDate))
{
    Write-Error "Date format is incorrect, please supply a valid control file date in the form of yymmdd."
    exit
}

# Get the starting part of the control file.
$controlFilePrefix = [IO.Path]::GetFileNameWithoutExtension($currentControlFile)

# Get the extension of the control file.
$controlFileSuffix = [IO.Path]::GetExtension($currentControlFile)

# Get the full path to the target control file.
$targetControlFile = $controlFilePath + $controlFilePrefix + $targetControlFileDate + $controlFileSuffix

# Check if current control file exists.
if ((Test-Path $controlFilePath$currentControlFile) -eq $false)
{
    Write-Error "Target control file, $controlFilePath$currentControlFile, doesn't exists."
    exit
}

# Check if target control file exists.
if ((Test-Path $targetControlFile) -eq $false)
{
    Write-Error "Target control file, $targetControlFile, doesn't exists."
    exit
}

# Delete the current control file
Remove-Item $controlFilePath$currentControlFile -Force -ErrorAction SilentlyContinue
Write-Host "Current control file, $controlFilePath$currentControlFile, has been deleted."

# Rename the target file to current control file.
Rename-Item $targetControlFile $currentControlFile > $null
Write-Host "Target control file, $targetControlFile, has been renamed back to current."

# Increment the Date to the next date so we can start rolling back multi-day control files.
$multiDate = $controlFileDate.AddDays(1)

#Get-ChildItem -Attributes $controlFilePath -Directory -Include *$controlFileSuffix

# Get a list of files in the controle file directory that need to be deleted if rolling back more than one days worth of control files.
$files = Get-ChildItem -Path $controlFilePath -Filter *$controlFileSuffix
foreach ($file in $files)
{
    if ($file.Name.Contains($multiDate.ToString('yyMMdd')))
    {
        # Remove the multiple control files.
        Remove-Item $file.FullName -Force
        Write-Host "Archived control file, $file, has been deleted."

        # Keep incrementing until all invalid archived control files have been deleted.
        $multiDate = $multiDate.AddDays(1)
    }
}