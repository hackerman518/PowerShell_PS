﻿param
(
    # The array of dataFileInfoIds are used for resetting the processing status back to "Ready For Processing".
    [Parameter(Mandatory=$true)][int[]]$dataFileInfoIds,
    # $firmWorkflowID is used to retrieve the dynamic commands.
    [Parameter(Mandatory=$true)][int]$workflowInstanceId,
    # This bool value is used to control cooking order of the dataFileInfoIds provided.
    [Parameter(Mandatory=$true)][bool]$isCookingOrderPreserved
)

<#
    This functions job is to expand the dynamic command and insert the correctly populated command into the job table and queue.
#>
function ExpandAndSubmitSingleCommand
{
    # Even though multiple cook commands could be associated with a given firmworkflowid,
    # the ExpandCommand.ps1 script will only expand those files that were set to DataFileStatusId = 3 ("Ready For Processing")
    foreach ($c in $commands)
    {
        $com = $c.Command
        $fullCmd = "&""$scriptPath\ExpandCommand.ps1"" ""$com"" DataTranslation $workflowInstanceId"
        $results = Invoke-Expression $fullCmd

        foreach ($r in $results)
        {
            if ($r.Contains($datafileInfoId))
            {
                # Submit the cook job.
                Write-Host "Submitting the following job: $r"
                $obj = $workflowInstanceId, "DataTranslation", $r
                $jobs.GetMethod('InsertJob').Invoke($jobs, $obj);
                return;
            }
        }
    }
}

<#
    This functions job is to hold the script from submitting additional jobs until the processing status could be verified.
    This function uses recursion to continually check for file DataFileStatusId. 
    If DataFileStatus = 5 ("Processed") then return true if DataFileStatusId = 3 ("Ready For Processing") then return false.
#>
function CheckFileStatus
{
    # Sleep for 30 seconds and then check the given file's status.
    $sleepTime = 30
    Write-Host "Sleeping for $sleepTime seconds before checking DataFileStatus on DataFileInfoId $x"
    Start-Sleep -s $sleepTime

    # Get the file status.
    $arguments = ('$filter' + "=DataFileInfoId eq $x"), 'DataFileInfos'
    $status = $ps.GetMethod('GetEntities').MakeGenericMethod($dataFile).Invoke($dataFile, $arguments)

    if ($status.DataFileStatusId -eq 3)
    {
        return $false
    }
    elseif ($status.DataFileStatusId -eq 5)
    {
        return $true
    }
    else
    {
        return CheckfileStatus
    }
}

# Derive the DataSourceWorkflowId from the passed in WorkflowInstanceID.
Function GetFirmId ($workflowInstanceID)
{
    $type = [Advent.PDS.BusinessCommon.DataServiceProxy.WorkflowInstance]
    $arguments = ('$expand=DataSourceWorkflow&$filter' + "=WorkflowInstanceId eq $workflowInstanceID"), 'WorkflowInstances'
    return $ps.GetMethod('GetEntity').MakeGenericMethod($type).Invoke($type, $arguments).DataSourceWorkflow.DataSourceFirmID
}

# Contains the full path and file name of the script that is being run.
$scriptPath = split-path -parent $PSCommandPath

# Execute the following script to load dependencies which must be in the relative path as this script.
&("$scriptPath\LoadBusinessLayer.ps1")

# Initialize all object of the given classes.
$fileStreaming = [Advent.PDS.BusinessCommon.Master.FileStreaming]
$ps = [Advent.PDS.BusinessCommon.Master.PowerShell]
$actOps = [Advent.PDS.BusinessCommon.DataServiceProxy.ActivityOperation]
$wfInstance = [Advent.PDS.BusinessCommon.DataServiceProxy.WorkflowInstance]
$dataFile = [Advent.PDS.BusinessCommon.DataServiceProxy.DataFileInfo]
$jobs = [Advent.PDS.BusinessCommon.Master.JobCommunicator]

$utility = [Advent.PDS.BusinessCommon.Master.Utility]
$temp = $utility.GetMethod('GetAppSettingValue').Invoke($utility, 'MsgTagDataFileId')
$msgTagBegin = $temp.Substring(0, $temp.Length - 1)
$msgTagEnd = $temp.Substring($temp.Length - 1)

foreach ($x in $dataFileInfoIds)
{
    # Compose the datafileinfoid part of the expanded commands.
    $datafileInfoId = $msgTagBegin + $x + $msgTagEnd
    
    # Create an object array (DataFileStatusId = 3 is "Ready For Processing").
    $obj = $x, 3

    # Set file status to null for reprocessing.
    $fileStreaming.GetMethod('SetFileStatus').Invoke($fileStreaming, $obj)

    # Get the DataSourceWorkflowId associated with the given WorkflowInstanceId
    $arguments = ('$filter' + "=WorkflowInstanceId eq $workflowInstanceId"), 'WorkflowInstances'
    $dataSourceWorkflowId = $ps.GetMethod('GetEntities').MakeGenericMethod($wfInstance).Invoke($wfInstance, $arguments).DataSourceWorkflowId

    # Get a list of Commands to be passed into the ExpandCommand.ps1 script.
    $arguments = ('$filter' + "=DataSourceWorkflowId eq $dataSourceWorkflowId and OperationId eq 3"), 'ActivityOperations'
    $commands = $ps.GetMethod('GetEntities').MakeGenericMethod($actOps).Invoke($actOps, $arguments)
    
    ExpandAndSubmitSingleCommand

    if ($isCookingOrderPreserved)
    {
        if (CheckFileStatus)
        {
            Write-Host "DateFileInfoID $x processed successfully."
        }
        else
        {
            Write-Host "DateFileInfoID $x failed to process successfully. Additional cook jobs will not be executed."
            exit
        }
    }
}