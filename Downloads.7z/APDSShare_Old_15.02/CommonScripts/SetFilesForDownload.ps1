param
(
    # The array of dataFileInfoIds to be flagged for downloading.
	[Parameter(Mandatory=$true)][int[]]$dataFileInfoIds
)

# Contains the full path and file name of the script that is being run.
$scriptPath = split-path -parent $PSCommandPath
# Execute the following script to load dependencies which must be in the relative path as this script.
&("$scriptPath\LoadBusinessLayer.ps1")

$ps = [Advent.PDS.BusinessCommon.Master.PowerShell]
$dataFileInfoType = [Advent.PDS.BusinessCommon.DataServiceProxy.DataFileInfo]
$ctx = [Advent.PDS.BusinessCommon.Master.BusinessLayer]::GetNewContext()
$isPromptNeeded = $false

foreach($dataFileInfoId in $dataFileInfoIds)
{
    Try
    {
        $arguments = ('$filter' + "=DataFileInfoId eq $dataFileInfoId"), 'DataFileInfos'
        $fileInfo = $ps.GetMethod('GetEntity').MakeGenericMethod($dataFileInfoType).Invoke($dataFileInfoType, $arguments)
        $fileInfo.IsDownloadable = $true
        $ctx.AttachTo('DataFileInfos', $fileInfo)
        $ctx.UpdateObject($fileInfo)
        Write-Host $fileInfo.Name "has been flagged for download."
        $isPromptNeeded = $true
    }
    Catch [System.Exception]
    {
        Write-Error "Due to the following error files previously marked for download will not be persisted to the database."
        Write-Error $_
        exit
    }
}

$title = "Downloadable Files"
$message = "Do you want to persist the changes for the files listed in console window?"
$options = [System.Management.Automation.Host.ChoiceDescription[]]("Yes", "No")
$result = $host.ui.PromptForChoice($title, $message, $options, 0)
switch ($result)
{
    0
    {
        # Pipe the result of SaveChanges() to null so that it's not send to StandardOutput
        $ctx.SaveChanges([System.Data.Services.Client.SaveChangesOptions]::Batch) > $null
        Write-Host "Changes saved."
    }

    1 { Write-Host "Changes not saved." }
}
