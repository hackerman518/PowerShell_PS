<#
Function to validate date.
#>
function CheckDateFormat($date)
{
    [DateTime]$testDateFormat = New-Object DateTime
    if (![DateTime]::TryParseExact($date, 'yyyy-MM-dd', [CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref] $testDateFormat))
    {
        Write-Error "Date $date is invalid, please specify a valid date and in the form of yyyy-mm-dd."
        exit
    }
}
