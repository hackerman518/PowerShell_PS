<#
This script support two different parameter sets:
	1. Download file(s) by specified FileId(s).
		example: .\DownloadDataFiles.ps1 c:\temp 345,346,433
	
	2. Download file(s) by specified BusinessDate + FirmId.
		example: .\DownloadDataFiles.ps1 c:\temp 2013-08-26 12
	   
	   Note that if there are multiple instances of the same file, the latest instance
	   over-writes the older instances.  This is done via the OData query ordering by
	   DataFileInfoId.  OData does not support distinct operator.
	   
This script uses BusinessCommon library to download any files from DB.
Doesn't use compression. Needs full permissions to destPath.

Dependencies: 
	Needs LoadBusinessLayer.ps1 in the same folder
	LoadBusinessLayer.ps1 needs APDSPowerShell.config in the same folder and populated with correct key values

This is not a lib with just a Function because BAs/IMs will be running it manually. Eventually, when file download is available
from the Console this could be turned into a Function.
#>

param
(
	# The folder path to download files to.
	[Parameter(Position=0,Mandatory=$true)][string]$destPath,
	
	# A list of unique file Ids to download (comma delimited).
	[Parameter(ParameterSetName="byFileID",Position=1,Mandatory=$true)][int[]]$fileIds,

	# Filter files whose business date matches the specified business date.
	[Parameter(ParameterSetName="byBDate",Position=1,Mandatory=$true)][string]$businessDate,
	# Filter files belonging to a specified FirmID.
	[Parameter(ParameterSetName="byBDate",Position=2,Mandatory=$true)][int]$firmId
)

# Contains the full path and file name of the script that is being run.
$scriptPath = split-path -parent $PSCommandPath
# Execute the following script to load dependencies.
&("$scriptPath\LoadBusinessLayer.ps1")
# Load shared functions.
. $scriptPath\Utils.ps1

function GetFileFromDB
{
	# declare out parameters
	$fileSize = $null
	$streamSize = $null

	# compose full file name
	$filePath = $destPath + "\" + $dataFileInfo.Name

	Write-Host "Downloading file Id '$($dataFileInfo.DataFileInfoId)'..."

	# Attempt to download
	Try
	{
		$streamIn = [Advent.PDS.BusinessCommon.Master.FileStreaming]::DownloadDataFile($dataFileInfo.DataFileInfoId, $dataFileInfo.FirmId, [ref] $fileSize, [ref] $streamSize, $false)

		# create file
		$fileIn = New-Object IO.FileStream $filePath ,'Create','Write'

		# read data and send it to opened file
		$streamIn.CopyTo($fileIn);
	}
	Catch
	{        
		Write-Error "Failed to download file '$($dataFileInfo.Name)' Error: $_"
		return
	}
	Finally
	{
		# always try to dispose of resources
		try
		{
			$fileIn.Dispose()
			$streamIn.Close()   
		}    
		Catch { } 
	}

	# Check received file size matches what's in DB
	$newFile = New-Object IO.FileInfo $filePath

	if ($newFile.Length -ne $fileSize)
	{
		Write-Warning "File '$($dataFileInfo.Name)' was not downloaded completely!"
		Write-Warning "Only downloaded $($newFile.Length) out of $fileSize bytes."
		$newFile.Delete();
		Write-Warning "File is deleted."
		continue
	}

	Write-Host "Successfully downloaded file Id '$($dataFileInfo.DataFileInfoId)' to $filePath"
}


Try
{
    # Check destination folder exists.
    If (!(Test-Path $destPath))
    {
	    throw "Destination folder: $destPath doesn't exist."
    }
	
	$ps = [Advent.PDS.BusinessCommon.Master.PowerShell]
    $type = [Advent.PDS.BusinessCommon.DataServiceProxy.DataFileInfo]

	# If parameter set byBDate is used, then filter files based on FirmID and BusinessDate.
	if ($PSCmdlet.ParameterSetName -eq "byBDate")
	{
		Write-Host "Downloading file(s) for specified FirmID: $firmId and BusinessDate: $businessDate ..."
		CheckDateFormat($businessDate)

	    $arguments = ('$filter' + "=FirmId eq $firmId and BusinessDate eq datetime'$businessDate'&" + '$orderby' + "=DataFileInfoId asc"), 'DataFileInfos'		
        $dataFileInfos = $ps.GetMethod('GetEntities').MakeGenericMethod($type).Invoke($type, $arguments)
		
		$matchCount = $dataFileInfos.Count
		Write-Host "Matching files found: $matchCount."
		
		# Note that if there are multiple instances of the same file, the latest instance
		# over writes the older instances.  This is done via the odata query ordering by
		# DataFileInfoId.  OData does not support distinct operator.
		ForEach ($dataFileInfo in $dataFileInfos)
		{
			GetFileFromDB
		}
	}
	else # Parameter set is by byFileID.
	{
		# Now, download files with the supplied fileIds.
		ForEach ($fileId in $fileIds)
		{
			$arguments = ('$filter' + "=DataFileInfoId eq $fileId"), 'DataFileInfos'

			Try
			{
				$dataFileInfo = $ps.GetMethod('GetEntity').MakeGenericMethod($type).Invoke($type, $arguments)
			}
			Catch
			{
				$x = ($error[0] | out-string)
				
				# "Sequence contains no elements" is too ambiguous of a error msg...
				if ($x.Contains("Sequence contains no elements"))
				{
					Write-Warning "File with fileId $fileId doesn't exist."
				}
				else
				{
					throw
				}
				continue
			}

			GetFileFromDB
		}
	}
}
Catch
{
	Write-Error $_
}