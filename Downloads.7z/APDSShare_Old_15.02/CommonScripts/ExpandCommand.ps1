﻿<#
Sample input for DataTranslation.
{PathExe}DataProcessor.exe -x{PathCooker}\NW_Spec.xml -l{MsgTagLogFile}.log -i{MsgTagInputFile} -outPath{MsgTagOutPath} -dn
    CookerSpec = c:\temp\FB_spec.xml
    ExePath = c:\temp
    MsgTabLogFile = Log file name. This will be replaced by another dynamic value from AppSetting table that the AgentCooker.dll will understand.
    MsgTagInputFile = Input file name. This will be replaced by another dynamic value from AppSetting table that the AgentCooker.dll will understand.
    MsgTagOutPath = Output file path. This will be replaced by another dynamic value from AppSetting table that the AgentCooker.dll will understand.

Sample output for DataTranslation after expansion
C:\Extensions\DataProcessor.exe -xC:\Cookers\NW_Spec.xml -l{LogFile}.log -i{InputFile} -outPath{OutPath} -dn[DataFileInfoID:234]

Sample input for DataAcquisition.
{PathPowerShell} {PathScript}ScriptName.ps1 {PathExe}
    ScriptPath = The location of all download scripts.
    ExePath = The location of where FileTranser.exe is kept.

Sample output for DataAcquisition after expansion
C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -ExecutionPolicy ByPass C:\Extensions\ScriptName.ps1 C:\Extensions\ localhost:8001 localhost:8000 1 2
#>

param
(
    # The command to expand.
    [Parameter(Mandatory=$true)][string]$cmd,
    # The command's operation name.
    [Parameter(Mandatory=$true)][string]$operationName,
    # $workflowInstanceID is used to correlate to other information.
    [Parameter(Mandatory=$true)][int]$workflowInstanceID
)

# Derive the firmID from the passed in WorkflowInstanceID.
Function GetFirmId ($workflowInstanceID)
{
    $type = [Advent.PDS.BusinessCommon.DataServiceProxy.WorkflowInstance]
    $arguments = ('$expand=DataSourceWorkflow&$filter' + "=WorkflowInstanceId eq $workflowInstanceID"), 'WorkflowInstances'
    $workflowInstance = $ps.GetMethod('GetEntity').MakeGenericMethod($type).Invoke($type, $arguments)
    if ($workflowInstance.SubscriberFirmId -eq $null)
    {
        return $workflowInstance.DataSourceWorkflow.DataSourceFirmID
    }
    else
    {
        return $workflowInstance.SubscriberFirmID
    }
}	

# Contains the full path and file name of the script that is being run.
$scriptPath = split-path -parent $PSCommandPath
# Execute the following script to load dependencies which must be in the relative path as this script.
&("$scriptPath\LoadBusinessLayer.ps1")

$ps = [Advent.PDS.BusinessCommon.Master.PowerShell]

# Execute the replace logic even if command string might not have {WorkflowInstanceId}.
# This is more optimal than doing an if check in the foreach loop on every iteration.
$cmd = $cmd -replace "{WorkflowInstanceId}", $workflowInstanceID
$cmdExpanded = $cmd

# Initialize an object of Utility class.
$utility = [Advent.PDS.BusinessCommon.Master.Utility]

$matches = [regex]::matches($cmd, '\{[\s\w]*\}') # Pattern to match string surrounded by {}
foreach ($m in $matches)
{
    Try
    {
        $configKeyVarName =  ($m -replace "\{") -replace "\}" # Remove the squiggly brackets.
        $arguments = $configKeyVarName, $false
        $configValue = $utility.GetMethod('GetAppSettingValue').Invoke($utility, $arguments)
        $cmdExpanded = $cmdExpanded -replace "$m", $configValue
    }
    Catch [System.Exception]
    {
		throw ($_.Exception.Message + " " + $_.ScriptStackTrace)
    }
}

# StringCollection will hold the list of expanded commands to be returned.
$cmds = New-Object System.Collections.Specialized.StringCollection

# If nothing was expanded in the $cmd then return it as is.
if ($matches.Count -eq 0)
{
    $cmds.Add($cmd) > $null
}
# Special processing based on operation types specified in $operationName.
elseif ($operationName -eq 'DataTranslation')
{
    # ADS-1398 Check for -c switch.
    if ($cmdExpanded.Contains("-c"))
    {
        $StartIndexOfValue = 2
        $cParamIndex = $cmdExpanded.IndexOf("-c")
        $NextParamIndex = $cmdExpanded.IndexOf("-", $cParamIndex+1)

        # Parse out only the -c parameter and no additional parameter.
        if ($NextParamIndex -eq -1)
        {
            $pathControlFile = $cmdExpanded.Substring($cParamIndex)
        }
        else
        {
            $pathControlFile = $cmdExpanded.Substring($cParamIndex, $NextParamIndex - $cParamIndex)
        }

        $pathControlFile = $pathControlFile.Substring($StartIndexOfValue).Trim()
        $firmID = GetFirmId($workflowInstanceID)
        $fullPathControlFile = $pathControlFile + $firmID + "\"
        $cmdExpanded = $cmdExpanded.Replace($pathControlFile, $fullPathControlFile)

        # ADS-1397 create client-specific subfolder under ControlFiles folder if it doesn't exists.
        if ((Test-Path $fullPathControlFile) -eq 0)
        {
            New-Item -ItemType Directory -Path $fullPathControlFile > $null
        }
    }

    # For Data translation operation, build one expanded command for each file to be processed.
    # Now, pull a list of Raw Formatted and Pre-Translated files that have not been processed.
    $type = [Advent.PDS.BusinessCommon.DataServiceProxy.DataFileInfo]
    $arguments = ('$filter' + "=WorkflowInstanceId eq $workflowInstanceID and DataFileStatusId eq 3 and ((DataFileTypeId eq 2) or (DataFileTypeId eq 3))&$" + 'orderby=UploadStartTime asc'), 'DataFileInfos'
    $fileInfos = $ps.GetMethod('GetEntities').MakeGenericMethod($type).Invoke($type, $arguments)
    
    if ($fileInfos.Count -gt 0)
    {
        $ctx = [Advent.PDS.BusinessCommon.Master.BusinessLayer]::GetNewContext()
    }
    
    # Expand the DataFileInfoId into the command.
    foreach ($f in $fileInfos)
    {
        $fileID = $f.DataFileInfoId

        # Pipe the result of SaveChanges() to null so that it's not sent to StandardOutput
        $cmds.Add($cmdExpanded + "[DataFileInfoID:$fileID]") > $null
        
        # Set file status to "Processing" (id = 4).
        $f.DataFileStatusId = 4
        $ctx.AttachTo('DataFileInfos', $f)
        $ctx.UpdateObject($f)
    }
    
    # Push file status updates to database in batch.
    if ($fileInfos.Count -gt 0)
    {
        # Pipe the result of SaveChanges() to null so that it's not sent to StandardOutput
        $ctx.SaveChanges([System.Data.Services.Client.SaveChangesOptions]::Batch) > $null
    }
}
elseif($operationName -eq 'DataAcquisition')
{
    $firmID = GetFirmId($workflowInstanceID)

    # Get a list of FTPCommunicationSettings for the given firm id.
    $type = [Advent.PDS.BusinessCommon.DataServiceProxy.FTPAccount]
    $arguments = ('$filter' + "=WorkflowInstanceId eq $workflowInstanceID "), 'FTPAccounts'
    $ftpSettings = $ps.GetMethod('GetEntities').MakeGenericMethod($type).Invoke($type, $arguments)

    foreach($ftp in $ftpSettings)
    {
        $ftpSettingId = $ftp.FTPAccountId

        # Pipe the result of SaveChanges() to null so that it's not sent to StandardOutput.
        $cmds.Add($cmdExpanded + " -f$ftpSettingId -w$workflowInstanceID") > $null
    }
}
elseif($operationName -eq 'DataConversion')
{
    $firmID = GetFirmId($workflowInstanceID)

    # Pipe the result of SaveChanges() to null so that it's not sent to StandardOutput.
    $cmds.Add($cmdExpanded + " $firmID $workflowInstanceID") > $null
}
else
{
    # Pipe the result of SaveChanges() to null so that it's not sent to StandardOutput.
    $cmds.Add($cmdExpanded) > $null
}

return $cmds
