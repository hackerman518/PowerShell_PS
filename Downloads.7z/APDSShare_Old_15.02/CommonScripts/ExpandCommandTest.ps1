﻿# Contains the full path and file name of the script that is being run.
$scriptPath = split-path -parent $PSCommandPath

# Execute the following script to load dependencies which must be in the relative path as this script.
&("$scriptPath\LoadBusinessLayer.ps1")

# Example of dumping list into a grid view.
#Get-Process | Out-GridView

# Examples of invoking Expand-Command.ps1 where the specifiec command has nothing to expand.
#$result = Invoke-Expression "$scriptPath\ExpandCommand.ps1 'Testing this string for nothing to expand.' 'DataTranslation' 1"

# Examples of invoking Expand-Command.ps1
$result = Invoke-Expression "$scriptPath\ExpandCommand.ps1 '{PathExe}DataProcessor.exe -x{PathCooker}FB_spec.xml -l{MsgTagLogFile} -i{MsgTagInputFile} -outPath{MsgTagOutPath} -dn ' 'DataAcquisition' 1"
#$result = Invoke-Expression "$scriptPath\ExpandCommand.ps1 '{PathPowerShell} {PathDownloadScript}ScriptName.ps1 {PathExe}' 'DataAcquisition' 3"

foreach ($r in $result)
{
    Write-Host $r
}