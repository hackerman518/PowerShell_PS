param
(
    [Parameter(Mandatory=$true)][string]$filename
)

Write-Host "Begin conversion script $scriptName."
Try
{
    $firmID = 3
    $workflowInstanceId = 14020


    # Import functions to the current session.
    $scriptPath = split-path -parent $PSCommandPath	 # Get this script's full path.
    . "$scriptPath\APDSDownloadFunctionsLib.ps1"


    # Make sure the above $load is commented out and bottom one uncommented before check-in.
    $load = "$scriptPath\..\CommonScripts\LoadBusinessLayer.ps1"

    # Execute the following script to load dependencies which must be in the relative path as this script.
    & $load

    $scriptName = $MyInvocation.MyCommand.Name


    $ps = [Advent.APDS.BusinessCommon.PowerShell]
    $dataFileInfoType = [Advent.APDS.BusinessCommon.APDSDataServiceProxy.DataFileInfo]

    # Get all the acquired files for the given workflow instance ID that produced the files.
    # Only original files that have been acquired.
    # DataFileTypeId 1 is equal to Original file. 
    # DataFileStatusId 2 is equal to Acquired file. 
    $arguments = ('$filter' + "=WorkflowInstanceId eq $workflowInstanceId and DataFileStatusId eq 5"), 'DataFileInfos'
    $fileInfos = $ps.GetMethod('GetEntities').MakeGenericMethod($dataFileInfoType).Invoke($dataFileInfoType, $arguments)

    if ($fileInfos.Count -gt 0)
    {
        $ctx = [Advent.APDS.BusinessCommon.BusinessLayer]::GetNewContext()

        Write-Host "Updating business date on this number of files: " $fileInfos.Count
    }
    else
    {
        Write-Host "Zero files returned for Data Conversion."
    }


    # Create array with all the file Ids.
    foreach ($fileInfo in $fileInfos)
    {
        $CurrentBusinessDate = (Get-Date -format MM/dd/yyyy)
        $fileInfo.BusinessDate = $CurrentBusinessDate


        $ctx.AttachTo('DataFileInfos', $fileInfo)
        $ctx.UpdateObject($fileInfo)
        Write-Host "File" $fileInfo.Name " id:"$fileInfo.DataFileInfoId" business date updated to"$CurrentBusinessDate

    }

        # Push file name updates to database in batch.
        if ($fileInfos.Count -gt 0)
        {
            # Pipe the result of SaveChanges() to null so that it's not send to StandardOutput
            $ctx.SaveChanges([System.Data.Services.Client.SaveChangesOptions]::Batch) > $null

            Write-Host "Busines date updates are successfully pushed to DB for" $fileInfos.Count "files"
        }


         # Upload it the database.

            # FileType 3 is "Pre-Translated"
            # FileStatus 3 is "Ready for processing"
            $fileId = RegisterFTPFile $filename 3 59039 (Get-Date -format MM/dd/yyyy) 3


        if ($fileId -gt 0)
        {
            Write-Host "File: $filename uploaded successfully. File ID:" $fileId
        }
        else
        {
            Write-Error "File: $filename failed to uploaded."
            
            # Wait one second to allow the agent job runner to encapsulate all information written to standard error as one block.
            Wait-Event -Timeout 1
        }

	Wait-Event -Timeout 1

    DownloadDataFiles "C:\temp\Roman" 67321

}
Catch [System.Exception]
{
    Write-Error $_
}
Finally
{
    # Remove the temporary folder and all items from it.
    #If ($outPath -ne $null)
    #{
    #    If(Test-Path $outPath)
    #    {
    #        Remove-Item .\$outPath -Force -Recurse
    #    }
    #}

    Write-Host "End of upload script $scriptName."
    Write-Host "--------------------------------------------------------"
}
