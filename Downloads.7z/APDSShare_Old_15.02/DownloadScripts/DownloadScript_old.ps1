param
(
    [Parameter(Mandatory=$true)][string]$shareLocation,
    [Parameter(Mandatory=$true)][string]$ftpAccountId,
    [Parameter(Mandatory=$true)][int]$workflowInstanceId
)

# Import functions to the current session.
$scriptPath = split-path -parent $PSCommandPath	 # Get this script's full path.
. "$scriptPath\APDSDownloadFunctionsLib.ps1"

$scriptName = $MyInvocation.MyCommand.Name

Write-Host "Begin download script $scriptName."
Try
{
    # Acquire file(s) with the specified FTP setting $ftpAccountId.
    $outPath = $null
    $errorCode = DownloadFTPFile ([ref]$outPath)
    if ($errorCode -gt 0)
    {
        Write-Error "DownloadFTPFile encountered an error."

        # Wait one second to allow the agent job runner to encapsulate all information written to standard error as one block.
        Wait-Event -Timeout 1
    }
}
Catch [System.Exception]
{
    Write-Error $_
}
Finally
{
    # Remove the temporary folder and all items from it.
    If (Test-Path $outPath)
    {
        Remove-Item .\$outPath -Force -Recurse
    }

    Write-Host "End of download script $scriptName."
}
