[cmdletbinding()]
Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "$ModulesDirectory\UnitTest.psm1"
}

#Requires -Modules LogMessage
#4/29/15 Updated -split operations to regex escape delimiter (| is a regex OR)

Function Get-FileHeader{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)] [String] $FilePath,
        [int] $HeaderLineNumber = 1
    )
    try {
        Start-FunctionDebugLog
        #the join/split forces a text without line breaks to be treated as an array of one item instead of an array of characters
        ((Get-Content -Path $FilePath -TotalCount $HeaderLineNumber) -join "`n" -split "`n")[$HeaderLineNumber - 1]
    } Catch {
    	#Log unhandled errors
        "Error Detected" + $_.InvocationInfo.PositionMessage | Write-LogMessage
        $_.Exception.Message | Write-LogMessage
        break
    } Finally {
       "End of " + $MyInvocation.MyCommand | Write-LogMessage -WriteVerbose
       Stop-FunctionDebugLog
    }
}

Function Get-FileTrailer{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)] [String] $FilePath,
        [int] $TrailerLineNumberFromEnd = 1
    )
    try {
        Start-FunctionDebugLog
        #the join/split forces a text without line breaks to be treated as an array of one item instead of an array of characters
        ((Get-Content -Path $FilePath | Select-Object -Last $TrailerLineNumberFromEnd) -join "`n" -split "`n")[0]
    } Catch {
    	#Log unhandled errors
        "Error Detected" + $_.InvocationInfo.PositionMessage | Write-LogMessage
        $_.Exception.Message | Write-LogMessage
        break
    } Finally {
       Stop-FunctionDebugLog
    }
}

Function Convert-StringToBusinessDate{
    [CmdletBinding()]
    Param(
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [String] $StringToConvert,
        $RegexInput,
        $RegexReplacement,
        $DateFormat,
        [Switch] $CaseInsensitive
    )
    Begin{
        Start-FunctionDebugLog
    }
    Process{
        try {
            If ($CaseInsensitive){
                $RegexOptions = [System.Text.RegularExpressions.RegexOptions] 'ignorecase'
            } else {
                $RegexOptions = [System.Text.RegularExpressions.RegexOptions] 'none'
            }
            If ([Regex]::Match($StringToConvert, $RegexInput, $RegexOptions).Success) {
                 $DateString = ($StringToConvert -replace $RegexInput, $RegexReplacement).trim()
            } else {
                Throw 'Unable to match String to pattern'
            }
            "'" + $DateString + "'"| Write-LogMessage -WriteVerbose
            Try {
                [System.Datetime]::ParseExact($DateString, $DateFormat, [IFormatProvider] [System.Globalization.CultureInfo] 'en-US')
            } Catch {
                'Unable to parse: ' + $DateString + ' as ' + $DateFormat | Write-LogMessage -WriteWarning
                [System.Datetime] 0 
            }
        } Catch {
        	#Log unhandled errors
            "Error Detected" + $_.InvocationInfo.PositionMessage | Write-LogMessage
            $_.Exception.Message | Write-LogMessage
            break
        }
    } End {
       Stop-FunctionDebugLog
    }
}

Function Get-BusinessDate {
    [CmdletBinding(DefaultParametersetName = "DataFileInfo-UseFileName")]
    Param (
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "FilePath-UseFileName")] 
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "FilePath-UseHeader")]
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "FilePath-UseTrailer")]
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "FilePath-UseCustomScript")]  
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "FilePath-UseToday")] 
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "FilePath-UseYesterday")] 
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "FilePath-UseLastWeekDay")] 
        [alias("Path")] 
        [string] $FilePath,

        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "DataFileInfo-UseFileName")] 
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "DataFileInfo-UseHeader")]
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "DataFileInfo-UseTrailer")]
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "DataFileInfo-UseCustomScript")]  
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "DataFileInfo-UseToday")] 
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "DataFileInfo-UseYesterday")] 
        [Parameter(Mandatory=$True,ValueFromPipeline=$True,ParameterSetName = "DataFileInfo-UseLastWeekDay")] 
        $DataFileInfo,

        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Switch] $UseDelimitedData,
        
        [Parameter(ParameterSetName = "FilePath-UseFileName")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseFileName")] 
        [Switch] $UseFileName,
        
        [Parameter(ParameterSetName = "FilePath-UseHeader")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [Switch] $UseHeader,
        [Parameter(ParameterSetName = "FilePath-UseHeader")]
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [int] $HeaderLineNumber = 1,
        
        [Parameter(ParameterSetName = "FilePath-UseTrailer")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")] 
        [Switch] $UseTrailer,
        [Parameter(ParameterSetName = "FilePath-UseTrailer")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")] 
        [int] $TrailerLineNumberFromEnd = 1,
        
        [Parameter(ParameterSetName = "FilePath-UseCustomScript")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseCustomScript")] 
        [Switch] $UseCustomScript,

        [Parameter(Mandatory=$True, ParameterSetName = "FilePath-UseCustomScript")] 
        [Parameter(Mandatory=$True, ParameterSetName = "DataFileInfo-UseCustomScript")] 
        [String] $CustomScriptPath,

        [Parameter(Mandatory=$True, ParameterSetName = "FilePath-UseCustomScript")] 
        [Parameter(Mandatory=$True, ParameterSetName = "DataFileInfo-UseCustomScript")] 
        [Hashtable] $CustomScriptArguments,
        
        [Parameter(ParameterSetName = "FilePath-UseToday")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseToday")] 
        [Switch] $UseToday,
        
        [Parameter(ParameterSetName = "FilePath-UseYesterday")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseYesterday")] 
        [Switch] $UseYesterday,
        
        [Parameter(ParameterSetName = "FilePath-UseLastWeekDay")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseLastWeekDay")] 
        [Switch] $UseLastWeekDay,
        
        [Parameter(ParameterSetName = "FilePath-UseToday")]
        [Parameter(ParameterSetName = "FilePath-UseYesterday")]
        [Parameter(ParameterSetName = "FilePath-UseLastWeekDay")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseToday")]
        [Parameter(ParameterSetName = "DataFileInfo-UseYesterday")]
        [Parameter(ParameterSetName = "DataFileInfo-UseLastWeekDay")] 
        [DateTime] $InputDate = (get-date),
        
        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "FilePath-UseFileName")] 
        [Parameter(ParameterSetName = "FilePath-UseHeader")] 
        [Parameter(ParameterSetName = "FilePath-UseTrailer")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseFileName")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")]
        [String] $RegexInput = '(\w{2})(\d{6})(.{4})',

        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "FilePath-UseFileName")] 
        [Parameter(ParameterSetName = "FilePath-UseHeader")] 
        [Parameter(ParameterSetName = "FilePath-UseTrailer")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseFileName")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")]
        [String] $RegexReplacement = '$2',

        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "FilePath-UseFileName")] 
        [Parameter(ParameterSetName = "FilePath-UseHeader")] 
        [Parameter(ParameterSetName = "FilePath-UseTrailer")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseFileName")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")]
        [String] $DateFormat = "MMddyy",

        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "FilePath-UseHeader")] 
        [Parameter(ParameterSetName = "FilePath-UseTrailer")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")]
        [String] $Delimiter="",

        [Parameter(ParameterSetName = "FilePath-UseHeader")] 
        [Parameter(ParameterSetName = "FilePath-UseTrailer")]
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")]
        [int] $ColumnNumber = 0,
        
        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [String] $ColumnName = "",
        
        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [int] $ColumnLineNumber = 1,
        
        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [int[]] $SampleDataLineNumbers = @($ColumnLineNumber+1),

        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Switch] $DoubleQuotesEscapeDelimeter,
                
        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "FilePath-UseFileName")]
        [Parameter(ParameterSetName = "FilePath-UseHeader")] 
        [Parameter(ParameterSetName = "FilePath-UseTrailer")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseFileName")]
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")]
        [switch] $CaseInsensitive,
        
        [Parameter(ParameterSetName = "FilePath-UseDelimitedData")]
        [Parameter(ParameterSetName = "FilePath-UseHeader")] 
        [Parameter(ParameterSetName = "FilePath-UseTrailer")]
        [Parameter(ParameterSetName = "DataFileInfo-UseDelimitedData")]
        [Parameter(ParameterSetName = "DataFileInfo-UseHeader")] 
        [Parameter(ParameterSetName = "DataFileInfo-UseTrailer")]
        [String] $TempDirectory = $Global:BusinessDateTempDirectory
    )
    Start-FunctionDebugLog
    Try {
        $InputPreference = ($PSCmdlet.ParameterSetName -split '-')[0]
        $BusinessDateMethod=($PSCmdlet.ParameterSetName -split '-')[1]

        Switch ($InputPreference){
            "FilePath" {
                $FileName = [System.IO.Path]::GetFileName($FilePath)
            }
            "DataFileInfo" {
                $FileName = $DataFileInfo.Name
                If ($BusinessDateMethod -in @("UseDelimitedData", "UseHeader", "UseTrailer", "UseCustomScript")){
                    Get-DataFile -DataFileInfoId ($DataFileInfo.DataFileInfoId) -OutputFolder $TempDirectory
                    $FilePath = Join-Path -Path $TempDirectory -ChildPath ($DataFileInfo.Name)
                }
            }
        }
        Switch ($BusinessDateMethod){
            "UseFileName" {
                #Gets the file name
                $StringToConvert = $FileName
                #Extracts business date using a regex replace and a ParseExact
                Return Convert-StringToBusinessDate -StringToConvert $StringToConvert -RegexInput $RegexInput -RegexReplacement $RegexReplacement -DateFormat $DateFormat -CaseInsensitive:$CaseInsensitive
            }
            "UseDelimitedData" {
                #Get Column headers and find the business date column
                If ($DoubleQuotesEscapeDelimeter){
                    $ColumnLine = Get-FileHeader -FilePath $FilePath -HeaderLineNumber $ColumnLineNumber
                    $ColumnLine | Write-LogMessage -WriteVerbose
                    If ($CaseInsensitive){
                        $ColumnNames = $ColumnLine.tolower() -split [regex]::escape($Delimiter).tolower()
                    } else {
                        $ColumnNames = $ColumnLine -split [regex]::escape($Delimiter)
                    }
                    $HeaderLibrary = @{}
                    $FixedColumnNames = @()
                    $ColumnNames | %{
                        $ColumnHeaderName = $_
                        If ($HeaderLibrary.ContainsKey($ColumnHeaderName)){
                            $HeaderLibrary.$ColumnHeaderName +=1
                            $FixedColumnNames += $ColumnHeaderName + $HeaderLibrary.$ColumnHeaderName
                        } else {
                            $HeaderLibrary.$ColumnHeaderName = 1
                            $FixedColumnNames += $ColumnHeaderName
                        }
                    }
                    If ($SampleDataLineNumbers) {
                        $SampleDataLines = @()
                        $MaxCount = $SampleDataLineNumbers | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
                        $FileContent = Get-Content -Path $FilePath -TotalCount $MaxCount
                        $SampleDataLineNumbers | %{
                            $SampleDataLineIndex = $_-1
                            $SampleDataLines += $FileContent[$SampleDataLineIndex]
                        }
                    } else {
                        $SampleDataLines = Get-Content -Path $FilePath | Select-Object -Skip $ColumnLineNumber
                    }
                    $ValuesFound = $SampleDataLines | ConvertFrom-Csv -Delimiter $Delimiter -Header $FixedColumnNames | Select-Object -ExpandProperty $ColumnName
                } else {
                    #Get Column headers and find the business date column
                    $ColumnLine = Get-FileHeader -FilePath $FilePath -HeaderLineNumber $ColumnLineNumber
                    $ColumnLine | Write-LogMessage -WriteVerbose
                    If ($CaseInsensitive){
                        $ColumnIndexOfBusinessDate = [array]::indexof($ColumnLine.tolower() -split [regex]::escape($Delimiter.tolower()), $ColumnName.tolower())
                    } else {
                        $ColumnIndexOfBusinessDate = [array]::indexof($ColumnLine -split [regex]::escape($Delimiter), $ColumnName)
                    } 
                    #Gets a data row and splits out the business date column
                    $SampleDataLines = @()
                    If (-not $SampleDataLineNumbers) {
                        $SampleDataLineNumbers = ($ColumnLineNumber+1)..(Get-Content -Path $FilePath | Measure-Object | Select-Object -ExpandProperty Count)
                    } 
                    $SampleDataLineNumbers | %{
                        $SampleDataLineNumber = $_
                        $SampleDataLines += (Get-FileHeader -FilePath $FilePath -HeaderLineNumber $SampleDataLineNumber) 
                    }
                    $ValuesFound = @()
                    $SampleDataLines | %{
                        $SampleDataLine = $_
                        $ValuesFound += ($SampleDataLine -split [regex]::escape($Delimiter))[$ColumnIndexOfBusinessDate]
                    }
                }
                $DatesFound = $ValuesFound | 
                ForEach-Object -Process {
                    Convert-StringToBusinessDate -StringToConvert $_ -RegexInput $RegexInput -RegexReplacement $RegexReplacement -DateFormat $DateFormat -CaseInsensitive:$CaseInsensitive
                } | 
                Sort-Object -Descending -Unique #Was Select-Object
                
                Switch ($DatesFound | Measure-Object | Select-Object -ExpandProperty Count) {
                    0 {
                        "Business Dates not Found." | Write-LogMessage -WriteWarning  
                        "Using Setting Business date to 0..." | Write-LogMessage 
                        Return [Datetime] 0
                    }
                    1 {
                        Return $DatesFound
                    }
                    default{
                        "Multiple Business Dates Found." | Write-LogMessage -WriteWarning  
                        $DatesFound | Write-LogMessage -WriteWarning
                        "Using First Instance found..." | Write-LogMessage 
                        Return ($DatesFound | Select-Object -First 1)
                    }
                } 
            }
            "UseHeader" {
                #Gets the first line of the file
                $StringToConvert = Get-FileHeader -FilePath $FilePath -HeaderLineNumber $HeaderLineNumber
                #Use the Delimiter and ColumnNumber parameters to get the correct column of a delimited line (counting first column as 1 not 0)
                If ($Delimiter -and $ColumnNumber){
                    $StringToConvert = ($StringToConvert -split [regex]::escape($Delimiter))[$ColumnNumber - 1]
                }
                #Extracts business date using a regex replace and a ParseExact
                Return Convert-StringToBusinessDate -StringToConvert $StringToConvert -RegexInput $RegexInput -RegexReplacement $RegexReplacement -DateFormat $DateFormat -CaseInsensitive:$CaseInsensitive
            }
            "UseTrailer" {
                #Gets the last line of the file
                $StringToConvert = Get-FileTrailer -FilePath $FilePath -TrailerLineNumberFromEnd $TrailerLineNumberFromEnd
                #Use the Delimiter and ColumnNumber parameters to get the correct column of a delimited line (counting first column as 1 not 0)
                If ($Delimiter -and $ColumnNumber){
                    $StringToConvert = ($StringToConvert -split [regex]::escape($Delimiter))[$ColumnNumber - 1]
                }
                #Extracts business date using a regex replace and a ParseExact
                Return Convert-StringToBusinessDate -StringToConvert $StringToConvert -RegexInput $RegexInput -RegexReplacement $RegexReplacement -DateFormat $DateFormat -CaseInsensitive:$CaseInsensitive
            }
            "UseCustomScript" {
                . $CustomScriptPath -FilePath $FilePath @CustomScriptArguments
            }
            "UseToday" {
                Return $InputDate.date
            }
            "UseYesterday" {
                Return  $InputDate.date.AddDays(-1)
            }
            "UseLastWeekDay" {
                Switch ($InputDate.DayOfWeek){
                    "Sunday" {
                        Return $InputDate.date.AddDays(-2)
                    }
                    "Monday" {
                        Return $InputDate.date.AddDays(-3)
                    }
                    Default  {
                        Return $InputDate.date.AddDays(-1)
                    }
                }
            }
            default {}
        }
    } catch {
        $_.invocationinfo.PositionMessage | Write-LogMessage -WriteWarning
        $_.Exception.Message | Write-LogMessage -WriteWarning

        "Unable to Determine Business Date.  Setting Business Date to 0 to ignore on subsequent runs" | Write-LogMessage -WriteWarning
        return 0
    }
    Finally{
        Stop-FunctionDebugLog
    }
}

Function Invoke-RepeatedScriptBlock {
    [CmdletBinding()]
    Param(
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [object] $InputObject,
        [ScriptBlock] $ScriptBlockToRepeat = {$_},
        [int] $TimesToRepeat = 1
    )
    Begin {
        $ReturnArray = @()
    }
    Process{
        $LoopObject = $InputObject
        1..$TimesToRepeat | ForEach-Object {
            $LoopObject = $LoopObject | ForEach-Object -Process $ScriptBlockToRepeat
        }
        $ReturnArray += $LoopObject
    }
    End{
        $ReturnArray
    }
}

Function Get-PreviousWeekday {
    Param(
        [DateTime] $InputDate
    )
    Switch ($InputDate.DayOfWeek){
        "Sunday" {
            Return $InputDate.date.AddDays(-2)
        }
        "Monday" {
            Return $InputDate.date.AddDays(-3)
        }
        Default  {
            Return $InputDate.date.AddDays(-1)
        }
    }
}

Function Get-TargetDate{
    Param(
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [DateTime] $InputDate = (Get-Date).date,
        [int] $WeekDaysBack = 1
    )
    $InputDate | Invoke-RepeatedScriptBlock -ScriptBlockToRepeat {Get-PreviousWeekday -InputDate $_} -TimesToRepeat $WeekDaysBack
} 

Function Get-PreviousDate{
    Param(
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [DateTime] $InputDate = (Get-Date).date,
        [int] $DaysBack = 1
    )
    $InputDate.date.AddDays(-1 * $DaysBack)
} 

Set-Alias -Name Get-BusinessDateFromDataFileInfo -Value Get-BusinessDate -Scope Global

If ($UnitTest){
    $UnitTestFilePath = "$ModulesDirectory\APDSBusinessDate.11223333.UnitTestData"
    $UnitTestFileName = [System.IO.Path]::GetFileName($UnitTestFilePath)

    $Asserts = @()

    #Test Convert-StringToBusinessDate Function
    $Asserts += Assert-Equal -TestInput (Convert-StringToBusinessDate -StringToConvert $UnitTestFileName -RegexInput '^APDSBusinessDate.(\d{2})(\d{2})(\d{4}).UnitTestData$' -RegexReplacement '$1/$2/$3' -DateFormat 'MM/dd/yyyy') -ExpectedValue ([datetime] '11/22/3333')
    $Asserts += Assert-Is    -TestInput (Convert-StringToBusinessDate -StringToConvert $UnitTestFileName -RegexInput '^APDSBusinessDate.(\d{2})(\d{2})(\d{4}).UnitTestData$' -RegexReplacement '$1/$2/$3' -DateFormat 'MM/dd/yyyy') -ExpectedType ([datetime])

    #Test Get-BusinessDate on all cases with FilePath
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseFileName -RegexInput '^APDSBusinessDate.(\d{2})(\d{2})(\d{4}).UnitTestData$' -RegexReplacement '$1/$2/$3' -DateFormat 'MM/dd/yyyy') -ExpectedValue ([datetime] '11/22/3333')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseHeader -HeaderLineNumber 1 -RegexInput '^Header\|(\d{1,2})/(\d{1,2})/(\d{4})$' -RegexReplacement '$1/$2/$3' -DateFormat 'M/d/yyyy') -ExpectedValue ([datetime] '1/2/2003')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseHeader -HeaderLineNumber 1 -Delimiter '|' -ColumnNumber 2 -RegexInput '^(\d{1,2})/(\d{1,2})/(\d{4})$' -RegexReplacement '$1/$2/$3' -DateFormat 'M/d/yyyy') -ExpectedValue ([datetime] '1/2/2003')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseTrailer -TrailerLineNumberFromEnd 1 -RegexInput '^Trailer\|(\w{3} \d{1,2} \d{4})$' -RegexReplacement '$1' -DateFormat 'MMM d yyyy') -ExpectedValue ([datetime] '2/3/2004')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseTrailer -TrailerLineNumberFromEnd 1 -Delimiter '|' -ColumnNumber 2 -RegexInput '^(\w{3} \d{1,2} \d{4})$' -RegexReplacement '$1' -DateFormat 'MMM d yyyy') -ExpectedValue ([datetime] '2/3/2004')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseDelimitedData -ColumnName 'BusinessDate' -Delimiter '|' -ColumnLineNumber 2 -SampleDataLineNumbers 3 -RegexInput '(.*)' -RegexReplacement '$1' -DateFormat 'M-d-yyyy') -ExpectedValue ([datetime] '3/4/2005')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseDelimitedData -ColumnName 'BusinessDate' -Delimiter '|' -DoubleQuotesEscapeDelimeter -ColumnLineNumber 2 -SampleDataLineNumbers 3 -RegexInput '(.*)' -RegexReplacement '$1' -DateFormat 'M-d-yyyy') -ExpectedValue ([datetime] '3/4/2005')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseDelimitedData -ColumnName 'BusinessDate' -Delimiter '|' -ColumnLineNumber 2 -SampleDataLineNumbers @(3,4) -RegexInput '^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$' -RegexReplacement '$1-$2-$3' -DateFormat 'M-d-yyyy') -ExpectedValue ([datetime] '3/4/2005')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseToday) -ExpectedValue (Get-Date).Date
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseToday -InputDate '1/1/2001') -ExpectedValue ([datetime] '1/1/2001')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseYesterday -InputDate '1/1/2001') -ExpectedValue ([datetime] '12/31/2000')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDate -FilePath $UnitTestFilePath -UseLastWeekDay -InputDate '1/1/2001') -ExpectedValue ([datetime] '12/29/2000')    

    #Test Alias
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseFileName -RegexInput '^APDSBusinessDate.(\d{2})(\d{2})(\d{4}).UnitTestData$' -RegexReplacement '$1/$2/$3' -DateFormat 'MM/dd/yyyy') -ExpectedValue ([datetime] '11/22/3333')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseHeader -HeaderLineNumber 1 -RegexInput '^Header\|(\d{1,2})/(\d{1,2})/(\d{4})$' -RegexReplacement '$1/$2/$3' -DateFormat 'M/d/yyyy') -ExpectedValue ([datetime] '1/2/2003')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseHeader -HeaderLineNumber 1 -Delimiter '|' -ColumnNumber 2 -RegexInput '^(\d{1,2})/(\d{1,2})/(\d{4})$' -RegexReplacement '$1/$2/$3' -DateFormat 'M/d/yyyy') -ExpectedValue ([datetime] '1/2/2003')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseTrailer -TrailerLineNumberFromEnd 1 -RegexInput '^Trailer\|(\w{3} \d{1,2} \d{4})$' -RegexReplacement '$1' -DateFormat 'MMM d yyyy') -ExpectedValue ([datetime] '2/3/2004')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseTrailer -TrailerLineNumberFromEnd 1 -Delimiter '|' -ColumnNumber 2 -RegexInput '^(\w{3} \d{1,2} \d{4})$' -RegexReplacement '$1' -DateFormat 'MMM d yyyy') -ExpectedValue ([datetime] '2/3/2004')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseDelimitedData -ColumnName 'BusinessDate' -Delimiter '|' -ColumnLineNumber 2 -SampleDataLineNumbers 3 -RegexInput '(.*)' -RegexReplacement '$1' -DateFormat 'M-d-yyyy') -ExpectedValue ([datetime] '3/4/2005')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseDelimitedData -ColumnName 'BusinessDate' -Delimiter '|' -DoubleQuotesEscapeDelimeter -ColumnLineNumber 2 -SampleDataLineNumbers 3 -RegexInput '(.*)' -RegexReplacement '$1' -DateFormat 'M-d-yyyy') -ExpectedValue ([datetime] '3/4/2005')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseDelimitedData -ColumnName 'BusinessDate' -Delimiter '|' -ColumnLineNumber 2 -SampleDataLineNumbers @(3,4) -RegexInput '^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$' -RegexReplacement '$1-$2-$3' -DateFormat 'M-d-yyyy') -ExpectedValue ([datetime] '3/4/2005')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseToday) -ExpectedValue (Get-Date).Date
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseToday -InputDate '1/1/2001') -ExpectedValue ([datetime] '1/1/2001')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseYesterday -InputDate '1/1/2001') -ExpectedValue ([datetime] '12/31/2000')
    $Asserts += Assert-Equal -TestInput (Get-BusinessDateFromDataFileInfo -FilePath $UnitTestFilePath -UseLastWeekDay -InputDate '1/1/2001') -ExpectedValue ([datetime] '12/29/2000')

    $PassedTests = $Asserts | Where-Object -Filter {$_.TestResult}
    $FailedTests = $Asserts | Where-Object -Filter {-not $_.TestResult}
    "{0}/{1} Unit Test Passed" -f $PassedTests.count, $Asserts.count | Write-Verbose -Verbose
    $Asserts | Write-Verbose
    If ($FailedTests){
        "The Following Tests did not pass:" | Write-Verbose -Verbose
        $FailedTests | Write-Verbose -Verbose
    }
} else {
    "Unit Test Not Required" | Write-Verbose
}