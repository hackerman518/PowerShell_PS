[cmdletbinding()]
Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "$ModulesDirectory\UnitTest.psm1"
}


#All logging calls in Write-LogMessage should use this function 
Function Write-Log{
    [CmdletBinding()]
    Param(
        [parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [alias("Object")] [String] $StringMessage
    )
    Begin {
        #HTML Control characters should automatically be escaped by NLOG
        #Escape curly brackets as they throw errors within Powershell
        $CharactersToEscape = '{','}'
        #Also High Unicode xD800 - xDFFF Surrogate characters as they crash the agent
        $CharactersToEscape += [char[]](([convert]::ToInt32('D800',16))..([convert]::ToInt32('DFFF',16)))
    }
    Process{
        Try{
            If ($StringMessage){
                $EscapedStringMessage = $StringMessage
                $CharactersToEscape | %{
                    $CharacterToEscape = $_
                    $EscapedStringMessage = $EscapedStringMessage -replace ([regex]::Escape($CharacterToEscape)), ("&#x{0:X};" -f ([int][char] $CharacterToEscape))
                }
                Write-Verbose -Message $EscapedStringMessage -Verbose
            }
        } catch{}
    }
}

Function Write-LogMessage {
    [CmdletBinding(DefaultParametersetName = "WriteHost")]
    Param(
        [parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [alias("Object")] [Object] $Message,
        [string] $LogPath = $Global:DownloadLogPath,
        [Parameter(ParameterSetName = "WriteDebug")]   [switch] $WriteDebug,
        [Parameter(ParameterSetName = "WriteError")]   [switch] $WriteError,
        [Parameter(ParameterSetName = "WriteVerbose")] [switch] $WriteVerbose,
        [Parameter(ParameterSetName = "WriteWarning")] [switch] $WriteWarning
    )
    Begin{
        If ($LogPath -and (-not (Test-Path -Path $LogPath))){
            "Creating $LogPath" | Write-Verbose 
            New-Item -Path $LogPath -ItemType File
        }
        $Header = "WIP-" + $Global:WorkflowInstanceSettings.WorkflowInstanceID + "_" + $Global:OperationActivity + "_IPID-" + $Global:DataSourceInterfaceCode + "_SubCopy-" + $Global:SubscriberCopy + ": "
        $ErrorMessage = @()
        $MessageArray = @()
    }
    Process{
        $Message | Where-Object -Filter {$_} | ForEach-Object -Process {
            $MessageArray+=$Message
        }        
    } End {
        $TextMessage = $MessageArray | out-string -Width 200
        $AppendedMessages = @()
        $TextMessage | ForEach-Object -Process {
            $_.trim() -split "`r?`n" | Where-Object -Filter {$_.trim()} | ForEach-Object -Process {
                $AppendedMessages += $Header + $_.trim()
            }            
        }
        $AppendedMessages | Where-Object -Filter {$_} | ForEach-Object -Process {
            $AppendedMessage = $_
            Switch ($PSCmdlet.ParameterSetName){
                "WriteDebug" {
                    If ($DebugPreference -ne 'SilentlyContinue'){
                        "Debug: $AppendedMessage" | Write-Log
                    }
                }
                "WriteError" {
                    If ($LogPath){
                        Try {
                            Add-Content -Path $LogPath -value "Error: $AppendedMessage"
                        } Catch {}
                    }
                    $ErrorMessage += $AppendedMessage
                }
                "WriteVerbose" {
                    If ($VerbosePreference -ne 'SilentlyContinue'){
                        "Verbose: $AppendedMessage" |  Write-Log
                    }
                }
                "WriteWarning" {
                    If ($WarningPreference -ne 'SilentlyContinue'){
                        "Warning: $AppendedMessage" | Write-Log
                    }
                    If ($LogPath){
                        Try {
                            Add-Content -Path $LogPath -value "Warning: $AppendedMessage"
                        } Catch {}
                    }
                }
                default {
                    $AppendedMessage | Write-Log
                    If ($LogPath){
                        Try {
                            Add-Content -Path $LogPath -value $AppendedMessage
                        } Catch {}
                    }
                }
            }
        }
        If ($PSCmdlet.ParameterSetName -eq 'WriteError'){
            $ErrorMessageString = $ErrorMessage -join "`n"
            Write-Error -Message $ErrorMessageString
        }
    }
}

Function Start-FunctionDebugLog{
    [cmdletbinding()]
    Param()
    Try {
        $CallingFunctionInfo = (Get-PSCallStack)[1]
        "Calling function '" + $CallingFunctionInfo.Command + " " + $CallingFunctionInfo.Arguments + "' in " + $CallingFunctionInfo.Location + " on " +(get-date).tostring("MM/dd/yyyy hh:mm:ss") | Write-LogMessage -WriteDebug
    } Catch{
    }
}

Function Stop-FunctionDebugLog{
    [cmdletbinding()]
    Param()
    Try {
        $CallingFunctionInfo = (Get-PSCallStack)[1]
        "Exiting function '" + $CallingFunctionInfo.Command + " " + $CallingFunctionInfo.Arguments + "' in " + $CallingFunctionInfo.Location + " on " +(get-date).tostring("MM/dd/yyyy hh:mm:ss") | Write-LogMessage -WriteDebug
    } Catch{
    }
}

If ($UnitTest){
    $Asserts = @()
    $Asserts += Assert-Equal -TestInput 1 -ExpectedValue 1
    $Asserts += Assert-NotEqual -TestInput 1 -UnexpectedValue 0
    $Asserts += Assert-Is -TestInput 1 -ExpectedType ([int])
    $Asserts += Assert-IsNot -TestInput 1 -UnexpectedType ([String])
    $Asserts += Assert-Contains -TestInput @(1,2,3) -ExpectedItem 1
    $Asserts += Assert-NotContains -TestInput @(1,2,3) -UnexpectedItem 0
    $Asserts += Assert-MemberOf -TestInput 1 -ExpectedInSet @(1,2,3)
    $Asserts += Assert-NotMemberOf -TestInput 0 -UnexpectedInSet @(1,2,3)
    $Asserts += Assert-Like -TestInput "123" -ExpectedWildcardPattern "?2*"
    $Asserts += Assert-NotLike -TestInput "123" -UnexpectedWildcardPattern "??2*"
    $Asserts += Assert-Match -TestInput "123" -ExpectedRegExPattern '^\d{3}$'
    $Asserts += Assert-NotMatch -TestInput "123" -UnexpectedRegExPattern '^\d{5}$'
    $Asserts += Assert-ScriptBlock -TestInput 1,2,3 -ScriptBlock {$_[0] + 1} -ExpectedValue 2
    If ($Asserts | Where-Object -Filter {-not $_}){
        "Unit Test Failed" | Write-Verbose -Verbose
    } else {
        "Unit Test Passed" | Write-Verbose -Verbose
    }
} else {
    "Unit Test Not Required" | Write-Verbose 
}