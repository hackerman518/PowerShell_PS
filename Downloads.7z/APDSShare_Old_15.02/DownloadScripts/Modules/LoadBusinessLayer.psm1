[cmdletbinding()]
Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "$ModulesDirectory\UnitTest.psm1"
}

Function LoadAssembly([String]$fileLocation)
{
    If (!(Test-Path $fileLocation))
    {
        $msg = "Problem loading $fileLocation. The assembly does not exists."
        Throw $msg
    }
    
    # Don't change this from UnsafeLoadFrom to LoadFrom because the security policy prevents either 
    # remote users or local users from running this script based on PathExe config key's value being UNC path vs local path.
    [System.Reflection.assembly]::UnsafeLoadFrom($fileLocation) > $null
}


# Contains the full path and file name of the script that is being run.
$scriptPath = $CommonScriptsDirectory

# Load libraries required by Advent.APDS.BusinessCommon.dll.
If (!$global:IsBusinessCommonLoaded)
{
    $configPath = "$scriptPath\APDSPowerShell.config"
    If (!(Test-Path $configPath))
    {
        $msg = "$configPath does not exists! This config file is required."
        Throw $msg
    }

    # Load the .config file containing location to the Data Service.
    [System.AppDomain]::CurrentDomain.SetData("APP_CONFIG_FILE", $configPath)
    [Configuration.ConfigurationManager].GetField("s_initState", "NonPublic, Static").SetValue($null, 0)
    [Configuration.ConfigurationManager].GetField("s_configSystem", "NonPublic, Static").SetValue($null, $null)
    ([Configuration.ConfigurationManager].Assembly.GetTypes() | where {$_.FullName -eq "System.Configuration.ClientConfigPaths"})[0].GetField("s_current", "NonPublic, Static").SetValue($null, $null)
    $global:AppSettings = [Configuration.ConfigurationManager]::AppSettings
 
 
    # Get the relative path to the libraries to load.
    $libraryPath = "$scriptPath\..\Extensions"

    If (!(Test-Path $libraryPath))
    {
        $msg = "Cannot load Business Layer because PathExe $libraryPath is invalid. PathExe is specified in $configPath."
        Throw $msg
    }
    
    # Now load assemblies.
    LoadAssembly("$LibraryPath\Castle.Core.dll")
    LoadAssembly("$LibraryPath\Castle.Facilities.WcfIntegration.dll")
    LoadAssembly("$LibraryPath\Castle.Windsor.dll")
    LoadAssembly("$LibraryPath\Advent.CTP.Configuration.Client.dll")
    LoadAssembly("$LibraryPath\Advent.CTP.Configuration.Contracts.dll")
    LoadAssembly("$LibraryPath\System.Spatial.dll")
    LoadAssembly("$LibraryPath\Microsoft.Data.Edm.dll")
    LoadAssembly("$LibraryPath\Microsoft.Data.OData.dll")
    LoadAssembly("$LibraryPath\Microsoft.Data.Services.Client.dll")
    LoadAssembly("$LibraryPath\Advent.PDS.BusinessCommon.dll")
    LoadAssembly("$LibraryPath\Advent.PDS.BusinessCommon.Master.dll")

    $global:IsBusinessCommonLoaded = $true
}

If ($UnitTest){
    $Asserts = @()
    $Asserts += Assert-Equal -TestInput 1 -ExpectedValue 1
    $Asserts += Assert-NotEqual -TestInput 1 -UnexpectedValue 0
    $Asserts += Assert-Is -TestInput 1 -ExpectedType ([int])
    $Asserts += Assert-IsNot -TestInput 1 -UnexpectedType ([String])
    $Asserts += Assert-Contains -TestInput @(1,2,3) -ExpectedItem 1
    $Asserts += Assert-NotContains -TestInput @(1,2,3) -UnexpectedItem 0
    $Asserts += Assert-MemberOf -TestInput 1 -ExpectedInSet @(1,2,3)
    $Asserts += Assert-NotMemberOf -TestInput 0 -UnexpectedInSet @(1,2,3)
    $Asserts += Assert-Like -TestInput "123" -ExpectedWildcardPattern "?2*"
    $Asserts += Assert-NotLike -TestInput "123" -UnexpectedWildcardPattern "??2*"
    $Asserts += Assert-Match -TestInput "123" -ExpectedRegExPattern '^\d{3}$'
    $Asserts += Assert-NotMatch -TestInput "123" -UnexpectedRegExPattern '^\d{5}$'
    $Asserts += Assert-ScriptBlock -TestInput 1,2,3 -ScriptBlock {$_[0] + 1} -ExpectedValue 2
    If ($Asserts | Where-Object -Filter {-not $_}){
        "Unit Test Failed" | Write-LogMessage
    } else {
        "Unit Test Passed" | Write-LogMessage
    }
} else {
    "Unit Test Not Required" | Write-LogMessage -WriteVerbose
}