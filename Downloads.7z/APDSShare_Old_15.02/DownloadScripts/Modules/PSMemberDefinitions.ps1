﻿Function Get-PSMemberDefinitions{
    Param(
        [System.Management.Automation.PSMethod] $PSMember
    )
    $ParameterSets = @()    
    $PSMember.OverloadDefinitions | %{
        $OverloadString = $_ 
        If ($OverloadString -match '^(?<MethodInfo>.*?)(?<ReturnType>[^ ]+) (?<Name>\w+)\((?<Parameters>[^\)]*)\)$'){
            $Matches |%{
                $Match = $_
                $StaticMethod = $Match['MethodInfo'] -match 'Static'
                $Accessibility = $(If ($Match['MethodInfo'] -match 'public|protected|internal|protected internal|private'){$Matches[0]} else {''})
                $ReturnType = $Match['ReturnType']
                $Name = $Match['Name']
                $Parameters = $Match['Parameters'] -split ', ' | %{
                    $ParameterInfo = $_
                    If ($ParameterInfo -match '^(?<ParamsSwitch>Params )?(?<ParameterType>[^ ]+) (?<ParameterName>[^ ]+)$'){                        
                        $Matches | %{
                            $ParameterObject = New-Object PSObject -Property $_ | Select-Object -Property @{Name = 'IsParams'; Expression = {[bool] $_.ParamsSwitch}} , ParameterType, ParameterName
                        }
                        $ParameterObject
                    }
                }
                
                $ParameterSets += New-Object PSObject -Property @{
                    StaticMethod = $StaticMethod
                    Accessibility = $Accessibility
                    ReturnType = $ReturnType
                    Name = $Name
                    Parameters = $Parameters             
                }
            }
        }
    }
    $ParameterSets
}

$scriptPath='\\pqaClsAtLsn\AdvCloudFS\PDSFileTable\APDSShare\CommonScripts'
&("$scriptPath\LoadBusinessLayer.ps1")
$fs = [Advent.PDS.BusinessCommon.Master.FileStreaming]
Get-PSMemberDefinitions -PSMember ($fs::UploadDataFile) | Select-Object -ExpandProperty 'Parameters' | ?{$_.ParameterName -eq 'ParentFileId'} | Select-Object -ExpandProperty 'ParameterType'
