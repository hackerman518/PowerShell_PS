Function Invoke-DecryptFile {  
    [cmdletbinding()]
    Param(
        [string] $PGPExePath,
        [string] $TargetPath,
        [string] $UserName,
        [string] $PassPhrase,
        [string] $Root = (Split-Path $TargetPath -parent)
 	)
    $PGPPath = Split-Path -Path $PGPExePath -Parent
    $RunLog  = "Run.Log"
    $ErrorLog = "Error.Log"
    Push-Location $Root
    $ExeArg = '+batchmode +force +pgppath "{0}" -p "{1}" -o "{2}" -u "{3}" -z "{4}"' -f $PGPPath, $TargetPath, [System.IO.Path]::GetFileNameWithoutExtension($TargetPath), $Username, $PassPhrase
    $ExeArg | Write-Verbose
    $P = Start-Process -FilePath "$PGPExePath" -ArgumentList $ExeArg -RedirectStandardError $ErrorLog -RedirectStandardOutput $RunLog -PassThru -Wait
    $EC = $P.exitcode
    $EC | Write-Verbose
    $P.Dispose()
    Get-Content $ErrorLog | Write-Warning
    Get-Content $RunLog   | Write-Host
    $ErrorLog | Remove-Item -Force
    $RunLog   | Remove-Item -Force
    Pop-Location
    Write-Host $EC
}

Function Invoke-EncryptFile {
    [cmdletbinding()]
    Param (
        [string]   $PGPExePath,
        [string]   $TargetPath,
        [string[]] $UserNameArray,
        [string]   $Root = (Split-Path $TargetPath -parent)
    )
    #PGP.exe Usage summary:
    #To encrypt a plaintext file with recipent's public key, type:
    #   pgp -e textfile her_userid [other userids] (produces textfile.pgp)
    $PGPPath = Split-Path -Path $PGPExePath -Parent
    $RunLog  = "Run.Log"
    $ErrorLog = "Error.Log"
    Push-Location $Root
    $ExeArg = '+batchmode +force -e "{1}" {2} -PGPPATH "{0}"' -f $PGPPath, $TargetPath, (($UserNameArray|%{'"' + $_ + '"'}) -join " ")
    $ExeArg | Write-Verbose
    $P = Start-Process -FilePath "$PGPExePath" -ArgumentList $ExeArg -RedirectStandardError $ErrorLog -RedirectStandardOutput $RunLog -PassThru -Wait
    $EC = $P.exitcode
    $EC | Write-Verbose
    $P.Dispose()
    Get-Content $ErrorLog | Write-Warning
    Get-Content $RunLog   | Write-Host
    $ErrorLog | Remove-Item -Force
    $RunLog   | Remove-Item -Force
    Pop-Location
    Write-Host $EC
}