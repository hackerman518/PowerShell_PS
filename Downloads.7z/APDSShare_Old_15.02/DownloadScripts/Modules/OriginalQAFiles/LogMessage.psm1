Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "C:\AtlasAgent\Program Files\PDSShare\DownloadScripts\Modules\UnitTest.psm1"
}

Function Write-LogMessage {
    [CmdletBinding(DefaultParametersetName = "WriteHost")]
    Param(
        [parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [alias("Object")] [Object] $Message,
        [string] $LogPath = $Global:DownloadLogPath,
        [Parameter(ParameterSetName = "WriteDebug")]   [switch] $WriteDebug,
        [Parameter(ParameterSetName = "WriteError")]   [switch] $WriteError,
        [Parameter(ParameterSetName = "WriteVerbose")] [switch] $WriteVerbose,
        [Parameter(ParameterSetName = "WriteWarning")] [switch] $WriteWarning
    )
    Begin{
        If ($LogPath -and (-not (Test-Path -Path $LogPath))){
            "Creating $LogPath" | Write-Verbose -Verbose
            New-Item -Path $LogPath -ItemType File
        }
    } Process {
        Switch ($PSCmdlet.ParameterSetName){
            "WriteDebug" {
                Write-Debug -Message $Message   
            }
            "WriteError" {
                Write-Error -Message $Message
                If ($LogPath){
                    Add-Content -Path $LogPath -value $Message
                }
            }
            "WriteVerbose" {
                Write-Verbose -Message $Message 
            }
            "WriteWarning" {
                Write-Warning -Message $Message
                If ($LogPath){
                    Add-Content -Path $LogPath -value $Message
                }
            }
            default {
                Write-Host -Object $Message
                If ($LogPath){
                    Add-Content -Path $LogPath -value $Message
                }
            }
        }
        
    }
    End{}
}

If ($UnitTest){
    $Asserts = @()
    $Asserts += Assert-Equal -TestInput 1 -ExpectedValue 1
    $Asserts += Assert-NotEqual -TestInput 1 -UnexpectedValue 0
    $Asserts += Assert-Is -TestInput 1 -ExpectedType ([int])
    $Asserts += Assert-IsNot -TestInput 1 -UnexpectedType ([String])
    $Asserts += Assert-Contains -TestInput @(1,2,3) -ExpectedItem 1
    $Asserts += Assert-NotContains -TestInput @(1,2,3) -UnexpectedItem 0
    $Asserts += Assert-MemberOf -TestInput 1 -ExpectedInSet @(1,2,3)
    $Asserts += Assert-NotMemberOf -TestInput 0 -UnexpectedInSet @(1,2,3)
    $Asserts += Assert-Like -TestInput "123" -ExpectedWildcardPattern "?2*"
    $Asserts += Assert-NotLike -TestInput "123" -UnexpectedWildcardPattern "??2*"
    $Asserts += Assert-Match -TestInput "123" -ExpectedRegExPattern '^\d{3}$'
    $Asserts += Assert-NotMatch -TestInput "123" -UnexpectedRegExPattern '^\d{5}$'
    $Asserts += Assert-ScriptBlock -TestInput 1,2,3 -ScriptBlock {$_[0] + 1} -ExpectedValue 2
    If ($Asserts | ?{-not $_}){
        "Unit Test Failed" | Write-Host
    } else {
        "Unit Test Passed" | Write-Host
    }
} else {
    "Unit Test Not Required" | Write-Verbose
}