Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "I:\APDSShare - Phase 2\DownloadScripts\Modules\UnitTest.psm1"
}

#Requires -Modules LogMessage

Function Invoke-FixedLengthUtility{
    [CmdletBinding()] 
    Param(
        [string] $FixedLengthUtilityPath,
        [string] $FixedLengthUtilityLogDirectory = (Split-Path -Path $InputFilePath -Parent),
        [string] $FixedLengthIniPath,
        [string] $InputFilePath,
        [string] $OutputFilePath = $InputFilePath + ".FixedLength",
        [string] $IniFileType,
        [switch] $PassThru
    )
    $File= $FixedLengthUtilityPath 
    $Args = @(
        "-i" + (Get-DOSPathFromLongName -path $InputFilePath), 
        "-o" + (Get-DOSPathFromLongName -path $OutputFilePath), 
        "-f" + (Get-DOSPathFromLongName -path $FixedLengthIniPath), 
        "-l" + (Get-DOSPathFromLongName -path $FixedLengthUtilityLogDirectory),
        "-s" + $IniFileType
    )
    $FixedLengthUtilityLogPath = $FixedLengthUtilityLogDirectory + '\FixedLength.err'
    
    "Running:" | Write-LogMessage
    $File + " " +  ($Args -join " ") | Write-LogMessage

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo.FileName = $File
    $p.StartInfo.Arguments = $Args
    $p.StartInfo.UseShellExecute = $false
    #$p.StartInfo.RedirectStandardOutput = true;
    #$p.StartInfo.RedirectStandardError = true;

    # Must pipe start to null otherwise True will be written to the Standard Output
    $p.Start() > $null
    $p.WaitForExit()
    $errorCode = $p.ExitCode
    $p.Dispose()
        
    If (test-path $FixedLengthUtilityLogPath){
        "Fixed Length Log Results:" | Write-LogMessage
        (((Get-Content -Path $FixedLengthUtilityLogPath | ?{$_}) -join "`n") -split "--------------------------------------------------------------------------------")[-1].trim() | Write-LogMessage
    } else {
        $FixedLengthUtilityLogPath + " was not created" | Write-LogMessage -WriteWarning
    }
    If (test-path $OutputFilePath){
        If ($Passthru){
            return Get-item $OutputFilePath
        }
    } else {
        $OutputFilePath + " was not created" | Write-LogMessage -WriteError
    }
}

If ($UnitTest){
    $Asserts = @()
    $Asserts += Assert-Equal -TestInput 1 -ExpectedValue 1
    $Asserts += Assert-NotEqual -TestInput 1 -UnexpectedValue 0
    $Asserts += Assert-Is -TestInput 1 -ExpectedType ([int])
    $Asserts += Assert-IsNot -TestInput 1 -UnexpectedType ([String])
    $Asserts += Assert-Contains -TestInput @(1,2,3) -ExpectedItem 1
    $Asserts += Assert-NotContains -TestInput @(1,2,3) -UnexpectedItem 0
    $Asserts += Assert-MemberOf -TestInput 1 -ExpectedInSet @(1,2,3)
    $Asserts += Assert-NotMemberOf -TestInput 0 -UnexpectedInSet @(1,2,3)
    $Asserts += Assert-Like -TestInput "123" -ExpectedWildcardPattern "?2*"
    $Asserts += Assert-NotLike -TestInput "123" -UnexpectedWildcardPattern "??2*"
    $Asserts += Assert-Match -TestInput "123" -ExpectedRegExPattern '^\d{3}$'
    $Asserts += Assert-NotMatch -TestInput "123" -UnexpectedRegExPattern '^\d{5}$'
    $Asserts += Assert-ScriptBlock -TestInput 1,2,3 -ScriptBlock {$_[0] + 1} -ExpectedValue 2
    If ($Asserts | ?{-not $_}){
        "Unit Test Failed" | Write-Host
    } else {
        "Unit Test Passed" | Write-Host
    }
} else {
    "Unit Test Not Required" | Write-Verbose
}