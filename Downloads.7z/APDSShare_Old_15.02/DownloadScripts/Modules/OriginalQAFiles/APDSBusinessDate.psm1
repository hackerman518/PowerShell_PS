[cmdletbinding()]
Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "$ModulesDirectory\UnitTest.psm1"
}

#Requires -Modules LogMessage

Function Get-FileHeader{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)] [String] $FilePath,
        [int] $HeaderLineNumber = 1
    )
    try {
        Start-FunctionDebugLog
        #the join/split forces a text without line breaks to be treated as an array of one item instead of an array of characters
        ((Get-Content -Path $FilePath -TotalCount $HeaderLineNumber) -join "`n" -split "`n")[$HeaderLineNumber - 1]
    } Catch {
    	#Log unhandled errors
        "Error Detected" + $_.InvocationInfo.PositionMessage | Write-LogMessage
        $_.Exception.Message | Write-LogMessage
        break
    } Finally {
       "End of " + $MyInvocation.MyCommand | Write-LogMessage -WriteVerbose
       Stop-FunctionDebugLog
    }
}

Function Get-FileTrailer{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)] [String] $FilePath,
        [int] $TrailerLineNumberFromEnd = 1
    )
    try {
        Start-FunctionDebugLog
        #the join/split forces a text without line breaks to be treated as an array of one item instead of an array of characters
        ((Get-Content -Path $FilePath | Select-Object -Last $TrailerLineNumberFromEnd) -join "`n" -split "`n")[0]
    } Catch {
    	#Log unhandled errors
        "Error Detected" + $_.InvocationInfo.PositionMessage | Write-LogMessage
        $_.Exception.Message | Write-LogMessage
        break
    } Finally {
       Stop-FunctionDebugLog
    }
}

Function Convert-StringToBusinessDate{
    [CmdletBinding()]
    Param(
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [String] $StringToConvert,
        $RegexInput,
        $RegexReplacement,
        $DateFormat
    )
    Begin{
        Start-FunctionDebugLog
    }
    Process{
        try {
            $DateString = ([Regex]::Match($StringToConvert, $RegexInput) -replace $RegexInput, $RegexReplacement).trim()
            "'" + $DateString + "'"| Write-LogMessage -WriteVerbose -Verbose
            Try {
                [System.Datetime]::ParseExact($DateString, $DateFormat, [IFormatProvider] [System.Globalization.CultureInfo] 'en-US')
            } Catch {
                'Unable to parse: ' + $DateString + ' as ' + $DateFormat | Write-Warning
                [System.Datetime] 0 
            }
        } Catch {
        	#Log unhandled errors
            "Error Detected" + $_.InvocationInfo.PositionMessage | Write-LogMessage
            $_.Exception.Message | Write-LogMessage
            break
        }
    } End {
       Stop-FunctionDebugLog
    }
}

Function Get-BusinessDate {
    [CmdletBinding(DefaultParametersetName = "UseFileName")]
    Param (
	    [Parameter(Mandatory=$True,ValueFromPipeline=$True)] 
        [alias("Path")] 
        [string] $FilePath,

        [Parameter(ParameterSetName = "UseDelimitedData")]
        [Switch] $UseDelimitedData,
        
        [Parameter(ParameterSetName = "UseFileName")] 
        [Switch] $UseFileName,
        
        [Parameter(ParameterSetName = "UseHeader")] 
        [Switch] $UseHeader,
        [Parameter(ParameterSetName = "UseHeader")]
        [int] $HeaderLineNumber = 1,
        
        [Parameter(ParameterSetName = "UseTrailer")] 
        [Switch] $UseTrailer,
        [Parameter(ParameterSetName = "UseTrailer")] 
        [int] $TrailerLineNumberFromEnd = 1,
        
        [Parameter(ParameterSetName = "UseCustomScript")] 
        [Switch] $UseCustomScript,
        [Parameter(Mandatory=$True, ParameterSetName = "UseCustomScript")] 
        [String] $CustomScriptPath,
        [Parameter(Mandatory=$True, ParameterSetName = "UseCustomScript")] 
        [Hashtable] $CustomScriptArguments,
        
        [Parameter(ParameterSetName = "UseToday")] 
        [Switch] $UseToday,
        
        [Parameter(ParameterSetName = "UseYesterday")] 
        [Switch] $UseYesterday,
        
        [Parameter(ParameterSetName = "UseLastWeekDay")] 
        [Switch] $UseLastWeekDay,
        
        [Parameter(ParameterSetName = "UseToday")]
        [Parameter(ParameterSetName = "UseYesterday")]
        [Parameter(ParameterSetName = "UseLastWeekDay")] 
        [DateTime] $InputDate = (get-date),
        
        [Parameter(ParameterSetName = "UseDelimitedData")]
        [Parameter(ParameterSetName = "UseFileName")] 
        [Parameter(ParameterSetName = "UseHeader")] 
        [Parameter(ParameterSetName = "UseTrailer")]
        [String] $RegexInput = '(\w{2})(\d{6})(.{4})',

        [Parameter(ParameterSetName = "UseDelimitedData")]
        [Parameter(ParameterSetName = "UseFileName")] 
        [Parameter(ParameterSetName = "UseHeader")] 
        [Parameter(ParameterSetName = "UseTrailer")]
        [String] $RegexReplacement = '$2',

        [Parameter(ParameterSetName = "UseDelimitedData")]
        [Parameter(ParameterSetName = "UseFileName")] 
        [Parameter(ParameterSetName = "UseHeader")] 
        [Parameter(ParameterSetName = "UseTrailer")]
        [String] $DateFormat = "MMddyy",

        [Parameter(ParameterSetName = "UseDelimitedData")]
        [Parameter(ParameterSetName = "UseHeader")] 
        [Parameter(ParameterSetName = "UseTrailer")]
        [String] $Delimiter="",
        [Parameter(ParameterSetName = "UseHeader")] 
        [Parameter(ParameterSetName = "UseTrailer")]
        [int] $ColumnNumber = 0,
        
        [Parameter(ParameterSetName = "UseDelimitedData")]
        [String] $ColumnName = "",
        [Parameter(ParameterSetName = "UseDelimitedData")]
        [int] $ColumnLineNumber = 1,
        [Parameter(ParameterSetName = "UseDelimitedData")]
        [int] $SampleDataLineNumber = 2,
        [Parameter(ParameterSetName = "UseDelimitedData")]
        [switch] $CaseInsensitive
    )
    Start-FunctionDebugLog
    Switch ($PSCmdlet.ParameterSetName){
        "UseFileName" {
            #Gets the file name
            $StringToConvert = Split-Path -Path $FilePath -leaf
            #Extracts business date using a regex replace and a ParseExact
            Return Convert-StringToBusinessDate -StringToConvert $StringToConvert -RegexInput $RegexInput -RegexReplacement $RegexReplacement -DateFormat $DateFormat
        }
        "UseDelimitedData" {
            #Get Column headers and find the business date column
            $ColumnLine = Get-FileHeader -FilePath $FilePath -HeaderLineNumber $ColumnLineNumber
            If ($CaseInsensitive){
                $ColumnIndexOfBusinessDate = [array]::indexof($ColumnLine.tolower() -split $Delimiter.tolower(), $ColumnName.tolower())
            } else {
                $ColumnIndexOfBusinessDate = [array]::indexof($ColumnLine -split $Delimiter, $ColumnName)
            } 
            #Gets a data row and splits out the business date column
            $SampleDataLine = Get-FileHeader -FilePath $FilePath -HeaderLineNumber $SampleDataLineNumber
            $StringToConvert = ($FirstDataLine -split $Delimiter)[$ColumnIndexOfBusinessDate]

            #Extracts business date using a regex replace and a ParseExact
            Return Convert-StringToBusinessDate -StringToConvert $StringToConvert -RegexInput $RegexInput -RegexReplacement $RegexReplacement -DateFormat $DateFormat
        }
        "UseHeader" {
            #Gets the first line of the file
            $StringToConvert = Get-FileHeader -FilePath $FilePath -HeaderLineNumber $HeaderLineNumber
            #Use the Delimiter and ColumnNumber parameters to get the correct column of a delimited line (counting first column as 1 not 0)
            If ($Delimiter -and $ColumnNumber){
                $StringToConvert = ($StringToConvert -split $Delimiter)[$ColumnNumber - 1]
            }
            #Extracts business date using a regex replace and a ParseExact
            Return Convert-StringToBusinessDate -StringToConvert $StringToConvert -RegexInput $RegexInput -RegexReplacement $RegexReplacement -DateFormat $DateFormat
        }
        "UseTrailer" {
            #Gets the last line of the file
            $StringToConvert = Get-FileTrailer -FilePath $FilePath -TrailerLineNumberFromEnd $TrailerLineNumberFromEnd
            #Use the Delimiter and ColumnNumber parameters to get the correct column of a delimited line (counting first column as 1 not 0)
            If ($Delimiter -and $ColumnNumber){
                $StringToConvert = ($StringToConvert -split $Delimiter)[$ColumnNumber - 1]
            }
            #Extracts business date using a regex replace and a ParseExact
            Return Convert-StringToBusinessDate -StringToConvert $StringToConvert -RegexInput $RegexInput -RegexReplacement $RegexReplacement -DateFormat $DateFormat
        }
        "UseCustomScript" {
            . $CustomScriptPath -FilePath $FilePath @CustomScriptArguments
        }
        "UseToday" {
            Return $InputDate.date
        }
        "UseYesterday" {
            Return  $InputDate.date.AddDays(-1)
        }
        "UseLastWeekDay" {
            Switch ($InputDate.DayOfWeek){
                "Sunday" {
                    Return $InputDate.date.AddDays(-2)
                }
                "Monday" {
                    Return $InputDate.date.AddDays(-3)
                }
                Default  {
                    Return $InputDate.date.AddDays(-1)
                }
            }
        }
        default {}
    }
    Stop-FunctionDebugLog
}

If ($UnitTest){
    $Asserts = @()
    $Asserts += Assert-Equal -TestInput 1 -ExpectedValue 1
    $Asserts += Assert-NotEqual -TestInput 1 -UnexpectedValue 0
    $Asserts += Assert-Is -TestInput 1 -ExpectedType ([int])
    $Asserts += Assert-IsNot -TestInput 1 -UnexpectedType ([String])
    $Asserts += Assert-Contains -TestInput @(1,2,3) -ExpectedItem 1
    $Asserts += Assert-NotContains -TestInput @(1,2,3) -UnexpectedItem 0
    $Asserts += Assert-MemberOf -TestInput 1 -ExpectedInSet @(1,2,3)
    $Asserts += Assert-NotMemberOf -TestInput 0 -UnexpectedInSet @(1,2,3)
    $Asserts += Assert-Like -TestInput "123" -ExpectedWildcardPattern "?2*"
    $Asserts += Assert-NotLike -TestInput "123" -UnexpectedWildcardPattern "??2*"
    $Asserts += Assert-Match -TestInput "123" -ExpectedRegExPattern '^\d{3}$'
    $Asserts += Assert-NotMatch -TestInput "123" -UnexpectedRegExPattern '^\d{5}$'
    $Asserts += Assert-ScriptBlock -TestInput 1,2,3 -ScriptBlock {$_[0] + 1} -ExpectedValue 2
    If ($Asserts | ?{-not $_}){
        "Unit Test Failed" | Write-Host
    } else {
        "Unit Test Passed" | Write-Host
    }
} else {
    "Unit Test Not Required" | Write-Verbose
}