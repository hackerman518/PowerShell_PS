Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "C:\AtlasAgent\Program Files\PDSShare\DownloadScripts\Modules\UnitTest.psm1"
}


#Requires -Modules WriteLogMessage

Function Invoke-FileTransfer {
    <#
    	.Synopsis
        Downloads files from a given FTP site and dumps it into
    	a specified folder.
    #>
    [CmdletBinding(SupportsShouldProcess = $True)]
    Param(
        [Parameter(Mandatory=$true)] [string] $ExeShareLocation,
        [Parameter(Mandatory=$true)] [string] $FtpSettingId,
        [Parameter(Mandatory=$true)] [string] $workflowInstanceID,
        [Parameter(Mandatory=$true)] [string] $TempFolderPath
    )
    Try {
        "Beginning of " + $MyInvocation.Line | Write-LogMessage -WriteVerbose -Verbose:$PSBoundParameters['Verbose']  
        "Downloading FTP Files" | Write-LogMessage
        
        # FileTransfer.exe will create the folder provided in $outPath if one doesn't already exists.
        $cmd = Join-Path -Path $ExeShareLocation -ChildPath "FileTransfer.exe"
    	$params = "-f{0} -w{1} -o{2} -true" -f $ftpSettingId, $workflowInstanceID, (Split-Path -path $TempFolderPath -Leaf)

    	# Note we are using System.Diagnostics.Process to invoke the executable instead 
    	# of the powershell command start-process because start-process throws UAC warnings
    	# that interferes with the executable.
    	$p = New-Object System.Diagnostics.Process
        $p.StartInfo.FileName = $cmd
        $p.StartInfo.Arguments = $params
        $p.StartInfo.UseShellExecute = $false
        $p.StartInfo.WorkingDirectory = (Split-Path -path $TempFolderPath -Parent)
        $p.StartInfo.RedirectStandardOutput = $true;
        $p.StartInfo.RedirectStandardError = $true;
        
        "Running: " + $Cmd + " " + $params | Write-LogMessage -WriteVerbose -Verbose:$PSBoundParameters['Verbose']
        # Must pipe start to null otherwise True will be written to the Standard Output
        $p.Start() | Out-Null
        
        do {
            Start-Sleep -Seconds 1
            If ($p.StandardOutput.peek()){
                $p.StandardOutput.ReadLine() |?{$_}|Write-LogMessage -WriteVerbose -Verbose:$PSBoundParameters['Verbose']
            }
        }
        until ($p.HasExited)

        If (-not $p.StandardOutput.EndOfStream){
                $p.StandardOutput.ReadToEnd() |?{$_}|Write-LogMessage -WriteVerbose -Verbose:$PSBoundParameters['Verbose']
        }
        If (-not $p.StandardError.EndOfStream){
            $p.StandardError.ReadToEnd() |?{$_}|Write-LogMessage -WriteWarning
        }
        $errorCode = $p.ExitCode
        $p.Close()
        $p.Dispose()

        # Zero means successful, anything else means an error occurred.
        if ($errorCode -gt 0) {
            Write-LogMessage -WriteError -Message "DownloadFTPFile encountered an error."
        } else {
            Write-LogMessage -Message "FTP Download Completed without an error."
        }
    } Catch {
    	#Log unhandled errors
        "Error Detected " + $_.InvocationInfo.PositionMessage |Write-LogMessage -WriteWarning
        $_.Exception.Message | Write-LogMessage -WriteWarning
        break
    } Finally {
       "End of " + $MyInvocation.MyCommand | Write-LogMessage -WriteVerbose -Verbose:$PSBoundParameters['Verbose']
    }
}

If ($UnitTest){
    $Asserts = @()
    $Asserts += Assert-Equal -TestInput 1 -ExpectedValue 1
    $Asserts += Assert-NotEqual -TestInput 1 -UnexpectedValue 0
    $Asserts += Assert-Is -TestInput 1 -ExpectedType ([int])
    $Asserts += Assert-IsNot -TestInput 1 -UnexpectedType ([String])
    $Asserts += Assert-Contains -TestInput @(1,2,3) -ExpectedItem 1
    $Asserts += Assert-NotContains -TestInput @(1,2,3) -UnexpectedItem 0
    $Asserts += Assert-MemberOf -TestInput 1 -ExpectedInSet @(1,2,3)
    $Asserts += Assert-NotMemberOf -TestInput 0 -UnexpectedInSet @(1,2,3)
    $Asserts += Assert-Like -TestInput "123" -ExpectedWildcardPattern "?2*"
    $Asserts += Assert-NotLike -TestInput "123" -UnexpectedWildcardPattern "??2*"
    $Asserts += Assert-Match -TestInput "123" -ExpectedRegExPattern '^\d{3}$'
    $Asserts += Assert-NotMatch -TestInput "123" -UnexpectedRegExPattern '^\d{5}$'
    $Asserts += Assert-ScriptBlock -TestInput 1,2,3 -ScriptBlock {$_[0] + 1} -ExpectedValue 2
    If ($Asserts | ?{-not $_}){
        "Unit Test Failed" | Write-Host
    } else {
        "Unit Test Passed" | Write-Host
    }
} else {
    "Unit Test Not Required" | Write-Verbose
}