﻿[cmdletbinding()]
Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "$ModulesDirectory\UnitTest.psm1"
}
#Based on http://www.tellingmachine.com/post/Converting-file-names-to-the-DOS-83-format-using-PowerShell.aspx

$Code =
@"
using System;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Globalization;
 
public class FileSystemHelper
{
  [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
  private static extern int GetShortPathName(
      [MarshalAs(UnmanagedType.LPTStr)] string path,
      [MarshalAs(UnmanagedType.LPTStr)] StringBuilder shortPath,
      int shortPathLength);
 
  [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
  [return: MarshalAs(UnmanagedType.U4)]
  private static extern int GetLongPathName(
      [MarshalAs(UnmanagedType.LPTStr)]
            string lpszShortPath,
      [MarshalAs(UnmanagedType.LPTStr)]
            StringBuilder lpszLongPath,
      [MarshalAs(UnmanagedType.U4)]
            int cchBuffer);
 
  public static string GetShortPathName(string path)
  {
    StringBuilder shortPath = new StringBuilder(500);
    if (0 == GetShortPathName(path, shortPath, shortPath.Capacity))
    {
      if (Marshal.GetLastWin32Error() == 2)
      {
        throw new Exception("File does not exist!");
      }
      else
      {
        throw new Exception("GetLastError returned: " + Marshal.GetLastWin32Error());
      }
    }
    return shortPath.ToString();
  }
 
 
  public static string GetLongPathName(string shortPath)
  {
    if (String.IsNullOrEmpty(shortPath))
    {
      return shortPath;
    }
 
    StringBuilder builder = new StringBuilder(255);
    int result = GetLongPathName(shortPath, builder, builder.Capacity);
    if (result > 0 && result < builder.Capacity)
    {
      return builder.ToString(0, result);
    }
    else
    {
      if (result > 0)
      {
        builder = new StringBuilder(result);
        result = GetLongPathName(shortPath, builder, builder.Capacity);
        return builder.ToString(0, result);
      }
      else
      {
        throw new FileNotFoundException(
        string.Format(
        CultureInfo.CurrentCulture,
        null,
        shortPath),
        shortPath);
      }
    }
  }
}
"@     
Add-Type -TypeDefinition $Code

#Function Get-ShortName {
#    [cmdletbinding()]
#    Param(
#        $FullName
#    )
#    If (Test-Path ($FullName)){
#        If ((Get-Item -Path $FullName).PSIsContainer){
#            (New-Object -ComObject Scripting.FileSystemObject).getfolder($FullName).ShortPath
#        } Else {
#            (New-Object -ComObject Scripting.FileSystemObject).getfile($FullName).ShortPath
#        }
#    } else {
#        ""
#    }
#}

function Get-DOSPathFromLongName{
    Param(
        [string] $Path
    )
    $FileName =  Split-Path -Path $Path -Leaf
    $FolderName =  Split-Path -Path $Path -Parent

    If (test-path -Path $Path) {
        Try{
            [FileSystemHelper]::GetShortPathName($Path)
        } catch {
            "Unable to determine DOS Shortname of {0}" -f $Path | Write-LogMessage -WriteWarning
            $Path            
        }
    } elseif (test-path -Path $FolderName){
        "File does not exist.  Only shortening directory name..." | Write-LogMessage -WriteVerbose
        Try{
            [FileSystemHelper]::GetShortPathName($FolderName) + "\" + $FileName
        } catch {
            "Unable to determine DOS Shortname of {0}" -f $FolderName | Write-LogMessage -WriteWarning
            $Path            
        }
    } else {
        "Parent folder of {0} does not exist" -f $Path | Write-LogMessage -WriteWarning
        $Path
    }
}
 
function Get-LongNameFromDOSPath{
    Param(
        [string] $Path
    )
    $FileName =  Split-Path -Path $Path -Leaf
    $FolderName =  Split-Path -Path $Path -Parent
    if (test-path -Path $FolderName){
        [FileSystemHelper]::GetLongPathName($FolderName) + "\" + $FileName
    } else {
        "Parent folder does not exist" |Write-LogMessage -WriteWarning
        $Path
    }
}

If ($UnitTest){
    $TempDir = "$ModulesDirectory\UnitTestData"
    If (-not (Test-Path -path $TempDir)){
        New-Item -Path $TempDir -ItemType Directory
    }
    $TestFile = "$TempDir\Test File With Spaces.txt"
    If (-not (Test-Path -path $TestFile)){
        New-Item -Path $TestFile -ItemType File
    }
    $NonexistentFile = "$TempDir\This File Should Not Exist.txt" 
    If (Test-Path -path $NonexistentFile){
        Remove-Item -Path $NonexistentFile -Force
    }
        
    $Asserts = @()
    $Asserts += Assert-Equal -TestInput (Get-LongNameFromDOSPath -Path (Get-DOSPathFromLongName -Path $TestFile)) -ExpectedValue $TestFile
    $Asserts += Assert-Equal -TestInput (Get-LongNameFromDOSPath -Path (Get-DOSPathFromLongName -Path $NonexistentFile)) -ExpectedValue $NonexistentFile
    $Asserts += Assert-Equal -TestInput (Test-Path -Path (Get-DOSPathFromLongName -Path $TestFile)) -ExpectedValue $true
    $Asserts += Assert-Equal -TestInput (Test-Path -Path (Get-LongNameFromDOSPath -Path $TestFile)) -ExpectedValue $true
    $Asserts += Assert-NotMatch -TestInput (Get-DOSPathFromLongName -Path $TestFile) -UnexpectedRegExPattern '\s'
    $NonexistentFileLong = Get-LongNameFromDOSPath -Path $NonexistentFile
    $NonexistentFileDOS  = Get-DOSPathFromLongName -Path $NonexistentFile
    New-Item -Path $NonexistentFile -ItemType File
    $Asserts += Assert-Equal -TestInput (Test-Path -Path $NonexistentFileLong) -ExpectedValue $true
    $Asserts += Assert-Equal -TestInput (Test-Path -Path $NonexistentFileDOS) -ExpectedValue $true    
    Remove-Item -Path $NonexistentFile -Force
    
    If ($Asserts | Where-Object -Filter {-not $_}){
        "Unit Test Failed" | Write-LogMessage 
    } else {
        "Unit Test Passed" | Write-LogMessage 
    }
} else {
    "Unit Test Not Required" | Write-LogMessage -WriteVerbose
}