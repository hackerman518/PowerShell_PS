﻿$TypeVersionTable = @(
#Advent.APDS.BusinessCommon
@{
    BusinessLayer = 'Advent.APDS.BusinessCommon.BusinessLayer'
    PowerShell = 'Advent.APDS.BusinessCommon.PowerShell'
    FileStreaming = 'Advent.APDS.BusinessCommon.FileStreaming'
    Utility = 'Advent.APDS.BusinessCommon.Utility'
    JobCommunicator = 'Advent.APDS.BusinessCommon.JobCommunicator'
    DataFileInfo = 'Advent.APDS.BusinessCommon.APDSDataServiceProxy.DataFileInfo'
    WorkflowInstance = 'Advent.APDS.BusinessCommon.APDSDataServiceProxy.WorkflowInstance'
    FTPAccount = 'Advent.APDS.BusinessCommon.APDSDataServiceProxy.FTPAccount'
    Job = 'Advent.APDS.BusinessCommon.APDSDataServiceProxy.Job'
    Operation = 'Advent.APDS.BusinessCommon.APDSDataServiceProxy.Operation'
},
#Advent.PDS.BusinessCommon(.Master)
@{
    BusinessLayer = 'Advent.PDS.BusinessCommon.Master.BusinessLayer'
    PowerShell = 'Advent.PDS.BusinessCommon.Master.PowerShell'
    FileStreaming = 'Advent.PDS.BusinessCommon.Master.FileStreaming'
    Utility = 'Advent.PDS.BusinessCommon.Master.Utility'
    JobCommunicator = 'Advent.PDS.BusinessCommon.Master.JobCommunicator'
    DataFileInfo = 'Advent.PDS.BusinessCommon.DataServiceProxy.DataFileInfo'
    WorkflowInstance = 'Advent.PDS.BusinessCommon.DataServiceProxy.WorkflowInstance'
    FTPAccount = 'Advent.PDS.BusinessCommon.DataServiceProxy.FTPAccount'
    Job = 'Advent.PDS.BusinessCommon.DataServiceProxy.Job'
    Operation = 'Advent.PDS.BusinessCommon.DataServiceProxy.Operation'
}
)

Function Check-Type{
    Param (
        [Parameter(ParameterSetName = "TypeShortName")][String] $TypeShortName,
        [Parameter(ParameterSetName = "TypeFullName")][String] $TypeFullName,
        [String] $AssemblyName,
        [Switch] $PassThru
    )
    $Matches = @() 
    [AppDomain]::CurrentDomain.GetAssemblies() | ?{-not $AssemblyName -or ($_.getname().name) -eq $AssemblyName} | %{
        $Assembly = $_
        Switch ($PsCmdlet.ParameterSetName) { 
            "TypeFullName"  {$Match = $Assembly.gettype($TypeFullName)} 
            "TypeShortName"  {$Match = $Assembly.gettypes() | ?{$_.name -eq $TypeShortName}} 
        } 
        If ($Match){
            $Matches += $Match
        }
    }
    If ($PassThru){
        $Matches
    } else {
        $Matches -as [bool]
    }
}

Function Coalesce-ScriptBlock{
    Param(
        [ScriptBlock[]] $inputs
    )
    ForEach ($Input in $Inputs){
        $ScriptResult = Invoke-Command -ScriptBlock $Input
        If($ScriptResult){break}
    }
    $ScriptResult
}

$TypeNames = @()
$TypeVersionTable | %{
    $TypeNames += $_.keys
}
$TypeNames = $TypeNames | Sort-Object -Unique

$TypeNames | %{
    $TypeName = $_
    $Checklist = $TypeVersionTable | %{$_.$TypeName} | ?{$_} | %{[scriptblock]::Create('Check-Type -TypeFullName ''' + $_ + ''' -PassThru')}
    $Checklist += {Throw "Unable to locate type for $TypeName"}
    $APDSTypeValue = Coalesce-ScriptBlock -inputs $CheckList
    
    Set-Variable -Name "APDSType_$TypeName" -Value $APDSTypeValue
}