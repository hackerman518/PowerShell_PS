param
(
    [Parameter(Mandatory=$true)][string]$filename
)

Write-Host "Begin conversion script $scriptName."
Try
{
    # Import functions to the current session.
    $scriptPath = split-path -parent $PSCommandPath	 # Get this script's full path.
    . "$scriptPath\APDSDownloadFunctionsLib.ps1"

    # Use this for local execution for developers
    #$load = "$scriptPath\..\..\Backend\PowerShellScripts\LoadBusinessLayer.ps1"

    # Make sure the above $load is commented out and bottom one uncommented before check-in.
    $load = "$scriptPath\..\CommonScripts\LoadBusinessLayer.ps1"

    # Execute the following script to load dependencies which must be in the relative path as this script.
    & $load

    $scriptName = $MyInvocation.MyCommand.Name
    $firmID = 5022
    $workflowInstanceId = 15046
    
    <#
    $fi = New-Object IO.FileInfo $filename
    $dfm = New-Object Advent.PDS.DataAccessLayer.DataFileMetadata
    $dfm.FileTypeId = 3
    $dfm.FirmId = $firmID
    $dfm.Name = $fi.Name
    $dfm.ParentFileId = 284351
    $dfm.SizeBytes = $fi.Length
    $dfm.WorkflowInstanceId = $workflowInstanceId
    $dfm.BusinessDate = (Get-Date -format MM/dd/yyyy)
    $dfm.FileStatusId = 3
    $fileStream = New-Object IO.FileStream $filename ,'Open','Read'

    [Advent.PDS.DataAccessLayer.DataFileStream]::SaveDataFile($dfm, $fileStream)
    

    exit
    #>

    Try
	{
        # FileType 3 is "Pre-Translated"
        # FileStatus 3 is "Ready for processing"
        $fileId = RegisterFTPFile $filename 3 284351 (Get-Date -format MM/dd/yyyy) 3
    }
    Catch
    {
        Write-Error "Uploading file to db encountered an error. File id:" 284351
        
            # Wait one second to allow the agent job runner to encapsulate all information written to standard error as one block.
        Wait-Event -Timeout 1
        continue
    }

    if ($fileId -gt 0)
    {
        Write-Host "File: $filename uploaded successfully with file ID:" $fileId
    }
    else
    {
        Write-Error "File: $filename failed to uploaded."
            
        # Wait one second to allow the agent job runner to encapsulate all information written to standard error as one block.
        Wait-Event -Timeout 1
    }
}
Catch [System.Exception]
{
    Write-Error $_.Exception
}
Finally
{
    # Remove the temporary folder and all items from it.
    #If ($outPath -ne $null)
    #{
    #    If(Test-Path $outPath)
    #    {
    #        Remove-Item .\$outPath -Force -Recurse
    #    }
    #}

    Write-Host "End of upload script $scriptName."
    Write-Host "--------------------------------------------------------"
}