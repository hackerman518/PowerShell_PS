﻿Import-Module \\PQACLSAtLsn\AdvCloudFS\PDSFileTable\APDSShare\DownloadScripts\Modules\LogMessage.psm1 -Force
Import-Module \\PQACLSAtLsn\AdvCloudFS\PDSFileTable\APDSShare\DownloadScripts\Modules\FileNameConversion.psm1 -Force

Function Get-ShortName{
    BEGIN { 
        $fso = New-Object -ComObject Scripting.FileSystemObject 
    }
    PROCESS {
        If ($_.psiscontainer) {
            $fso.getfolder($_.fullname).ShortName
        } ELSE {
            $fso.getfile($_.fullname).ShortName
        } 
    } 
}
        $FixedIni = "\\PQACLSAtLsn\AdvCloudFS\PDSFileTable\APDSShare\Cookers\4AD_fixed.ini"
        $FixedIni | Get-Item | Get-ShortName
        
        [FileSystemHelper]::GetShortPathName("\\PQACLSAtLsn.ctp.dev.com\AdvCloudFS\PDSFileTable\APDSShare\Cookers\4AD_fixed.ini")
        [FileSystemHelper]::GetShortPathName("\\PQACLSAtLsn.ctp.dev.com\AdvCloudFS\PDSFileTable\APDSShare\Cookers")
        [FileSystemHelper]::GetShortPathName("\\PQACLSAtLsn.ctp.dev.com\AdvCloudFS\PDSFileTable\APDSShare")
        [FileSystemHelper]::GetShortPathName("\\PQACLSAtLsn.ctp.dev.com\AdvCloudFS\PDSFileTable")
        [FileSystemHelper]::GetShortPathName("\\PQACLSAtLsn.ctp.dev.com\AdvCloudFS")
        [FileSystemHelper]::GetShortPathName($FixedIni)
