﻿<#
    APDSDownloadFunctionsLib.ps1
  
    This module contains a set of common functions used by the download scripts.
 #>

 <#
    This function will give the corresponding Axys File Type for the given AXML file name.
#>
Function APXFileTypeMapping
{
    param
    (
        [Parameter(Mandatory=$true)][string]$fileName
    )

    $ext = [System.IO.Path]::GetExtension($fileName)

    # Keep the list alphabetacally sorted based on extension.
    switch ($ext)
    {
        ".cdx" { return "CDT" }
        ".dxx" { return "DXI" }
        ".hmx" { return "MVL" }
        ".ipx" { return "IPN" }
        ".lpx" { return "LPN" }
        ".ltx" { return "LTS" }
        ".mvx" { return "MVL" }
        ".nax" { return "NAA" }
        ".pgx" { return "PGN" }
        ".psx" { return "PSN" }
        ".rgx" { return "RGL" }
        ".rrx" { return "RRT" }
        ".scx" { return "SEC" }
        ".trx" { return "TRN" }
        ".usx" { return "USI" }
        ".wxx" { return "WXS" }
        ".xfx" { return "XFS" }
        default { Write-Error "Invalid extension supplied: $ext" }
    }
}

 <#
    Call download data file script. Update path if needed.
 #>
Function DownloadDataFiles
{
    param
    (
	    [Parameter(Mandatory=$true)][string]$destPath,
	    [Parameter(Mandatory=$true)][string[]]$fileIds
    )

    # Get this script's full path.
    $scriptPath = split-path -parent $PSCommandPath	 

    # Get the relative path to DownloadDataFiles.ps1
    #$command = "$scriptPath\..\..\Backend\PowerShellScripts\DownloadDataFiles.ps1" #local for developers
    $command = "$scriptPath\..\CommonScripts\DownloadDataFiles.ps1"

    # Execute the script
    & $command -destPath $destPath -fileIds $fileIds
}

<#
	Downloads files from a given FTP site and dumps it into
	a randomly generated folder and returns the path to	the folder.
	
	The following session variables must be set before calling this function:
	
	$ftpAccountId = FTP setting ID for (s)ftp connection.
	$shareLocation = Full path to .exe files.
#>
Function DownloadFTPFile
{
	# Validate required session variables.
	$functionName = $MyInvocation.MyCommand
	if (!$shareLocation) { Throw "Function $functionName`: Variable `$shareLocation not set. It must be set!" }
	if (!$ftpAccountId) { Throw "Function $functionName`: Variable `$ftpAccountId not set. It must be set!"	}
    if (!$workflowInstanceID) { Throw "Function $functionName`: Variable `$workflowInstanceID not set. It must be set!" }

    # Advent.PDS.FileTransfer.exe will download the files and stream them directly to db.
    $cmd = $shareLocation + "Advent.PDS.FileTransfer.exe"
	$params = "-f$ftpAccountId -w$workflowInstanceID"

	# Note we are using System.Diagnostics.Process to invoke the executable instead 
	# of the powershell command start-process because start-process throws UAC warnings
	# that interferes with the executable.
	$p = New-Object System.Diagnostics.Process
    $p.StartInfo.FileName = $cmd
    $p.StartInfo.Arguments = $params
    $p.StartInfo.UseShellExecute = $false
    #$p.StartInfo.RedirectStandardOutput = true;
    #$p.StartInfo.RedirectStandardError = true;

    # Must pipe start to null otherwise True will be written to the Standard Output
    $p.Start() > $null
    $p.WaitForExit()
    $errorCode = $p.ExitCode
    $p.Dispose()

    # Zero means successful, anything else means an error occurred.
    return $errorCode
}

<#
    This function extracts the mmddyy date part out of the default AXML file naming convention and then mmddyy format into APX long file date format yyyymmdd.
#>
Function GetAPXFormattedDatePart
{
    param
    (
        [Parameter(Mandatory=$true)][string]$fileName
    )

    $dateStartingPoint = GetDateStartingPoint $fileName
    $fileName = [System.IO.Path]::GetFileNameWithoutExtension($fileName)
    $datePart = $fileName.Substring($dateStartingPoint)
    
    [DateTime]$dateFormat = New-Object DateTime
    if (![DateTime]::TryParseExact($datePart, 'MMddyy', [CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref] $dateFormat))
    {
        Write-Error "Date format: $datePart is incorrect, please supply a valid AXML file date in the form of mmddyy."
        return $null
    }

    return $dateFormat.ToString("yyyyMMdd")
}

<#
    This function returns the starting point of the mmddyy file date format of the given file.
#>
Function GetDateStartingPoint
{
    param
    (
        [Parameter(Mandatory=$true)][string]$fileName
    )

    $mmddyyDate = [System.IO.Path]::GetFileNameWithoutExtension($fileName)

    # Subtract 6 from the length of the file name because the date in default file name is mmddyy.
    $dateStartingPoint = $mmddyyDate.Length - 6
    return $dateStartingPoint
}

<#
    This function will get the ip code of the given file name.
#>
Function GetIPCode
{
    param
    (
        [Parameter(Mandatory=$true)][string]$fileName
    )

    $dateStartingPoint = GetDateStartingPoint $fileName
    return $fileName.Substring(0, $dateStartingPoint)
}

<#
	This function will upload the given file.
	
	The following session variables must be set before
	calling this function:
	
	$firmID = The firm to be associated with the uploaded file.
	$shareLocation = Full path to .exe files.
	
#>
Function RegisterFTPFile
{
    param
    (
		[Parameter(Mandatory=$true)][string]$file,
        [Parameter(Mandatory=$true)][int]$fileType,
        [Parameter(Mandatory=$false)][System.Nullable[[int]]]$parentFileID,
        [Parameter(Mandatory=$false)][System.Nullable[[DateTime]]]$businessDate,
        [Parameter(Mandatory=$false)][System.Nullable[[int]]]$fileStatusId
    )

	# Validate required session variables.
	$functionName = $MyInvocation.MyCommand
	if (!$firmID) { Throw "Function $functionName`: Variable `$firmID not set. It must be set!" }
    if (!$workflowInstanceID) { Throw "Function $functionName`: Variable `$workflowInstanceID not set. It must be set!" }
    
    # ParentFileId is null for filetype = 1 or 2 or a value greater than zero for all other file types.
    if ($parentFileID -ne $null)
    {
        if ($parentFileID -lt 1)
        {
            Throw "Function $functionName`: Value for `$parentFileID not valid. It must be set to $null or greater than zero!"
        }
    }

    # Get this script's full path.
    $scriptPath = split-path -parent $PSCommandPath	 

    # Upload the given file to the DB
    Try
    {
        $fs = [Advent.PDS.BusinessCommon.Master.FileStreaming]
        $fi = New-Object IO.FileInfo $file
        $fileStream = New-Object IO.FileStream $file ,'Open','Read'
        $fileID = $fs::UploadDataFile($fi.Name, $firmID, $fi.Length, $fileType, $fileStream, $parentFileID, $workflowInstanceID, $businessDate, $fileStatusId)
    }
    Catch
    {
        Write-Error $_
        return 0
    }
    Finally
    {
        if ($fileStream -ne $null)
        {
            $fileStream.Dispose();
        }
    }

	# Return FileID for the registered file.
	return $fileId
}
