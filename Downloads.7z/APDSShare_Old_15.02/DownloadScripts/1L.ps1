param
(
    [Parameter(Mandatory=$true)][string]$shareLocation,
    [Parameter(Mandatory=$true)][string]$firmID,
    [Parameter(Mandatory=$true)][string]$workflowInstanceID,
    [Parameter(Mandatory=$true)][string]$ftpAccountId
)

# Import functions to the current session.
$scriptPath = split-path -parent $PSCommandPath	 # Get this script's full path.
. "$scriptPath\APDSDownloadFunctionsLib.ps1"

$scriptName = $MyInvocation.MyCommand.Name

Write-Host "Begin download script $scriptName."
Try
{
    # Acquire file(s) with the specified FTP setting $ftpAccountId.
    $outPath = $null
    $errorCode = DownloadFTPFile ([ref]$outPath)
    if ($errorCode -gt 0)
    {
        Write-Error "DownloadFile encountered an error."
        
        # Wait one second to allow the agent job runner to encapsulate all information written to standard error as one block.
        Wait-Event -Timeout 1
    }

    $files = Get-ChildItem -Path $outPath
    foreach($file in $files)
    {
        $newname = ''
        $filename = $file.Name
        
        # Rename to appropriate file extension based on keyword in the file name.
        if ($file.BaseName.Contains('POSIT'))
        {
            # Expect format: 10087POSIT20121204_043052.txt
            # Rename to 1Lmmddyy.ps1
            $newname = '1L' + $file.BaseName.Substring(14,4) + $file.BaseName.Substring(12,2) + '.ps1'
        }
        elseif ($file.BaseName.Contains('TRANS'))
        {
            # Expect format: 10087_TRANS_20121204_LOC.TXT
            # Rename to 1Lmmddyy.tr1
            $newname = '1L' + $file.BaseName.Substring(16,4) + $file.BaseName.Substring(14,2) + '.tr1'
        }
        
        if ($newname -ne '')
        {
            rename-item $file.FullName -newname $newname
            $filename = $newname
        }

        # Upload it the database.
        $filename = Join-Path $file.DirectoryName $filename
        $fileId = RegisterFTPFile $filename 2 $null (Get-Date -format MM/dd/yyyy)
        if ($fileId -gt 0)
        {
            Write-Host "File: $filename uploaded successfully with file ID: $fileId"
        }
        else
        {
            Write-Error "File: $filename failed to uploaded."
            
            # Wait one second to allow the agent job runner to encapsulate all information written to standard error as one block.
            Wait-Event -Timeout 1
        }
    }
}
Catch [System.Exception]
{
    Write-Error $_
}
Finally
{
    # Remove the temporary folder and all items from it.
    If (Test-Path $outPath)
    {
        Remove-Item .\$outPath -Force -Recurse
    }
}

Write-Host "End of download script $scriptName."
