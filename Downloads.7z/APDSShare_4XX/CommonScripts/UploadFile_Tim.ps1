﻿
# Contains the full path and file name of the script that is being run.
$scriptPath = split-path -parent $PSCommandPath
# Execute the following script to load dependencies.
&("$scriptPath\LoadBusinessLayer.ps1")

# Upload the given file to the DB
Try
{

    $fs = [Advent.PDS.BusinessCommon.Master.FileStreaming]
    $fi = New-Object IO.FileInfo $file
    $fileStream = New-Object IO.FileStream $file ,'Open','Read'
    Write-Host "Starting UploadDataFile filename= $($fi.Name)  firmID= $firmID"
	$fileID = $fs::UploadDataFile($fi.Name, $firmID, $fi.Length, $fileType, $fileStream, $parentFileID, $workflowInstanceID, $businessDate, $fileStatusId)
    Write-Host "Completed UploadDataFile filename= $($fi.Name)  firmID= $firmID"

	Write-Host "[TL Debug] Starting to get latest args values"
	$fi.Name 
	$firmID 
	$fi.Length 
	$fileType 
	$fileStream 
	$parentFileID 
	$workflowInstanceID 
	$businessDate 
	$fileStatusId
	Write-Host "[TL Debug] Args Completed"
	$fileID = $fs::UploadDataFile($fi.Name, $firmID, $fi.Length, $fileType, $fileStream, $parentFileID, 1, $businessDate, $fileStatusId)
}
Catch
{
    Write-Error $_.Exception
    return 0
}
