[cmdletbinding()]
Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "$ModulesDirectory\UnitTest.psm1"
}
#Requires -Modules LogMessage, InvokeGenericExe

Function Invoke-FixedLengthUtility{
    [CmdletBinding()] 
    Param(
        [validateScript({Test-Path -Path $_})] [string] $FixedLengthUtilityPath,
        [validateScript({Test-Path -Path $_})] [string] $FixedLengthUtilityTempDirectory = (Split-Path -Path $InputFilePath -Parent),
        [validateScript({Test-Path -Path $_})] [string] $FixedLengthIniPath,
        [validateScript({Test-Path -Path $_})] [string] $InputFilePath,
        [validateScript({Test-Path -Path $_ -IsValid})][string] $OutputFilePath = $InputFilePath + ".FixedLength",
        [string] $IniFileType,
        [switch] $PassThru
    )
    #The Fixed Length Utility cannot take Path arguments with spaces in the name.  Use Dos8.3 Names if possible, otherwise temporarily copy the file to the file to the temp directory if there are spaces in the original folder, or rename the file replacing spaces with underscores in the name
    try {
        $TempFixedLengthUtilityTempDirectory = Get-DOSPathFromLongName -Path $FixedLengthUtilityTempDirectory
    } catch {
        $TempFixedLengthUtilityTempDirectory = $FixedLengthUtilityTempDirectory
    }
    If ($TempFixedLengthUtilityTempDirectory -match ' '){
        If ($TempFixedLengthUtilityTempDirectory -match ' '){
            'Unable to get Dos 8.3 directory name for temporary directory "{0}".  The fixed Length Utility cannot run on paths containing spaces that have no Dos 8.3 file name.  Please specify a different Temp Directory.' -f $FixedLengthUtilityTempDirectory | Write-LogMessage -WriteError
            return
        }
    }

    try {
        $TempInputFilePath = Get-DOSPathFromLongName -Path $InputFilePath
    } catch {
        $TempInputFilePath = $InputFilePath
    }
    If ($TempInputFilePath -match ' '){
        If ($TempInputFilePath -match ' '){
            $TempInputFileDir = [System.IO.Path]::GetDirectoryName($TempInputFilePath)
            $TempInputFileName = [System.IO.Path]::GetFileName($TempInputFilePath)
            If ($TempInputFileDir -match ' '){
                $TempInputFileDir = $TempFixedLengthUtilityTempDirectory
            }
            If ($TempInputFileName -match ' '){
                $TempInputFileName = $TempInputFileName -replace ' ', '_'
            }
            $TempInputFilePath = Join-Path -Path $TempInputFileDir -ChildPath $TempInputFileName
            'Unable to get Dos 8.3 File name for "{0}".  The fixed Length Utility cannot run on paths containing spaces that have no Dos 8.3 file name.  Using "{1}" instead.' -f $InputFilePath, $TempInputFilePath | Write-LogMessage -WriteError            
            Copy-Item -LiteralPath $InputFilePath -Destination $TempInputFilePath | Out-Null
        }
    }

    try {
        $TempFixedLengthIniPath = Get-DOSPathFromLongName -Path $FixedLengthIniPath
    } catch {
        $TempFixedLengthIniPath = $FixedLengthIniPath
    }
    If ($TempFixedLengthIniPath -match ' '){
        If ($TempFixedLengthIniPath -match ' '){
            $TempFixedLengthIniDir = [System.IO.Path]::GetDirectoryName($TempFixedLengthIniPath)
            $TempFixedLengthIniName = [System.IO.Path]::GetFileName($TempFixedLengthIniPath)
            If ($TempFixedLengthIniDir -match ' '){
                $TempFixedLengthIniDir = $TempFixedLengthUtilityTempDirectory
            }
            If ($TempFixedLengthIniName -match ' '){
                $TempFixedLengthIniName = $TempFixedLengthIniName -replace ' ', '_'
            }
            $TempFixedLengthIniPath = Join-Path -Path $TempFixedLengthIniDir -ChildPath $TempFixedLengthIniName
            'Unable to get Dos 8.3 File name for "{0}".  The fixed Length Utility cannot run on paths containing spaces that have no Dos 8.3 file name.  Using "{1}" instead.' -f $InputFilePath, $TempInputFilePath | Write-LogMessage -WriteError            
            Copy-Item -LiteralPath $FixedLengthIniPath -Destination $TempFixedLengthIniPath | Out-Null
        }
    }

    try {
        $TempOutputFilePath = Get-DOSPathFromLongName -Path $OutputFilePath
    } catch {
        $TempOutputFilePath = $OutputFilePath
    }
    If ($TempOutputFilePath -match ' '){
        If ($TempOutputFilePath -match ' '){
            $TempOutputFileDir = [System.IO.Path]::GetDirectoryName($TempOutputFilePath)
            $TempOutputFileName = [System.IO.Path]::GetFileName($TempOutputFilePath)
            If ($TempOutputFileDir -match ' '){
                $TempOutputFileDir = $TempFixedLengthUtilityTempDirectory
            }
            If ($TempOutputFileName -match ' '){
                $TempOutputFileName = $TempOutputFileName -replace ' ', '_'
            }
            $TempOutputFilePath = Join-Path -Path $TempOutputFileDir -ChildPath $TempOutputFileName
        }
    }


    $Args = @(
        '-i{0}' -f $TempInputFilePath
        '-o{0}' -f $TempOutputFilePath
        '-f{0}' -f $TempFixedLengthIniPath
        '-l{0}' -f $TempFixedLengthUtilityTempDirectory
        '-s{0}' -f $IniFileType
    ) -join ' '
    $FixedLengthUtilityLogPath = $FixedLengthUtilityTempDirectory + '\FixedLength.err'

    $FixedLengthAttempts = 0
    $ContinueProcessing = $True
    While ($ContinueProcessing -and $FixedLengthAttempts -lt 5){
        $FixedLengthAttempts += 1

        If (Test-Path $TempOutputFilePath){
            'Deleting existing fixed Length file: "{0}"' -f $TempOutputFilePath | Write-LogMessage
            Remove-Item -Path $TempOutputFilePath -Force | Out-Null
        }

        Invoke-GenericExe -ExePath $FixedLengthUtilityPath -Args $Args -TempFolderPath $FixedLengthUtilityTempDirectory
        $WaitCount = 0
        While ($WaitCount -lt 20 -and -not (test-path -path $FixedLengthUtilityLogPath)){
            $WaitCount += 1
            start-sleep -Seconds 1
        }
        If (test-path $FixedLengthUtilityLogPath){
            "Fixed Length Log Results:" | Write-LogMessage
            $FixedLengthLog = (((Get-Content -Path $FixedLengthUtilityLogPath | Where-Object -Filter {$_}) -join "`n") -split "--------------------------------------------------------------------------------")[-1].trim() 
            If ($FixedLengthLog -match '\*Error\*'){
                $FixedLengthLog | Write-LogMessage -WriteWarning
                throw "Error detected in fixed length log"
            } else {
                $FixedLengthLog | Write-LogMessage        
            }
        } else {
            $FixedLengthUtilityLogPath + " was not created" | Write-LogMessage -WriteWarning
        }
        If (test-path $TempOutputFilePath){
            If (-not (test-path -Path $OutputFilePath)){
                Copy-Item -LiteralPath $TempOutputFilePath -Destination $OutputFilePath | Out-Null          
            }
            $return = Get-item $OutputFilePath
            $ContinueProcessing = $False
        } else {
            "{0} was not created on try #{1}." -f $OutputFilePath, $FixedLengthAttempts | Write-LogMessage
            start-sleep -Seconds 5
        }
    }
    If ($ContinueProcessing){
        "Unable to create {0} after {1} attempts." -f $OutputFilePath, $FixedLengthAttempts | Write-LogMessage
    } else {
        "Created {0} after {1} attempts." -f $OutputFilePath, $FixedLengthAttempts | Write-LogMessage    
    }
    If ($Passthru){
        return $return
    }
}

If ($UnitTest){
    $Asserts = @()
    #Unit Tests needed for this script.  
    If ($Asserts | Where-Object -Filter {-not $_}){
        "Unit Test Failed" | Write-LogMessage
    } else {
        "Unit Test Passed" | Write-LogMessage
    }
} else {
    "Unit Test Not Required" | Write-LogMessage -WriteVerbose
}