[cmdletbinding()]
Param(
    [Switch] $UnitTest
)
If ($UnitTest -and (-not (Get-Module UnitTest))){
    Import-Module -Name "$ModulesDirectory\UnitTest.psm1"
}
#Requires -Modules LogMessage, LoadBusinessLayer
#Uses the Generic Type list

#$global:AppSettings.GetEnumerator() | ForEach-Object -Process {
#  New-Object PSObject -Property ([ordered] @{Field = $_; Value = $global:AppSettings[$_]})
#} | Write-LogMessage

#$APDSType_BusinessLayer | Get-Member -Static | Write-LogMessage

$ctx = [Advent.PDS.BusinessCommon.Master.BusinessLayer]::GetNewContext()
#$ctx = $APDSType_BusinessLayer::GetNewContext()

try{
    Add-Type -TypeDefinition @"
    public enum FileType
    {
        Ignored,
        Raw,
        RawAndPrecooked,
        Precooked,
        Cooked
    }
"@
}
catch{}

Function Get-PSMemberDefinitions{
    Param(
        [System.Management.Automation.PSMethod] $PSMember
    )
    $ParameterSets = @()    
    $PSMember.OverloadDefinitions | %{
        $OverloadString = $_ 
        If ($OverloadString -match '^(?<MethodInfo>.*?)(?<ReturnType>[^ ]+) (?<Name>\w+)\((?<Parameters>[^\)]*)\)$'){
            $Matches |%{
                $Match = $_
                $StaticMethod = $Match['MethodInfo'] -match 'Static'
                $Accessibility = $(If ($Match['MethodInfo'] -match 'public|protected|internal|protected internal|private'){$Matches[0]} else {''})
                $ReturnType = $Match['ReturnType']
                $Name = $Match['Name']
                $Parameters = $Match['Parameters'] -split ', ' | %{
                    $ParameterInfo = $_
                    If ($ParameterInfo -match '^(?<ParamsSwitch>Params )?(?<ParameterType>[^ ]+) (?<ParameterName>[^ ]+)$'){                        
                        $Matches | %{
                            $ParameterObject = New-Object PSObject -Property $_ | Select-Object -Property @{Name = 'IsParams'; Expression = {[bool] $_.ParamsSwitch}} , ParameterType, ParameterName
                        }
                        $ParameterObject
                    }
                }
                
                $ParameterSets += New-Object PSObject -Property @{
                    StaticMethod = $StaticMethod
                    Accessibility = $Accessibility
                    ReturnType = $ReturnType
                    Name = $Name
                    Parameters = $Parameters             
                }
            }
        }
    }
    $ParameterSets
}

$Global:ParentFileIDType = Get-PSMemberDefinitions -PSMember ($APDSType_FileStreaming::UploadDataFile) | Select-Object -ExpandProperty 'Parameters' | ?{$_.ParameterName -eq 'ParentFileId'} | Select-Object -ExpandProperty 'ParameterType'

Function Send-FileToDb{
    Param (
        [Parameter(Mandatory=$true)][int]$FirmID,
        [Parameter(Mandatory=$true)][FileType] $FileType,
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$false)][int[]] $ParentFileIDs,
        [Parameter(Mandatory=$false)][System.Nullable[[int]]] $workflowInstanceID,
        [Parameter(Mandatory=$false)][System.Nullable[[DateTime]]] $BusinessDate,
        [Parameter(Mandatory=$false)][System.Nullable[[int]]] $fileStatusId
    )
    Try{
        $CallingFunctionInfo = (Get-PSCallStack)[1]
        "Calling function '" + $CallingFunctionInfo.Command + " " + $CallingFunctionInfo.Arguments + "' in " + $CallingFunctionInfo.Location + " on " +(get-date).tostring("MM/dd/yyyy hh:mm:ss") | Write-LogMessage

        Switch ($Global:ParentFileIDType){
            "System.Nullable[int]" {
                 $NewParentFileID = [System.Nullable[[int]]] ($ParentFileIDs | Select-Object -First 1)
            }
            "String" {
                If ($ParentFileIDs){
                    $NewParentFileID = $ParentFileIDs -join ","
                } else {
                    $NewParentFileID = [System.Management.Automation.Language.NullString]::Value
                }
            }
            Default{
                Throw ("Unrecognized ParentFileId parameter in signature of [{0}]::UploadDataFile" -f $APDSType_FileStreaming.fullname)
            }            
        }
        
        $FileInfoObject = Get-Item -Path $filePath
        $DotNetFileStreamObject = New-Object IO.FileStream $filePath ,'Open','Read'
        #$fileID = $APDSType_FileStreaming::UploadDataFile($FileInfoObject.Name, $FirmID, $FileInfoObject.Length, ($FileType -as [int]), $DotNetFileStreamObject, $workflowInstanceID, $BusinessDate, $fileStatusId)
        $LastFileUploadBefore = Search-DataFiles -Names $FileInfoObject.Name -MostRecent
        "Uploading '{0}' to SQL DB with the following Command:" -f $FileInfoObject.Name | Write-LogMessage -WriteVerbose
        @"
static int UploadDataFile(
    string fileName = {0}, 
    int firmId = {1}, 
    long fileSizeBytes = {2}, 
    int fileTypeId = {3}, 
    System.IO.Stream fileContent = {4}, 
    {12} parentFileId = {5}, 
    System.Nullable[int] workflowInstanceId = {6}, 
    System.Nullable[datetime] businessDate = {7}, 
    System.Nullable[int] fileStatusId = {8}, 
    System.Nullable[int] fileMaskId = {9}, 
    System.Nullable[bool] isDownloadable = {10}, 
    System.Nullable[datetime] ftpModifiedTime = {11}
)
"@ -f @(
            ($FileInfoObject.Name | %{"[{0}] '{1}'" -f $_.gettype().Fullname, $_}), 
            ($FirmID | %{"[{0}] '{1}'" -f $_.gettype().Fullname, $_}),
            ($FileInfoObject.Length | %{"[{0}] '{1}'" -f $_.gettype().Fullname, $_}),
            ($FileType -as [int] | %{"[{0}] '{1}'" -f $_.gettype().Fullname, $_}),
            ($DotNetFileStreamObject | %{"[{0}] '{1}'" -f $_.gettype().Fullname, ("FileStream of " + $_.Name)}),
            $(If ($NewParentFileID) {$NewParentFileID | %{"[{0}] '{1}'" -f $_.gettype().Fullname, $_}}else{'$Null'}),
            $(If ($workflowInstanceID) {$workflowInstanceID | %{"[{0}] '{1}'" -f $_.gettype().Fullname, $_}}else{'$Null'}),
            $(If ($BusinessDate){$BusinessDate | %{"[{0}] '{1}'" -f $_.gettype().Fullname, $_}}else{'$Null'}),
            $(If ($fileStatusID){$fileStatusID | %{"[{0}] '{1}'" -f $_.gettype().Fullname, $_}}else{'$Null'}),
            '$Null', 
            '$Null', 
            '$Null',
            $Global:ParentFileIDType
        ) | Write-LogMessage -WriteVerbose
        $fileID = Retry-ScriptBlock -ScriptblockToAttempt {
            $APDSType_FileStreaming::UploadDataFile(
                $FileInfoObject.Name, 
                $FirmID, 
                $FileInfoObject.Length, 
                ($FileType -as [int]), 
                $DotNetFileStreamObject, 
                $NewParentFileID, 
                $workflowInstanceID, 
                $BusinessDate, 
                $fileStatusId
            )
        } -ScriptblockToCheckRetry {
            $LastFileAfterUpload = Search-DataFiles -Names $FileInfoObject.Name
            $LastFileUploadBefore.DataFileInfoId -eq $LastFileAfterUpload.DataFileInfoId
        }
        return $fileID
    } Catch {
        $CaughtError = $_
        $ErrorMsg = "Error Detected " + $CaughtError.InvocationInfo.PositionMessage + "`r`n" + $CaughtError.Exception.Message
        $ErrorText = $ErrorMsg -split "`r?`n" | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}       
        'The Scriptblock encountered the following error:' | Write-LogMessage -WriteWarning
        $ErrorText | Write-LogMessage -WriteWarning
        $fileID = 0
        return $fileID
    } Finally {
        if ($DotNetFileStreamObject -ne $null) {
            $DotNetFileStreamObject.Dispose();
        }
    }
}

Function Get-DataFiles{
    param
    (
	    # The folder path to download files to.
	    [Parameter(Position=0,Mandatory=$true)]
        [ValidateScript({Test-Path $_})]
        [string]$destPath,
	
	    # A list of unique file Ids to download (comma delimited).
	    [Parameter(ParameterSetName="byFileID",Position=1,Mandatory=$true)][int[]]$fileIds,

	    # Filter files whose business date matches the specified business date.
	    [Parameter(ParameterSetName="byBDate",Position=1,Mandatory=$true)][string]$businessDate,
	    # Filter files belonging to a specified DataSourceFirmID.
	    [Parameter(ParameterSetName="byBDate",Position=2,Mandatory=$true)][int]$DataSourceFirmID,
        [int] $FileTypeID = 1,
        [int] $FileStatusID = 2
    )

   Try
    {
	    # If parameter set byBDate is used, then filter files based on DataSourceFirmID and BusinessDate.
	    if ($PSCmdlet.ParameterSetName -eq "byBDate")
	    {
		    "Downloading file(s) for specified DataSourceFirmID: $DataSourceFirmID and BusinessDate: $businessDate ..." | Write-LogMessage

            [DateTime]$testDateFormat = New-Object DateTime
            if (![DateTime]::TryParseExact($businessDate, 'yyyy-MM-dd', [CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref] $testDateFormat))
            {
                "Date $date is invalid, please specify a valid date and in the form of yyyy-mm-dd." | Write-LogMessage -WriteError
                exit
            }
            $DataFileInfoFilterstring = '$filter=FirmId eq ' + $DataSourceFirmID + ' and BusinessDate eq datetime''' + $businessDate + ''''
            If ($FileTypeID){
                $DataFileInfoFilterstring += ' and DataFileTypeId eq ' + $FileTypeID
            }
            If ($FileStatusID){
	            $DataFileInfoFilterstring += ' and DataFileStatusId eq ' + $FileStatusID	
            }
            $arguments = ($DataFileInfoFilterstring + '&$orderby=DataFileInfoId asc'), 'DataFileInfos'
            $dataFileInfos = Invoke-NonGenericMethod -CallingType $APDSType_Powershell -MethodName 'GetEntities' -ReturnType $APDSType_DataFileInfo -Arguments $arguments

		    $matchCount = $dataFileInfos.Count
		    "Matching files found: $matchCount." | Write-LogMessage
		
		    # Note that if there are multiple instances of the same file, the latest instance
		    # over writes the older instances.  This is done via the odata query ordering by
		    # DataFileInfoId.  OData does not support distinct operator.
		    $dataFileInfos | Where-Object -Filter {$_} | ForEach-Object -Process {
                $dataFileInfo = $_
                Get-DataFile -dataFileInfo $dataFileInfo
		    }
	    }
	    else # Parameter set is by byFileID.
	    {
		    # Now, download files with the supplied fileIds.
		    ForEach ($fileId in $fileIds)
		    {
			    $arguments = ('$filter' + "=DataFileInfoId eq $fileId"), 'DataFileInfos'

			    Try
			    {
                    $dataFileInfos = Invoke-NonGenericMethod -CallingType $APDSType_Powershell -MethodName 'GetEntities' -ReturnType $APDSType_DataFileInfo -Arguments $arguments
			    }
			    Catch
			    {
				    $x = ($error[0] | out-string)
				
				    # "Sequence contains no elements" is too ambiguous of a error msg...
				    if ($x.Contains("Sequence contains no elements"))
				    {
					    "File with fileId $fileId doesn't exist." | Write-LogMessage -WriteWarning
				    }
				    else
				    {
					    throw
				    }
				    continue
			    }

			    Get-DataFile -dataFileInfo $dataFileInfo
		    }
	    }
    }
    Catch
    {
        $CaughtError = $_
        $ErrorMsg = "Error Detected " + $CaughtError.InvocationInfo.PositionMessage + "`r`n" + $CaughtError.Exception.Message
        $ErrorText = $ErrorMsg -split "`r?`n" | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}       
        'The Scriptblock encountered the following error:' | Write-LogMessage -WriteWarning
        $ErrorText | Write-LogMessage -WriteError
    }
}

Function Search-DataFiles{
    param
    (
	   	# Filter files whose business date is one of the specified business dates.
	    [DateTime[]] $businessDates = $null,
	    # Filter files belonging to a set of DataSourceFirmIDs
        [string[]] $Names= $null,
	    [int[]] $FirmIDs = $null,
        [int[]] $FileTypeIDs = $null,
        [int[]] $FileStatusIDs = $null,
        [int[]] $DataFileInfoIds = $null,
        [int[]] $WorkflowInstanceIds = $null,
        [Switch] $MostRecent
    )
    Try {
        $FilterArray = @()
        
        If ($DataFileInfoIds){
            #Filter on Business Dates
            $DataFileInfoIdFilter = @()
            $DataFileInfoIds | ForEach-Object -Process {
                $DataFileInfoIdFilter += 'DataFileInfoId eq ' + $_
            }
            $FilterArray += "(" + ($DataFileInfoIdFilter -join " or ") + ")"
        }

        If ($Names){
            #Filter on Names
            $NameFilter = @()
            $Names | ForEach-Object -Process {
                $NameFilter += 'Name eq ''' + $_ + ''''
            }
            $FilterArray += "(" + ($NameFilter -join " or ") + ")"
        }

        If ($businessDates){
            #Filter on Business Dates
            $BusinessDateFilter = @()
            $BusinessDates | ForEach-Object -Process {
                $BusinessDateFilter += 'BusinessDate eq datetime''' + $_.tostring('yyyy-MM-dd') + ''''
            }
            $FilterArray += "(" + ($BusinessDateFilter -join " or ") + ")"
        }
        
        If ($FirmIDs){
            #Filter on Data Source Firm IDs
            $FirmIDFilter = @()
            $FirmIDs | ForEach-Object -Process {
                $FirmIDFilter += 'FirmId eq ' + $_ 
            }
            $FilterArray += "(" + ($FirmIDFilter -join " or ") + ")"
        }

        If ($FileTypeIDs){
            #Filter on File Type IDs
            $FileTypeIDFilter = @()
            $FileTypeIDs | ForEach-Object -Process {
                $FileTypeIDFilter += 'DataFileTypeId eq ' + $_
            }
            $FilterArray += "(" + ($FileTypeIDFilter -join " or ") + ")"
        }
        
        If ($FileStatusIDs){
	        #Filter on File Statuses
            $FileStatusIDFilter = @()
            $FileStatusIDs | ForEach-Object -Process {
                $FileStatusIDFilter += 'DataFileStatusId eq ' + $_
            }
            $FilterArray += "(" + ($FileStatusIDFilter -join " or ") + ")"
        }

        If ($WorkflowInstanceIDs){
	        #Filter on Status IDs
            $WorkflowInstanceIDFilter = @()
            $WorkflowInstanceIDs | ForEach-Object -Process {
                $WorkflowInstanceIDFilter += 'WorkflowInstanceId eq ' + $_
            }
            $FilterArray += "(" + ($WorkflowInstanceIDFilter -join " or ") + ")"
        }
        
        $FilterString = $FilterArray -join " and "
        $DataFileInfoFilterstring = '$filter=' + $FilterString + '&$orderby=DataFileInfoId asc'
        $arguments = $DataFileInfoFilterstring, 'DataFileInfos'
        
        $dataFileInfos = Invoke-NonGenericMethod -CallingType $APDSType_Powershell -MethodName 'GetEntities' -ReturnType $APDSType_DataFileInfo -Arguments $arguments

		$matchCount = $dataFileInfos.Count
		"Matching files found: $matchCount." | Write-LogMessage -writeverbose
		
        If ($MostRecent){
            # Only Pull the most recent copy of each file name
            $dataFileInfos | 
            Group-Object -Property Name | 
            ForEach-Object -Process {
                $_.group | 
                Sort-Object UploadStartTime -Descending | 
                Select-Object -First 1
            }
        } else {
            $dataFileInfos
        }
    }
    Catch
    {
        $CaughtError = $_
        $ErrorMsg = "Error Detected " + $CaughtError.InvocationInfo.PositionMessage + "`r`n" + $CaughtError.Exception.Message
        $ErrorText = $ErrorMsg -split "`r?`n" | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}       
        'The Scriptblock encountered the following error:' | Write-LogMessage -WriteWarning
        $ErrorText | Write-LogMessage -WriteError
    }
}

Function Get-DataFile{
    [CmdletBinding(DefaultParametersetName = "byDataFileInfoId")]
    Param(
        [Parameter(ParameterSetName="byDataFileInfo", 
                   Mandatory=$true,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [validatescript({$_ -is $APDSType_DataFileInfo})] $dataFileInfo,
        [Parameter(ParameterSetName="byDataFileInfoId", 
                   Mandatory=$true,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [int] $DataFileInfoId,
        [Parameter(Mandatory=$true)][String] $OutputFolder 
    )
    Begin{
    
    }
    Process{
        If ($PSCmdlet.ParameterSetName -eq "byDataFileInfoId"){
            # Get the DataFileInfo from the passed in DataFileInfoId.
            $GetDataFileInfoSettings=@{
                CallingType = $APDSType_Powershell
                ReturnType  = $APDSType_DataFileInfo
                Arguments   = @(
                                ('$filter=DataFileInfoId eq ' + $DataFileInfoId), 
                                'DataFileInfos'
                                )
                MethodName  ='GetEntity'
            }
            $dataFileInfo = Invoke-NonGenericMethod @GetDataFileInfoSettings
        }

	    # declare out parameters
	    $fileSize = $null
	    $streamSize = $null

	    # compose full file name
	    $filePath = $OutputFolder + "\" + $dataFileInfo.Name

	    "Downloading file Id '$($dataFileInfo.DataFileInfoId)'..." | Write-LogMessage
        $DataFileInfoId = $dataFileInfo.DataFileInfoId
        $DataSourceFirmID = $dataFileInfo.FirmId
        $StreamIn = $null
	    # Attempt to download
	    Try
	    {
		    $streamIn = $APDSType_FileStreaming::DownloadDataFile($DataFileInfoId, $DataSourceFirmID, [ref] $fileSize, [ref] $streamSize, $false)

		    # create file
		    $fileIn = New-Object IO.FileStream $filePath ,'Create','Write'

		    # read data and send it to opened file
		    $streamIn.CopyTo($fileIn);
            start-sleep -Seconds 5
	    }
	    Catch
	    {        
            $CaughtError = $_
            $ErrorMsg = "Error Detected " + $CaughtError.InvocationInfo.PositionMessage + "`r`n" + $CaughtError.Exception.Message
            $ErrorText = $ErrorMsg -split "`r?`n" | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}       
            'The Scriptblock encountered the following error:' | Write-LogMessage -WriteWarning
            $ErrorText | Write-LogMessage -WriteWarning

		    "Failed to download file '$($dataFileInfo.Name)' Error: $_" | Write-LogMessage -WriteError
		    return
	    }
	    Finally
	    {
		    # always try to dispose of resources
		    try
		    {
			    $fileIn.Dispose()
			    $streamIn.Close()   
		    }    
		    Catch { } 
	    }

	    # Check received file size matches what's in DB
	    $newFile = New-Object IO.FileInfo $filePath

	    if ($newFile.Length -ne $fileSize)
	    {
		    "File '$($dataFileInfo.Name)' was not downloaded completely!" | Write-LogMessage -WriteWarning
		    "Only downloaded $($newFile.Length) out of $fileSize bytes." | Write-LogMessage -WriteWarning
		    $newFile.Delete();
		    "File is deleted." | Write-LogMessage -WriteWarning
		    continue
	    }

	    "Successfully downloaded file Id '$($dataFileInfo.DataFileInfoId)' to $filePath" | Write-LogMessage
    }
    End{
    }
}

Function Invoke-NonGenericMethod{
    [cmdletbinding()]
    Param (
        [parameter(Mandatory=$true)] [System.Type] $CallingType,
        [parameter(Mandatory=$true)] [String] $MethodName,
        [parameter(Mandatory=$true)] [System.Type]$ReturnType,
        [parameter(Mandatory=$true)] [String[]] $Arguments
    )
    Try{
        Start-FunctionDebugLog
        #$CallingType.count | Write-LogMessage
        #$CallingType.fullname | Write-LogMessage
        #$CallingType.GetMethod | Write-LogMessage
        $Method = $CallingType.GetMethod($MethodName)
        #$Method.MakeGenericMethod  | Write-LogMessage
        #$ReturnType.count | Write-LogMessage
        #$ReturnType.FullName | Write-LogMessage
        $GenMethod = $Method.MakeGenericMethod($ReturnType)
        $GenMethod.Invoke($ReturnType, $Arguments)
    } Catch {
    	#Log unhandled errors
        "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogMessage -WriteWarning
        $_.Exception.Message | Write-LogMessage -WriteWarning
        throw $_
    } Finally {
        Stop-FunctionDebugLog
    }
}

Function Get-AppSettingValue {
    Param (
        $ValueName
    )
    Invoke-NonGenericMethod -CallingType $APDSType_Utility -MethodName 'GetAppSettingValue' -ReturnType $APDSType_Utility -Arguments $ValueName
}

Function Update-BusinessLayerObject {
    [cmdletbinding()]
    Param(
        [String] $Type = 'DataFileInfos',
        [ScriptBlock] $SearchBlock,
        [ScriptBlock] $UpdateBlock
    )
    Retry-ScriptBlock -ScriptblockToAttempt {
        $ctx = $APDSType_BusinessLayer::GetNewContext()
        $MyFiles = Invoke-Command -ScriptBlock $SearchBlock
        $MyFiles |ForEach-Object -Process {
            $CurrentObject = $_ 
            $CurrentObject | ForEach-Object -Process $UpdateBlock
            $ctx.AttachTo($Type, $CurrentObject)
            $ctx.UpdateObject($CurrentObject)
        }
        $ctx.SaveChanges($APDSType_SaveChangesOptions::Batch) | Write-LogMessage -WriteVerbose
    } -ScriptblockToCheckRetry {
        Invoke-Command -ScriptBlock $SearchBlock 
    }
}

Function Update-DataFile {
    Param(
        [int] $DataFileInfoId,
        [HashTable] $UpdateProperties
    )
    $DFIInfo = Search-DataFiles -DataFileInfoIds ($DataFileInfoId)
    If($DFIInfo){
        "Updating Settings for " + $DFIInfo.Name + " (File ID ${DataFileInfoId}) setting the following properties:" | Write-LogMessage
        New-Object PSObject -Property $UpdateProperties | Write-LogMessage
        Update-BusinessLayerObject -SearchBlock {
            Search-DataFiles -DataFileInfoIds ($DataFileInfoId)
        } -UpdateBlock {
            $DataFileInfo = $_
            $UpdateProperties.Keys | ForEach-Object -Process {
                $Key = $_
                $DataFileInfo.$Key = $UpdateProperties[$key]
            }
        }
    }
}

#Based on the script here: https://blogs.endjin.com/2014/07/how-to-retry-commands-in-powershell/
Function Retry-ScriptBlock
{
    param (
        [Parameter(Mandatory=$true)] [alias("ScriptBlock")] [Scriptblock] $ScriptblockToAttempt,
        [Parameter(Mandatory=$false)] [Scriptblock] $ScriptblockToCheckRetry = {$True},
        [Parameter(Mandatory=$false)] [int] $MaxAttemptCount = 5, 
        [Parameter(Mandatory=$false)] [Timespan] $TimeOutMin = "00:00:02",
        [Parameter(Mandatory=$false)] [Timespan] $TimeOutMax = "00:00:05"
    )
    $ScriptBlockToAttemptText = ($ScriptblockToAttempt.ToString().trim() -split "`r?`n") | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}             
    $ScriptblockToCheckRetrytText = ($ScriptblockToCheckRetry.ToString().trim() -split "`r?`n") | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}             
    $AttemptCount = 0
    $Completed = $false
    "Attempting to run the following scriptblock a maximum of {0} times:" -f $MaxAttemptCount | Write-LogMessage -WriteVerbose
    $ScriptBlockToAttemptText | Write-LogMessage  -WriteVerbose

    Do {
        try {
            $AttemptCount += 1
            'Beginning Attempt {0}/{1}' -f $AttemptCount, $MaxAttemptCount | Write-LogMessage
            $ReturnObj = Invoke-Command -ScriptBlock $ScriptblockToAttempt
            'The scriptblock ran successfully.' | Write-LogMessage 
            $Completed = $true
        } catch {
            $CaughtError = $_
            $ErrorMsg = "Error Detected " + $CaughtError.InvocationInfo.PositionMessage + "`r`n" + $CaughtError.Exception.Message
            $ErrorText = $ErrorMsg -split "`r?`n" | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}       
            $ErrorText | Write-LogMessage -WriteWarning
            If ($AttemptCount -ge $MaxAttemptCount) {
                $Completed = $true
                'This scriptblock has failed the maximum number of allowed times and will not run again.' -f $MaxAttemptCount | Write-LogMessage -WriteError 
            } else {
                Try {
                    $Retry = Invoke-Command -ScriptBlock $ScriptblockToCheckRetry
                } catch {
                    $Retry = $false
                }
                If ($Retry){
                    $NextTimeOut = [TimeSpan]::FromMilliseconds((($TimeOutMin.TotalMilliseconds)..($TimeOutMax.TotalMilliseconds) | Get-Random))
                    'Rerunning the scriptblock in {0} seconds.' -f $NextTimeOut.TotalSeconds | Write-LogMessage 
                    Start-Sleep -Milliseconds $NextTimeOut.TotalMilliseconds
                } else {
                    $Completed = $true
                    "The retry condition:`r`n{0}`r`nwas not met. This scriptblock will not be run again" -f $ScriptblockToCheckRetrytText | Write-LogMessage -WriteVerbose
                }
            }
        }
    } Until ($Completed -or ($AttemptCount -ge $MaxAttemptCount))
    $ReturnObj
}

If ($UnitTest){
    $Asserts = @()
    $Asserts += Assert-Equal -TestInput 1 -ExpectedValue 1
    $Asserts += Assert-NotEqual -TestInput 1 -UnexpectedValue 0
    $Asserts += Assert-Is -TestInput 1 -ExpectedType ([int])
    $Asserts += Assert-IsNot -TestInput 1 -UnexpectedType ([String])
    $Asserts += Assert-Contains -TestInput @(1,2,3) -ExpectedItem 1
    $Asserts += Assert-NotContains -TestInput @(1,2,3) -UnexpectedItem 0
    $Asserts += Assert-MemberOf -TestInput 1 -ExpectedInSet @(1,2,3)
    $Asserts += Assert-NotMemberOf -TestInput 0 -UnexpectedInSet @(1,2,3)
    $Asserts += Assert-Like -TestInput "123" -ExpectedWildcardPattern "?2*"
    $Asserts += Assert-NotLike -TestInput "123" -UnexpectedWildcardPattern "??2*"
    $Asserts += Assert-Match -TestInput "123" -ExpectedRegExPattern '^\d{3}$'
    $Asserts += Assert-NotMatch -TestInput "123" -UnexpectedRegExPattern '^\d{5}$'
    $Asserts += Assert-ScriptBlock -TestInput 1,2,3 -ScriptBlock {$_[0] + 1} -ExpectedValue 2
    If ($Asserts | Where-Object -Filter {-not $_}){
        "Unit Test Failed" | Write-LogMessage
    } else {
        "Unit Test Passed" | Write-LogMessage
    }
} else {
    "Unit Test Not Required" | Write-LogMessage -WriteVerbose
}