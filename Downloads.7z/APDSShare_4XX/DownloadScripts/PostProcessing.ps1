[CmdletBinding(DefaultParametersetName = "UseApxName")]
<#
    This script is used for post-processing activity.
    It can rename all translated files from AXML format to APX long file format.
#>

param(
    # This is the instance id of the firm workflow that called this script.
    [Parameter(Position=1,Mandatory=$true)][int]$workflowInstanceId,
    [Parameter(ParameterSetName = "UseAxysName")][switch] $UseAxysName,
    [Parameter(ParameterSetName = "UseApxName")][switch] $UseApxName
)

Function Rename-ApxFile {
    Param (
        $fileInfo
    )
    # Get the extension and make sure it is AXML format
    $ext = [System.IO.Path]::GetExtension($fileInfo.Name)

    # Only continue to rename if it is an AXML formatted file.
    if (!$ext.EndsWith("x", [System.StringComparison]::OrdinalIgnoreCase)) {
        continue
    }

    # Get the APX file extension mapping.
    $apxFileType = APXFileTypeMapping $fileInfo.Name
    #Write-Debug $apxFileType
        
    # Get the APX converted date part out of the file name.
    $dateFormat = GetAPXFormattedDatePart $fileInfo.Name
    #Write-Debug $dateFormat
        
    # Skip file is invalid date format.
    if ($dateFormat -eq $null) {
        Write-Warning "Skipping renaming of $($fileInfo.Name) due to invalid date format."
        continue
    }

    $ipCode = GetIPCode $fileInfo.Name
    #Write-Debug $ipCode
        
        
    $originalName = $fileInfo.Name
    $fileInfo.Name = "$ipCode-$dateFormat-$apxFileType-0001$ext"
    $ctx.AttachTo('DataFileInfos', $fileInfo)
    $ctx.UpdateObject($fileInfo)
    "Renaming file from $originalName to $ipCode-$dateFormat-$apxFileType-0001$ext" | Write-LogMessage

    # Push file name updates to database in batch.
    if ($fileInfos.Count -gt 0)
    {
        # Pipe the result of SaveChanges() to null so that it's not send to StandardOutput
        $ctx.SaveChanges([System.Data.Services.Client.SaveChangesOptions]::Batch) > $null
    }
}

Try {
    # Import functions to the current session.
    $scriptPath = split-path -parent $PSCommandPath	 # Get this script's full path.
    . "$scriptPath\APDSDownloadFunctionsLib.ps1"

    # Contains the full path and file name of the script that is being run.
    $scriptPath = split-path -Parent $PSCommandPath

    # Use this for local execution for developers
    #$load = "$scriptPath\..\..\Backend\PowerShellScripts\LoadBusinessLayer.ps1"

    # Make sure the above $load is commented out and bottom one uncommented before check-in.
    $load = "$scriptPath\..\CommonScripts\LoadBusinessLayer.ps1"

    # Execute the following script to load dependencies which must be in the relative path as this script.
    & $load

    $ps = [Advent.PDS.BusinessCommon.Master.PowerShell]
    $dataFileInfoType = [Advent.PDS.BusinessCommon.DataServiceProxy.DataFileInfo]

    # Get all the translated files for the given workflow instance ID that produced the files.
    # DataFileTypeId 4 is equal to Translated file. Only translated files that haven't already been renamed will get renamed by this script.
    $arguments = ('$filter' + "=WorkflowInstanceId eq $workflowInstanceId and DataFileTypeId eq 4 and not substringof('0001', Name)"), 'DataFileInfos'
    $fileInfos = $ps.GetMethod('GetEntities').MakeGenericMethod($dataFileInfoType).Invoke($dataFileInfoType, $arguments)

    if ($fileInfos.Count -gt 0)
    {
        $ctx = [Advent.PDS.BusinessCommon.Master.BusinessLayer]::GetNewContext()
    }
    else
    {
        Write-Host "Zero files returned for Post Processing."
        exit 
    }

    foreach ($fileInfo in $fileInfos) {
        Switch ($PSCmdlet.ParameterSetName){
            "UseApxName" {
                Retry-ScriptBlock -ScriptblockToAttempt {
                    Rename-APXFile -fileInfo $fileInfo
                }
            }
            default{
                "No Post Processing Necessary for " + $fileInfo.Name | Write-Host
            }
        }
    }
} Catch [System.Exception] {
    Write-Error $_
}

