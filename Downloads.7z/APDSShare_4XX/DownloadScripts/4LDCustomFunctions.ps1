﻿#Add This to the Business Date Module Library

Function Update-NonAlphaNumericFileWithLastWeekdaysBusinessDate {
    Param(
        [int] $NWeekDaysBack = 1
    )
    $FilePath = Join-Path -Path $Global:BusinessDateTempDirectory -ChildPath ($DataFileInfo.Name)
    If (-not (Test-Path -Path $FilePath)){
        Get-DataFile -DataFileInfoId ($DataFileInfo.DataFileInfoId) -OutputFolder $Global:BusinessDateTempDirectory
    }
    $FileData = Get-content -Path $FilePath -Raw

    If (-not ([Regex]::Match($FileData, '[A-Za-z0-9]').Success)){
        $PreviousWeekdaysBusinessDate = Get-TPlusNWeekDaysBack -InputDate ($DataFileInfo.UploadStartTime) -NWeekDaysBack $NWeekDaysBack
        "'{0}' was marked as business date '01/01/0001', but does not contain alphanumeric characters, updating business date to T+{1} date ('{2}') to allow for the precooked file to be created for its dependent file types..." -f $DataFileInfo.Name, $NWeekDaysBack, $PreviousWeekdaysBusinessDate.tostring("MM/dd/yyyy")  | Write-LogMessage
        Update-DataFile -DataFileInfoId ($_.DataFileInfoId) -UpdateProperties @{BusinessDate = $PreviousWeekdaysBusinessDate}
    }
}

Function Invoke-RepeatedScriptBlock {
    [CmdletBinding()]
    Param(
        [Parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [object] $InputObject,
        [ScriptBlock] $ScriptBlockToRepeat = {$_},
        [int] $TimesToRepeat = 1
    )
    Begin {
        $ReturnArray = @()
    }
    Process{
        $LoopObject = $InputObject
        1..$TimesToRepeat | ForEach-Object {
            $LoopObject = $LoopObject | ForEach-Object -Process $ScriptBlockToRepeat
        }
        $ReturnArray += $LoopObject
    }
    End{
        $ReturnArray
    }
}

Function Get-PreviousWeekday {
    Param(
        [DateTime] $InputDate
    )
    Switch ($InputDate.DayOfWeek){
        "Sunday" {
            Return $InputDate.date.AddDays(-2)
        }
        "Monday" {
            Return $InputDate.date.AddDays(-3)
        }
        Default  {
            Return $InputDate.date.AddDays(-1)
        }
    }
}

Function Get-TPlusNWeekDaysBack{
    Param(
        [DateTime] $InputDate = (Get-Date).date,
        [int] $NWeekDaysBack = 1
    )
    $InputDate | Invoke-RepeatedScriptBlock -ScriptBlockToRepeat {Get-PreviousWeekday -InputDate $_} -TimesToRepeat $NWeekDaysBack
}