[CmdletBinding(SupportsShouldProcess = $True)]
param (
    [Parameter(Mandatory=$False)] [alias("IPID")] [string] $IpidOverride, #<-- Unused
    [Parameter(Position=1, Mandatory=$False)] [string] $shareLocation = '',
    [Parameter(Position=2, Mandatory=$False)] [int] $FirmID=$Null, #<-- Unused
    [Parameter(Position=3, Mandatory=$True)] [int] $WorkflowInstanceID,
    [Switch] $NoLog = $true,
    [Switch] $BetaCooker,
    [Switch] $BetaScriptSettings,
    [Switch] $LoadModulesOnly
)
#    [string] $ManualReprocessFolder="C:\AtlasAgent\Program Files\PDSShare\raw",
$ErrorActionPreference = "Stop"

$Global:OperationActivity = "DataConversion"

Function Pad-Center{
    [CmdletBinding()]
    Param(
        [parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [String] $String,
        [Char]   $PaddingCharacter = "-",
        [int]    $FullLength = 100
    )
    Process{
        $PaddedString = ([string] $PaddingCharacter) + "  " + $String.trim() + "  " + ([string] $PaddingCharacter)
        If ($PaddedString.length -ge $FullLength){
            $PaddedString
        } else {
            $ExtraPadding = [System.Math]::Floor(($FullLength - ($PaddedString.length))/2)
            (([String] $PaddingCharacter) * $ExtraPadding) + $PaddedString + (([String] $PaddingCharacter) * $ExtraPadding)
        }
    }
}

Function Write-LogBeforeModuleLoad{
    [CmdletBinding()]
    Param(
        [parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [alias("Object")] [Object] $PreMessage
    )
    Begin{
        $Header = "WFI-" + $WorkflowInstanceID +"_" + $Global:OperationActivity + ": "
        $PreMessageArray = @()
    }
    Process{
        $PreMessage | Where-Object -Filter {$_} | ForEach-Object -Process {
            $PreMessageArray+=$PreMessage
        }
    } 
    End {
        If ($PreMessageArray){
            $TextMessage = $PreMessageArray | out-string -Width 200
            $FormattedMessage = @()
            $TextMessage | ForEach-Object -Process {
                $_.trim() -split "`r?`n" | Where-Object -Filter {$_.trim()} | ForEach-Object -Process {
                    $FormattedMessage += $_.trim()
                }            
            }
            $AppendedMessage = $Header + $FormattedMessage
            Write-Verbose -Verbose -Message ($AppendedMessage)
        }
    }
}

"Begin DataConversion at " + (get-date).ToString("MM/dd/yyyy hh:mm:ss") | Pad-Center -PaddingCharacter "*" -FullLength 120 | Write-LogBeforeModuleLoad

Try{
    "Determining File Share" | Pad-Center | Write-LogBeforeModuleLoad
    If (Test-Path -path $shareLocation){
        'Using Supplied Parameter: $shareLocation = "{0}" to determine FileShare' -f $shareLocation | Write-LogBeforeModuleLoad
        $ScriptPath = (Join-Path -path $ShareLocation -childpath "..\DownloadScripts\DataConversion.ps1" -Resolve) | Get-Item | Select-Object -ExpandProperty FullName
    }ElseIf (Test-Path -path $PSCommandPath){
        'Using Powershell Variable: $PSCommandPath = "{0}" to determine FileShare' -f $PSCommandPath | Write-LogBeforeModuleLoad
        $ScriptPath = $PSCommandPath | Resolve-Path | Get-Item | Select-Object -ExpandProperty FullName
    } ElseIf (Test-Path -path $MyInvocation.InvocationName){
        'Using Powershell Variable: $MyInvocation.InvocationName = "{0}" to determine FileShare' -f $MyInvocation.InvocationName | Write-LogBeforeModuleLoad
        $ScriptPath = $MyInvocation.InvocationName | Resolve-Path | Get-Item | Select-Object -ExpandProperty FullName
    } Else {
        "Unable to Determine Root Directory" | Write-Error
    }
} catch {
    "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogBeforeModuleLoad
    $_.Exception.Message | Write-LogBeforeModuleLoad
    "Unable to Determine Root Directory" | Write-Error
} 
Try {
    $ADPSScriptName =  [System.IO.Path]::GetFileNameWithoutExtension((Split-Path -Path ($ScriptPath) -Leaf))
    $ADPSSharedDirectory = split-path -Path (split-path -Path ($ScriptPath) -parent) -parent
    "Using $ADPSSharedDirectory as root directory" | Write-LogBeforeModuleLoad

    $Global:DownloadScriptsDirectory     = Join-Path -path $ADPSSharedDirectory -ChildPath "DownloadScripts" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    $Global:ModulesDirectory             = Join-Path -path $ADPSSharedDirectory -ChildPath "DownloadScripts\Modules" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    $Global:PGPDirectory                 = Join-Path -path $ADPSSharedDirectory -ChildPath "DownloadScripts\Modules\PGP" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    $Global:ZipDirectory                 = Join-Path -path $ADPSSharedDirectory -ChildPath "DownloadScripts\Modules\7Zip" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    $Global:ExtensionsDirectory          = Join-Path -path $ADPSSharedDirectory -ChildPath "Extensions" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    $Global:CommonScriptsDirectory       = Join-Path -path $ADPSSharedDirectory -ChildPath "CommonScripts" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    $Global:TempDataDirectory            = ".\TempData" #Join-Path -path $ADPSSharedDirectory -ChildPath "TempData" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    If($BetaCooker){
        $Global:CookersDirectory         = Join-Path -path $ADPSSharedDirectory -ChildPath "Cookers\Beta" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    } else {
        $Global:CookersDirectory         = Join-Path -path $ADPSSharedDirectory -ChildPath "Cookers" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    }
    If($BetaScriptSettings){
        $Global:ScriptSettingsDirectory  = Join-Path -path $ADPSSharedDirectory -ChildPath "DownloadScripts\Beta" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    } else {
        $Global:ScriptSettingsDirectory  = Join-Path -path $ADPSSharedDirectory -ChildPath "DownloadScripts" -Resolve | Get-Item | Select-Object -ExpandProperty FullName
    }
    
    If ($NoLog){
        $Global:LogDirectory    = $Null
        $Global:LogPath = $Null
    } else {
        $Global:LogDirectory    = ($ADPSSharedDirectory + "\DownloadScripts\Logs"       | Resolve-Path).ProviderPath
        $Global:LogPath = $LogDirectory + "\" + $ADPSScriptName + ".log"
    }
} catch {
    "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogBeforeModuleLoad
    $_.Exception.Message | Write-LogBeforeModuleLoad
    "Unable to find all necessary directories" | Write-Error
}   

Try {    
    "Loading Environment Specific XML data from: '${CommonScriptsDirectory}\APDSPowerShell.config'" | Write-LogBeforeModuleLoad
    $Global:XMLConfigSettings = ((Get-Content -Path ($CommonScriptsDirectory + "\APDSPowerShell.config")) -as [xml]).configuration.appSettings.add
} Catch {
    "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogBeforeModuleLoad
    $_.Exception.Message | Write-LogBeforeModuleLoad
    "Unable to Load XML file:'${CommonScriptsDirectory}\APDSPowerShell.config'" | Write-Error
}

If ($PSBoundParameters['Verbose'].IsPresent){
    Get-Variable VerbosePreference | Set-Variable -Value Continue
}
If ($PSBoundParameters['Debug'].IsPresent){
    Get-Variable DebugPreference | Set-Variable -Value Continue
} 

try{
    $GenericConversionFunctionsPath = $ModulesDirectory+"\GenericConversionFunctions.ps1"
    . $GenericConversionFunctionsPath

    "Loading Modules" | Pad-Center | Write-LogBeforeModuleLoad
    Load-ApdsModule -path ($ModulesDirectory+"\UnitTest.psm1") -Force
    Load-ApdsModule -path ($ModulesDirectory+"\LogMessage.psm1") -Force
    Load-ApdsModule -path ($ModulesDirectory+"\LoadBusinessLayer.psm1") -Force
    
    # Load BusinessCommon Types
    $GenericTypeListPath = $ModulesDirectory+"\GenericTypeList.ps1"
    . $GenericTypeListPath

    Load-ApdsModule -path ($ModulesDirectory+"\APDSFileStreaming.psm1") -Force
    Load-ApdsModule -path ($ModulesDirectory+"\APDSBusinessDate.psm1") -Force
    Load-ApdsModule -path ($ModulesDirectory+"\InvokeGenericExe.psm1") -Force
    #Load-ApdsModule -path ($ModulesDirectory+"\InvokeFileTransfer.psm1") -Force
    Load-ApdsModule -path ($ModulesDirectory+"\InvokeFixedLengthUtility.psm1") -Force
    Load-ApdsModule -path ($ModulesDirectory+"\FileNameConversion.psm1") -Force
    Load-ApdsModule -path ($ModulesDirectory+"\GPG.psm1") -Force
    Load-ApdsModule -path ($ModulesDirectory+"\ZipNoDll.psm1") -Force
} Catch {
    "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogBeforeModuleLoad
    $_.Exception.Message | Write-LogBeforeModuleLoad
        "Unable to load all modules before starting main conversion script!" | Write-Error
}

If(-not $LoadModulesOnly){
    Try{
        # Derive all Console/SQL information from the passed in WorkflowInstanceId.
        "Gathering console information for this Workflow Instance" | Pad-Center | Write-LogBeforeModuleLoad        
        $GetWorkflowInstanceSettings=@{
            CallingType = $APDSType_Powershell
            ReturnType  = $APDSType_WorkflowInstance
            Arguments   = @(
                            ('$expand=DataSourceWorkflow/DataSource,DataSourceWorkflow/Workflow,DataSourceWorkflow/ActivityOperations,Subscriber&$filter=WorkflowInstanceId eq ' + $WorkflowInstanceID), 
                            'WorkflowInstances'
                            )
            MethodName  ='GetEntity'
        }
        $Global:WorkflowInstanceSettings = Invoke-NonGenericMethod @GetWorkflowInstanceSettings

        $Global:SubscriberSettings = $WorkflowInstanceSettings.Subscriber
        $Global:DataSourceWorkflowSettings = $WorkflowInstanceSettings.DataSourceWorkflow
        $Global:DataSourceSettings = $DataSourceWorkflowSettings.DataSource
        $Global:WorkflowSettings = $DataSourceWorkflowSettings.Workflow
        $Global:ActivityOperationSettings = $DataSourceWorkflowSettings.ActivityOperations

        $Global:DataSourceWorkflowName = $Global:DataSourceWorkflowSettings.Name

        $Global:DataSourceName = $DataSourceSettings.Name
        If ($IpidOverride) {
            "Using override IPID settings: {0}" -f $IpidOverride | Pad-Center | Write-LogBeforeModuleLoad
            $Global:DataSourceInterfaceCode = $IpidOverride
        } else {
            $Global:DataSourceInterfaceCode = $DataSourceSettings.InterfaceCode
        }

        $Global:SubscriberName = $SubscriberSettings.Name
        $Global:SubscriberCopy = $SubscriberSettings.CopyNumber

        "Updating Log Headers" | Write-LogMessage -WriteVerbose
        
        "Workflow Instance Settings" | Pad-Center -PaddingCharacter "~" -FullLength 50 | Write-LogMessage -WriteVerbose
        $WorkflowInstanceSettings | Format-List | Write-LogMessage -WriteVerbose

        "Subscriber Setting" | Pad-Center -PaddingCharacter "~" -FullLength 50 | Write-LogMessage -WriteVerbose
        $SubscriberSettings | Format-List  | Write-LogMessage -WriteVerbose
                
        "DataSource Workflow Settings" | Pad-Center -PaddingCharacter "~" -FullLength 50 | Write-LogMessage -WriteVerbose
        $DataSourceWorkflowSettings | Format-List  | Write-LogMessage -WriteVerbose

        "DataSource Settings" | Pad-Center -PaddingCharacter "~" -FullLength 50 | Write-LogMessage -WriteVerbose
        $DataSourceSettings | Format-List  | Write-LogMessage -WriteVerbose

        "Workflow Settings" | Pad-Center -PaddingCharacter "~" -FullLength 50 | Write-LogMessage -WriteVerbose
        $WorkflowSettings | Format-List  | Write-LogMessage -WriteVerbose

        "Activity Operation Settings" | Pad-Center -PaddingCharacter "~" -FullLength 50 | Write-LogMessage -WriteVerbose
        $ActivityOperationSettings | Format-List  | Write-LogMessage -WriteVerbose

        "This workflow instance #{0} is running Data Source Workflow '{1}',  which processes '{2}' ({3}) files for subscriber '{4}' ({5})" -f  $WorkflowInstanceSettings.WorkflowInstanceId, $DataSourceWorkflowName, $DataSourceName, $DataSourceInterfaceCode, $SubscriberName, $SubscriberCopy| Write-LogMessage

        Try{
            "Loading XML Data" | Pad-Center |  Write-LogMessage
            $XMLData = [xml] (get-content "$ScriptSettingsDirectory\${DataSourceInterfaceCode}_ConversionSettings.xml")

            If (
                $XMLData.Document.ChildNodes | 
                Where-Object -Filter {$_ -match 'AdditionalFiles'} | 
                Select-object -ExpandProperty ChildNodes | 
                Where-Object -Filter {$_ -match 'AdditionalFile'}
            ){
                $AdditionalFiles = $XMLData.Document.AdditionalFiles.SelectNodes('AdditionalFile')
            } else {
                $AdditionalFiles = @()
            }
            "Loaded info on {0} Additional Files: {1}" -f $AdditionalFiles.Count, (($AdditionalFiles | Select-Object -ExpandProperty FilePath) -join ", ") | Write-LogMessage
            If (
                $XMLData.Document.ChildNodes | 
                Where-Object -Filter {$_ -match 'PgpFileTypes'} | 
                Select-object -ExpandProperty ChildNodes | 
                Where-Object -Filter {$_ -match 'PgpFileType'}
            ){
                $PgpFileTypes = $XMLData.Document.PgpFileTypes.SelectNodes('PgpFileType')
            } else {	
                $PgpFileTypes = @()
            }
            "Loaded info on {0} Pgp Files: {1}" -f $PgpFileTypes.Count, (($PgpFileTypes | Select-Object -ExpandProperty Name) -join ", ") |  Write-LogMessage

            If (
                $XMLData.Document.ChildNodes | 
                Where-Object -Filter {$_ -match 'ZipFileTypes'} | 
                Select-object -ExpandProperty ChildNodes | 
                Where-Object -Filter {$_ -match 'ZipFileType'}
            ){
                $ZipFileTypes = $XMLData.Document.ZipFileTypes.SelectNodes('ZipFileType')
            } else {
                $ZipFileTypes = @()
            }
            "Loaded info on {0} Zip Files: {1}" -f $ZipFileTypes.Count, (($ZipFileTypes | Select-Object -ExpandProperty Name) -join ", ") |  Write-LogMessage

            If (
                $XMLData.Document.ChildNodes | 
                Where-Object -Filter {$_ -match 'RawFileTypes'} | 
                Select-object -ExpandProperty ChildNodes | 
                Where-Object -Filter {$_ -match 'RawFileType'}
            ){
                $RawFileTypes = $XMLData.Document.RawFileTypes.SelectNodes('RawFileType')
            } else {
                $RawFileTypes = @()
            }
            "Loaded info on {0} Raw File Types: {1}" -f $RawFileTypes.Count, (($RawFileTypes | Select-Object -ExpandProperty Name) -join ", ") |  Write-LogMessage

            If (
                $XMLData.Document.ChildNodes | 
                Where-Object -Filter {$_ -match 'PrecookedFileTypes'} | 
                Select-object -ExpandProperty ChildNodes | 
                Where-Object -Filter {$_ -match 'PrecookedFileType'}
            ){
                $PrecookedFileTypes = $XMLData.Document.PrecookedFileTypes.SelectNodes('PrecookedFileType')
            } else {
                $PrecookedFileTypes = @()
            }
            "Loaded info on {0} Precooked File Types: {1}" -f $PrecookedFileTypes.Count, (($PrecookedFileTypes | Select-Object -ExpandProperty Name) -join ", ") |  Write-LogMessage
        } Catch {
            "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogMessage
            $_.Exception.Message | Write-LogMessage
            "Unable to load XML Data" | Write-Error
        }

        #Load Additional Files
        If ($AdditionalFiles){
            "Loading Additional Files specified by XML" | Write-LogMessage
            #Load Additional Files
            $AdditionalFiles | Where-Object -Filter {$_} | ForEach-Object -Process {
                 $AdditionalFilePath = Invoke-Expression ('"'+$_.filepath+'"')
                 "Loading $AdditionalFilePath"  | Write-LogMessage
                 . $AdditionalFilePath
            }
        }        

        "Beginning Main Script" | Pad-Center -PaddingCharacter "*" -FullLength 120 | Write-LogMessage

        # Change Temp folder
        $ConversionTempDirectoryBase = "$TempDataDirectory\${DataSourceInterfaceCode}_conversion"
        $Global:ConversionTempDirectoryList = @()

        #Get list of PGP Files.  If necessary determine content date for each, then upload any decrypted output Files (Usually ZIP or RAW).
        "Checking for PGP Files" | Pad-Center | Write-LogMessage        
        If ($PgpFileTypes){
            $PGP_RegexPatterns = $PgpFileTypes | Where-Object -Filter {$_} | Select-Object -ExpandProperty RegexPattern
            $DataFileInfos = Search-DataFiles -WorkflowInstanceIDs @($WorkflowInstanceID) -FileTypeIDs 1 -FileStatusIDs 2 
            $PGPDataFileInfos = $DataFileInfos | Match-RegexPatterns -RegexPatterns $PGP_RegexPatterns -Property Name
            If ($PGPDataFileInfos) {
                "{0} New PGP files are available for this interface" -f $PGPDataFileInfos.count | Write-LogMessage
                $PGPDataFileInfos | ForEach-Object -Process {
                    Try {
                        $DataFileInfo = $_
                        "Decrypting PGP file: " + $DataFileInfo.Name | Write-LogMessage
                        $PGPInfo = $PgpFileTypes | Where-Object -Filter {$DataFileInfo.Name -match $_.RegexPattern} | Select-Object -First 1
                        $Global:PGPTempDirectory = $ConversionTempDirectoryBase + "_PGP_" + $DataFileInfo.Name + "_" + $DataFileInfo.DataFileInfoId
                        $Global:ConversionTempDirectoryList += $PGPTempDirectory 
                        If (-not (Test-Path -Path $Global:PGPTempDirectory)){
                            New-Item -Path $Global:PGPTempDirectory -ItemType Directory | Out-Null
                        } else {
                            Get-ChildItem $Global:PGPTempDirectory | Remove-Item  -Force -Recurse | Out-Null
                        }   
                        Get-DataFile -DataFileInfoId ($DataFileInfo.DataFileInfoId) -OutputFolder $PGPTempDirectory
                        $GPGFilePath = Join-Path -Path ($PGPTempDirectory) -ChildPath ($DataFileInfo.Name)
                        $GPGExecutableFilePath = $Global:PGPDirectory + '\gpg.exe'
                        Invoke-GPGDecrypt -ExePath $GPGExecutableFilePath -TargetPath $GPGFilePath -Passphrase ($PGPInfo.Passphrase) -UsePGPNameAsDecryptedFileName
                        $DecryptedFileName = [System.IO.Path]::GetFileNameWithoutExtension($GPGFilePath)
                        $DecryptedFilePath = Join-Path -Path $PGPTempDirectory -ChildPath $DecryptedFileName
                        "Uploading $DecryptedFileName"  | Write-LogMessage
                        $fileId = Send-FileToDb -FirmID $FirmID -FilePath $DecryptedFilePath -fileType 1 -parentFileID @($DataFileInfo.DataFileInfoId) -businessDate $null -workflowInstanceID $workflowInstanceID -fileStatusId 2     
                    } catch{
                        "Error decrypting PGP file: " + $DataFileInfo.Name | Write-LogMessage
                        "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogMessage -WriteWarning
                        $_.Exception.Message | Write-LogMessage -WriteWarning
                    } Finally {    
                        "Marking " + $DataFileInfo.Name + " as processed" | Write-LogMessage
                        Update-DataFile -DataFileInfoId ($DataFileInfo.DataFileInfoId) -UpdateProperties @{DataFileStatusId = 6}        
                    }
                }
            } else {
                "No New PGP files are available for this interface" | Write-LogMessage
            }
        } else {
            "No PGP files are used for this interface" | Write-LogMessage
        }

        #Get list of Zip Files.  If necessary determine content date for each, then upload any decrypted output Files (Usually RAW).
        "Checking for Zip Files" | Pad-Center | Write-LogMessage        
        If ($ZipFileTypes){
            $Zip_RegexPatterns = $ZipFileTypes | Where-Object -Filter {$_} | Select-Object -ExpandProperty RegexPattern
            $DataFileInfos = Search-DataFiles -WorkflowInstanceIDs @($WorkflowInstanceID) -FileTypeIDs 1 -FileStatusIDs 2 
            $ZipDataFileInfos = $DataFileInfos | Match-RegexPatterns -RegexPatterns $Zip_RegexPatterns -Property Name
            If ($ZipDataFileInfos){
                "{0} New Zip files are available for this interface" -f $ZipDataFileInfos.count | Write-LogMessage
                $ZipDataFileInfos | ForEach-Object -Process {
                    Try{
                        $DataFileInfo = $_
                        "Unzipping Zip file: " + $DataFileInfo.Name | Write-LogMessage
                        $ZipInfo = $ZipFileTypes | Where-Object -Filter {$DataFileInfo.Name -match $_.RegexPattern} | Select-Object -First 1
                        $Global:ZipTempDirectory = $ConversionTempDirectoryBase + "_Zip_" + $DataFileInfo.Name + "_" + $DataFileInfo.DataFileInfoId
                        $Global:ConversionTempDirectoryList += $ZipTempDirectory 
                        If (-not (Test-Path -Path $Global:ZipTempDirectory)){
                            New-Item -Path $Global:ZipTempDirectory -ItemType Directory | Out-Null
                        } else {
                            Get-ChildItem $Global:ZipTempDirectory | Remove-Item  -Force -Recurse | Out-Null
                        }   
                        Get-DataFile -DataFileInfoId ($DataFileInfo.DataFileInfoId) -OutputFolder $ZipTempDirectory
                        $ZipFileTypePath = Join-Path -Path $ZipTempDirectory -ChildPath ($DataFileInfo.Name)
                        Expand-Archive -Archive $ZipFileTypePath -OutputDirectory $ZipTempDirectory

                        $UnZippedFiles = Get-ChildItem -Path $ZipTempDirectory | ?{$_.Name -ne $DataFileInfo.Name} 
                        $UnZippedFiles | %{
                            $UnzippedFileName = $_.Name
                            $UnzippedFilePath = $_.FullName
                            "Uploading $UnzippedFileName"  | Write-LogMessage
                            $fileId = Send-FileToDb -FirmID $FirmID -FilePath $UnzippedFilePath -fileType 1 -parentFileID @($DataFileInfo.DataFileInfoId) -businessDate $null -workflowInstanceID $workflowInstanceID -fileStatusId 2         
                        }    
                    } catch {
                        "Error decrypting Zip file: " + $DataFileInfo.Name | Write-LogMessage                
                        "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogMessage -WriteWarning
                        $_.Exception.Message | Write-LogMessage -WriteWarning                } Finally {
                        "Marking " + $DataFileInfo.Name + " as processed" | Write-LogMessage
                        Update-DataFile -DataFileInfoId ($DataFileInfo.DataFileInfoId) -UpdateProperties @{DataFileStatusId = 6}
                    }
                }
            }else{
                "No New ZIP files are available for this interface" | Write-LogMessage            
            }
        } else {
            "No Zip files are used for this interface" | Write-LogMessage
        }

        "Getting business dates for unprocessed files" | Pad-Center | Write-LogMessage  
        # Get list of New Files (no business date) and determine content date for each, then update Raw Raw Files' business date and upload any unzipped Raw Files by running Process-NewFile function set in main script
        $UnprocessedFilesWithoutBusinessDates = Search-DataFiles -WorkflowInstanceIDs @($WorkflowInstanceID) -FileTypeIDs @(1) -FileStatusIDs @(2) | Where-Object -Filter {-not $_.businessDate}
        If ($UnprocessedFilesWithoutBusinessDates){
            $UnprocessedFilesWithoutBusinessDates | ForEach-Object -Process {
                $DFI = $_
                "Resolving Business Date of {0} (#{1})" -f $DFI.Name, $DFI.DataFileInfoID | Write-LogMessage
                $DFI | Resolve-BusinessDate
            }
        } else {
            "There are no new files with unresolved business dates." | Write-LogMessage
        }
        
        "Getting unprocessed files with newly resolved business dates" | Pad-Center | Write-LogMessage
        # Find Newly Uploaded Raw files whose Business date has been determined
        $NewFiles = Search-DataFiles -WorkflowInstanceIDs @($WorkflowInstanceID) -FirmIDs $FirmID -FileTypeIDs @(1) -FileStatusIDs @(2) | 
        Where-Object -FilterScript {
            $_.businessdate -gt [datetime] 0
        } 
        If ($NewFiles){
            $NewFiles | ForEach-Object -Process {
                "Found {0} (#{1}) with a business date of {2}" -f $_.Name, $_.DataFileInfoID, $_.BusinessDate | Write-LogMessage
            }
        } else {
            "No unprocessed files with resolved business dates were found" | Write-LogMessage
        }

        "Getting potential precooked file type and content date pairs for which new raw files exist " | Pad-Center | Write-LogMessage
        #Get a unique list of Precooked file types and Content date pairs which new raw files exist
        $UniquePrecookedFileTypesAndBusinessDates =@() 
        $NewFiles | Get-UniquePrecookedFileTypesAndBusinessDates | ForEach-Object -Process {
            $UniquePrecookedFileTypesAndBusinessDates += $_
        }
        If ($UniquePrecookedFileTypesAndBusinessDates){
            "Found new raw files that can be used to create precooked file types for the following business dates:" | Write-LogMessage
            $UniquePrecookedFileTypesAndBusinessDates | Write-LogMessage

            "Generating Precooked files" | Pad-Center | Write-LogMessage
            # For each unique Precooked File type/content date found 
            $UniquePrecookedFileTypesAndBusinessDates | ForEach-Object -Process {
                Try{
                    $PrecookedFileTypesAndBusinessDate = $_
                    $PrecookedFileTypesAndBusinessDate | Process-UniquePrecookedFileTypesAndBusinessDates 
                } Catch {
                    "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogMessage -WriteWarning
                    $_.Exception.Message | Write-LogMessage -WriteWarning
                    "Unable to create the preprocessed file:" + $DataSourceInterfaceCode + $PrecookedFileTypesAndBusinessDate.BusinessDate.tostring("MMddyy") + "." + $PrecookedFileTypesAndBusinessDate.PrecookedFileType | Write-LogMessage -WriteWarning
                }
            }
        } Else {
            "No new precooked files can be generated" | Write-LogMessage
        }
     } catch {
        Try{
            "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogMessage -WriteWarning
            $_.Exception.Message | Write-LogMessage -WriteWarning
        } catch {
            "Error Detected " + $_.InvocationInfo.PositionMessage | Write-LogBeforeModuleLoad
            $_.Exception.Message | Write-LogBeforeModuleLoad
        }
    } finally {
        Start-Sleep -Seconds 5

        # Delete Temp folders
        "Cleaning up used temp directories." | Pad-Center | Write-LogMessage
        $Global:ConversionTempDirectoryList | 
        Sort-Object -Unique | ForEach-Object -Process {
            $ConversionTempDirectory = $_
            If ($ConversionTempDirectory -and (Test-Path $ConversionTempDirectory)) {
                Start-Sleep -Seconds 1
                Get-Item $ConversionTempDirectory |ForEach-Object -Process {
                    "Removing $_" | Write-LogMessage
                    Remove-Item -Path $_ -Force -Recurse
                }
            }
        }
        "End at " + (get-date).ToString("MM/dd/yyyy hh:mm:ss") | Pad-Center -PaddingCharacter "*" -FullLength 120 | Write-LogBeforeModuleLoad
    }
}
