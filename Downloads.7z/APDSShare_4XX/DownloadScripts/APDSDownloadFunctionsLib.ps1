﻿<#
    APDSDownloadFunctionsLib.ps1
  
    This module contains a set of common functions used by the download scripts.
 #>

 <#
    This function will give the corresponding Axys File Type for the given AXML file name.
#>
Function APXFileTypeMapping
{
    param
    (
        [Parameter(Mandatory=$true)][string]$fileName
    )

    $ext = [System.IO.Path]::GetExtension($fileName)

    # Keep the list alphabetacally sorted based on extension.
    switch ($ext)
    {
        ".cdx" { return "CDT" }
        ".dxx" { return "DXI" }
        ".hmx" { return "MVL" }
        ".ipx" { return "IPN" }
        ".lpx" { return "LPN" }
        ".ltx" { return "LTS" }
        ".mvx" { return "MVL" }
        ".nax" { return "NAA" }
        ".pgx" { return "PGN" }
        ".psx" { return "PSN" }
        ".rgx" { return "RGL" }
        ".rrx" { return "RRT" }
        ".scx" { return "SEC" }
        ".trx" { return "TRN" }
        ".usx" { return "USI" }
        ".wxx" { return "WXS" }
        ".xfx" { return "XFS" }
        default { Write-Error "Invalid extension supplied: $ext" }
    }
}

 <#
    Call download data file script. Update path if needed.
 #>
Function DownloadDataFiles
{
    param
    (
	    [Parameter(Mandatory=$true)][string]$destPath,
	    [Parameter(Mandatory=$true)][string[]]$fileIds
    )

    # Get this script's full path.
    $scriptPath = split-path -parent $PSCommandPath	 

    # Get the relative path to DownloadDataFiles.ps1
    #$command = "$scriptPath\..\..\Backend\PowerShellScripts\DownloadDataFiles.ps1" #local for developers
    $command = "$scriptPath\..\CommonScripts\DownloadDataFiles.ps1"

    # Execute the script
    & $command -destPath $destPath -fileIds $fileIds
}

<#
	Downloads files from a given FTP site and dumps it into
	a randomly generated folder and returns the path to	the folder.
	
	The following session variables must be set before calling this function:
	
	$ftpAccountId = FTP setting ID for (s)ftp connection.
	$shareLocation = Full path to .exe files.
#>
Function DownloadFTPFile
{
    param
    (
		[ref]$outPath
    )

	# Validate required session variables.
	$functionName = $MyInvocation.MyCommand
	if (!$shareLocation) { Throw "Function $functionName`: Variable `$shareLocation not set. It must be set!" }
	if (!$ftpAccountId) { Throw "Function $functionName`: Variable `$ftpAccountId not set. It must be set!"	}
    if (!$workflowInstanceID) { Throw "Function $functionName`: Variable `$workflowInstanceID not set. It must be set!" }

	# Get random name for folder location where files will be dumped.
	$outPath.Value = [System.IO.Path]::GetFileNameWithoutExtension([System.IO.Path]::GetRandomFileName())

    # Advent.PDS.FileTransfer.exe will create the folder provided in $outPath if one doesn't already exists.
    $cmd = $shareLocation + "Advent.PDS.FileTransfer.exe"
	$params = "-f$ftpAccountId -w$workflowInstanceID -o" + $outPath.Value

	# Note we are using System.Diagnostics.Process to invoke the executable instead 
	# of the powershell command start-process because start-process throws UAC warnings
	# that interferes with the executable.
	$p = New-Object System.Diagnostics.Process
    $p.StartInfo.FileName = $cmd
    $p.StartInfo.Arguments = $params
    $p.StartInfo.UseShellExecute = $false
    #$p.StartInfo.RedirectStandardOutput = true;
    #$p.StartInfo.RedirectStandardError = true;

    # Must pipe start to null otherwise True will be written to the Standard Output
    $p.Start() > $null
    $p.WaitForExit()
    $errorCode = $p.ExitCode
    $p.Dispose()

    # Zero means successful, anything else means an error occurred.
    return $errorCode
}

<#
    This function extracts the mmddyy date part out of the default AXML file naming convention and then mmddyy format into APX long file date format yyyymmdd.
#>
Function GetAPXFormattedDatePart
{
    param
    (
        [Parameter(Mandatory=$true)][string]$fileName
    )

    $dateStartingPoint = GetDateStartingPoint $fileName
    $fileName = [System.IO.Path]::GetFileNameWithoutExtension($fileName)
    $datePart = $fileName.Substring($dateStartingPoint)
    
    [DateTime]$dateFormat = New-Object DateTime
    if (![DateTime]::TryParseExact($datePart, 'MMddyy', [CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref] $dateFormat))
    {
        Write-Error "Date format: $datePart is incorrect, please supply a valid AXML file date in the form of mmddyy."
        return $null
    }

    return $dateFormat.ToString("yyyyMMdd")
}

<#
    This function returns the starting point of the mmddyy file date format of the given file.
#>
Function GetDateStartingPoint
{
    param
    (
        [Parameter(Mandatory=$true)][string]$fileName
    )

    $mmddyyDate = [System.IO.Path]::GetFileNameWithoutExtension($fileName)

    # Subtract 6 from the length of the file name because the date in default file name is mmddyy.
    $dateStartingPoint = $mmddyyDate.Length - 6
    return $dateStartingPoint
}

<#
    This function will get the ip code of the given file name.
#>
Function GetIPCode
{
    param
    (
        [Parameter(Mandatory=$true)][string]$fileName
    )

    $dateStartingPoint = GetDateStartingPoint $fileName
    return $fileName.Substring(0, $dateStartingPoint)
}

<#
	This function will upload the given file.
	
	The following session variables must be set before
	calling this function:
	
	$firmID = The firm to be associated with the uploaded file.
	$shareLocation = Full path to .exe files.
	
#>
Function RegisterFTPFile
{
    param
    (
		[Parameter(Mandatory=$true)][string]$file,
        [Parameter(Mandatory=$true)][int]$fileType,
        [Parameter(Mandatory=$false)][System.Nullable[[int]]]$parentFileID,
        [Parameter(Mandatory=$false)][System.Nullable[[DateTime]]]$businessDate,
        [Parameter(Mandatory=$false)][System.Nullable[[int]]]$fileStatusId
    )

	# Validate required session variables.
	$functionName = $MyInvocation.MyCommand
	if (!$firmID) { Throw "Function $functionName`: Variable `$firmID not set. It must be set!" }
    if (!$workflowInstanceID) { Throw "Function $functionName`: Variable `$workflowInstanceID not set. It must be set!" }
    
    # ParentFileId is null for filetype = 1 or 2 or a value greater than zero for all other file types.
    if ($parentFileID -ne $null)
    {
        if ($parentFileID -lt 1)
        {
            Throw "Function $functionName`: Value for `$parentFileID not valid. It must be set to $null or greater than zero!"
        }
    }

    # Get this script's full path.
    $scriptPath = split-path -parent $PSCommandPath	 

    # Get the relative path to DownloadDataFiles.ps1
    #$command = "$scriptPath\..\..\Backend\PowerShellScripts\FileStore.ps1" #local for developers
    $command = "$scriptPath\..\CommonScripts\FileStore.ps1"

    # Execute the script
    $fileId = & $command $firmID $fileType $file $parentFileID $workflowInstanceID $businessDate $fileStatusId

	# Return FileID for the registered file.
	return $fileId
}


#Based on the script here: https://blogs.endjin.com/2014/07/how-to-retry-commands-in-powershell/
Function Retry-ScriptBlock
{
    param (
        [Parameter(Mandatory=$true)] [alias("ScriptBlock")] [Scriptblock] $ScriptblockToAttempt,
        [Parameter(Mandatory=$false)] [Scriptblock] $ScriptblockToCheckRetry = {$True},
        [Parameter(Mandatory=$false)] [int] $MaxAttemptCount = 5, 
        [Parameter(Mandatory=$false)] [Timespan] $TimeOutMin = "00:00:02",
        [Parameter(Mandatory=$false)] [Timespan] $TimeOutMax = "00:00:05"
    )
    $ScriptBlockToAttemptText = ($ScriptblockToAttempt.ToString().trim() -split "`r?`n") | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}             
    $ScriptblockToCheckRetrytText = ($ScriptblockToCheckRetry.ToString().trim() -split "`r?`n") | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}             
    $AttemptCount = 0
    $Completed = $false
    "Attempting to run the following scriptblock a maximum of {0} times:" -f $MaxAttemptCount | Write-LogMessage 
    $ScriptBlockToAttemptText | Write-LogMessage 

    Do {
        try {
            $AttemptCount += 1
            'Beginning Attempt {0}/{1}' -f $AttemptCount, $MaxAttemptCount | Write-LogMessage
            Invoke-Command -ScriptBlock $ScriptblockToAttempt
            'The scriptblock ran succeessfully.' | Write-LogMessage 
            $Completed = $true
        } catch {
            Try {
                $CaughtError = $_
                $ErrorMsg = "Error Detected " + $CaughtError.InvocationInfo.PositionMessage + "`r`n" + $CaughtError.Exception.Message
                $ErrorText = $ErrorMsg -split "`r?`n" | % -Begin {$OutputArray = @()} -Process {$OutputArray += "  " + $_} -end {$OutputArray -join "`r`n"}       
                'The Scriptblock encountered the following error:' | Write-LogMessage
                $ErrorText | Write-LogMessage
                If ($AttemptCount -ge $MaxAttemptCount) {
                    $Completed = $true
                    'This scriptblock has failed the maximum number of allowed times and will not run again.' -f $MaxAttemptCount | Write-LogMessage -WriteError 
                } else {
                    Try {
                        $Retry = Invoke-Command -ScriptBlock $ScriptblockToCheckRetry
                    } catch {
                        $Retry = $false
                    }
                    If ($Retry){
                        $NextTimeOut = [TimeSpan]::FromMilliseconds((($TimeOutMin.TotalMilliseconds)..($TimeOutMax.TotalMilliseconds) | Get-Random))
                        'Rerunning the scriptblock in {0} seconds.' -f $NextTimeOut.TotalSeconds | Write-LogMessage 
                        Start-Sleep -Milliseconds $NextTimeOut.TotalMilliseconds
                    } else {
                        $Completed = $true
                        "The retry condition:`r`n{0}`r`nwas not met. This scriptblock will not be run again" -f $ScriptblockToCheckRetrytText | Write-LogMessage -WriteError
                    }
                }
            } catch {
                $Completed = $true
            }
        }
    } Until ($Completed)
}

Function Write-Log{
    [CmdletBinding()]
    Param(
        [parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [alias("Object")] [String] $StringMessage
    )
    Begin {
        #HTML Control characters should automatically be escaped by NLOG
        #Escape curly brackets as they throw errors within Powershell
        $CharactersToEscape = '{','}'
        #Also High Unicode xD800 - xDFFF Surrogate characters as they crash the agent
        $CharactersToEscape += [char[]](([convert]::ToInt32('D800',16))..([convert]::ToInt32('DFFF',16)))
    }
    Process{
        Try{
            If ($StringMessage){
                $EscapedStringMessage = $StringMessage
                $CharactersToEscape | %{
                    $CharacterToEscape = $_
                    $EscapedStringMessage = $EscapedStringMessage -replace ([regex]::Escape($CharacterToEscape)), ("&#x{0:X};" -f ([int][char] $CharacterToEscape))
                }
                Write-Verbose -Message $EscapedStringMessage -Verbose
            }
        } catch{}
    }
}

Function Write-LogMessage {
    [CmdletBinding(DefaultParametersetName = "WriteHost")]
    Param(
        [parameter(
            Mandatory=$true,
            ValueFromPipeline=$True
        )] [alias("Object")] [Object] $Message,
        [string] $LogPath = $Global:DownloadLogPath,
        [Parameter(ParameterSetName = "WriteDebug")]   [switch] $WriteDebug,
        [Parameter(ParameterSetName = "WriteError")]   [switch] $WriteError,
        [Parameter(ParameterSetName = "WriteVerbose")] [switch] $WriteVerbose,
        [Parameter(ParameterSetName = "WriteWarning")] [switch] $WriteWarning
    )
    Begin{
        If ($LogPath -and (-not (Test-Path -Path $LogPath))){
            "Creating $LogPath" | Write-Verbose 
            New-Item -Path $LogPath -ItemType File
        }
        $Header = "WIP-" + $workflowInstanceId + ": "
        $ErrorMessage = @()
        $MessageArray = @()
    }
    Process{
        $Message | Where-Object -Filter {$_} | ForEach-Object -Process {
            $MessageArray+=$Message
        }        
    } End {
        $TextMessage = $MessageArray | out-string -Width 200
        $AppendedMessages = @()
        $TextMessage | ForEach-Object -Process {
            $_.trim() -split "`r?`n" | Where-Object -Filter {$_.trim()} | ForEach-Object -Process {
                $AppendedMessages += $Header + $_.trim()
            }            
        }
        $AppendedMessages | Where-Object -Filter {$_} | ForEach-Object -Process {
            $AppendedMessage = $_
            Switch ($PSCmdlet.ParameterSetName){
                "WriteDebug" {
                    If ($DebugPreference -ne 'SilentlyContinue'){
                        "Debug: $AppendedMessage" | Write-Log
                    }
                }
                "WriteError" {
                    If ($LogPath){
                        Try {
                            Add-Content -Path $LogPath -value "Error: $AppendedMessage"
                        } Catch {}
                    }
                    $ErrorMessage += $AppendedMessage
                }
                "WriteVerbose" {
                    If ($VerbosePreference -ne 'SilentlyContinue'){
                        "Verbose: $AppendedMessage" |  Write-Log
                    }
                }
                "WriteWarning" {
                    If ($WarningPreference -ne 'SilentlyContinue'){
                        "Warning: $AppendedMessage" | Write-Log
                    }
                    If ($LogPath){
                        Try {
                            Add-Content -Path $LogPath -value "Warning: $AppendedMessage"
                        } Catch {}
                    }
                }
                default {
                    $AppendedMessage | Write-Log
                    If ($LogPath){
                        Try {
                            Add-Content -Path $LogPath -value $AppendedMessage
                        } Catch {}
                    }
                }
            }
        }
        If ($PSCmdlet.ParameterSetName -eq 'WriteError'){
            $ErrorMessageString = $ErrorMessage -join "`n"
            Write-Error -Message $ErrorMessageString
        }
    }
}
